#!/usr/bin/env bash
# Local build: needs JDK 17+, the Android SDK (ANDROID_HOME set) and Gradle 9.3.1+ on PATH.
# Android Studio users can instead run: Build > Build Bundle(s) / APK(s) > Build APK(s).
set -euo pipefail
gradle :app:assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
