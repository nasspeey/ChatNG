package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBackIos
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.DonutLarge
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.DonutLarge
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.ui.navigation.MainTab
import com.example.ui.theme.DangerRed
import com.example.ui.theme.LocalHighContrast
import com.example.ui.theme.OnlineGreen
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** iOS-flavoured colour helpers derived from the active theme. */
object IOS {
  val isDark: Boolean
    @Composable get() = MaterialTheme.colorScheme.background.luminance() < 0.5f

  /** Page background of grouped (Settings-style) screens. */
  val groupedBg: Color
    @Composable get() = if (isDark) Color.Black else Color(0xFFF2F2F7)

  /** Card / row background inside grouped screens. */
  val groupedCard: Color
    @Composable get() = if (isDark) Color(0xFF1C1C1E) else Color.White

  val highContrast: Boolean
    @Composable get() = LocalHighContrast.current

  val separator: Color
    @Composable get() = when {
      highContrast -> if (isDark) Color(0xFF8E8E93) else Color(0xFF6C6C70)
      isDark -> Color(0xFF38383A)
      else -> Color(0xFFD1D1D6)
    }

  val secondaryLabel: Color
    @Composable get() = when {
      highContrast -> if (isDark) Color(0xFFD1D1D6) else Color(0xFF3C3C43)
      isDark -> Color(0xFF8E8E93)
      else -> Color(0xFF8A8A8E)
    }

  /** Search-field / segmented-control fill. */
  val fill: Color
    @Composable get() = if (isDark) Color(0xFF1C1C1E) else Color(0xFFEEEEF0)

  val receivedBubble: Color
    @Composable get() = when {
      highContrast -> if (isDark) Color(0xFF3A3A3C) else Color(0xFFD1D1D6)
      isDark -> Color(0xFF262629)
      else -> Color(0xFFE9E9EB)
    }

  val bar: Color
    @Composable get() = (if (isDark) Color(0xFF121212) else Color(0xFFF9F9F9)).copy(alpha = 0.97f)
}

// ---------------------------------------------------------------- titles / bars

@Composable
fun IOSLargeTitle(
  title: String,
  modifier: Modifier = Modifier,
  actions: @Composable RowScope.() -> Unit = {}
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .statusBarsPadding()
      .padding(start = 20.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.displaySmall,
      color = MaterialTheme.colorScheme.onBackground,
      modifier = Modifier.weight(1f)
    )
    actions()
  }
}

@Composable
fun IOSNavBar(
  title: String? = null,
  onBack: (() -> Unit)? = null,
  backLabel: String = "Back",
  titleContent: (@Composable () -> Unit)? = null,
  background: Color = IOS.bar,
  trailing: @Composable RowScope.() -> Unit = {}
) {
  Column(Modifier.fillMaxWidth()) {
    Box(
      Modifier
        .fillMaxWidth()
        .background(background)
        .statusBarsPadding()
        .height(48.dp)
    ) {
      if (onBack != null) {
        Row(
          Modifier
            .align(Alignment.CenterStart)
            .clickable(
              interactionSource = remember { MutableInteractionSource() },
              indication = null,
              onClick = onBack
            )
            .padding(start = 8.dp, end = 16.dp, top = 12.dp, bottom = 12.dp)
            .testTag("nav_back"),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            Icons.AutoMirrored.Filled.ArrowBackIos,
            contentDescription = "Back",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp)
          )
          Text(backLabel, fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
        }
      }
      Box(Modifier.align(Alignment.Center)) {
        if (titleContent != null) titleContent() else if (title != null) {
          Text(
            title,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 96.dp)
          )
        }
      }
      Row(
        Modifier
          .align(Alignment.CenterEnd)
          .padding(end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = trailing
      )
    }
    HorizontalDivider(thickness = 0.5.dp, color = IOS.separator)
  }
}

/** Blue text button used in nav bars ("Done", "Edit", "Post"). */
@Composable
fun IOSTextButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  bold: Boolean = false,
  destructive: Boolean = false
) {
  val color = when {
    !enabled -> IOS.secondaryLabel
    destructive -> DangerRed
    else -> MaterialTheme.colorScheme.primary
  }
  Text(
    text = text,
    color = color,
    fontSize = 17.sp,
    fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
    modifier = modifier
      .clip(RoundedCornerShape(8.dp))
      .clickable(enabled = enabled, onClick = onClick)
      .padding(horizontal = 8.dp, vertical = 8.dp)
  )
}

@Composable
fun IOSIconButton(
  icon: ImageVector,
  contentDescription: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  tint: Color = MaterialTheme.colorScheme.primary
) {
  Box(
    modifier
      .size(40.dp)
      .clip(CircleShape)
      .clickable(onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Icon(icon, contentDescription, tint = tint, modifier = Modifier.size(24.dp))
  }
}

// ---------------------------------------------------------------- inputs

@Composable
fun IOSSearchField(
  value: String,
  onValueChange: (String) -> Unit,
  modifier: Modifier = Modifier,
  placeholder: String = "Search"
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .height(38.dp)
      .clip(RoundedCornerShape(10.dp))
      .background(IOS.fill)
      .padding(horizontal = 8.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(Icons.Filled.Search, null, tint = IOS.secondaryLabel, modifier = Modifier.size(18.dp))
    Box(Modifier.weight(1f).padding(start = 6.dp), contentAlignment = Alignment.CenterStart) {
      if (value.isEmpty()) {
        Text(placeholder, fontSize = 17.sp, color = IOS.secondaryLabel)
      }
      BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = TextStyle(fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface),
        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
        modifier = Modifier.fillMaxWidth().testTag("search_field")
      )
    }
    if (value.isNotEmpty()) {
      Icon(
        Icons.Filled.Cancel,
        contentDescription = "Clear",
        tint = IOS.secondaryLabel,
        modifier = Modifier
          .size(18.dp)
          .clickable { onValueChange("") }
      )
    }
  }
}

@Composable
fun IOSPrimaryButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  destructive: Boolean = false
) {
  Button(
    onClick = onClick,
    enabled = enabled,
    shape = RoundedCornerShape(12.dp),
    colors = ButtonDefaults.buttonColors(
      containerColor = if (destructive) DangerRed else MaterialTheme.colorScheme.primary,
      contentColor = Color.White
    ),
    modifier = modifier.fillMaxWidth().height(50.dp)
  ) {
    Text(text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
fun IOSSegmented(
  options: List<String>,
  selectedIndex: Int,
  onSelect: (Int) -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(9.dp))
      .background(IOS.fill)
      .padding(2.dp)
  ) {
    options.forEachIndexed { i, label ->
      val selected = i == selectedIndex
      Box(
        Modifier
          .weight(1f)
          .clip(RoundedCornerShape(7.dp))
          .background(
            if (selected) (if (IOS.isDark) Color(0xFF636366) else Color.White) else Color.Transparent
          )
          .clickable { onSelect(i) }
          .padding(vertical = 7.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          label,
          fontSize = 13.sp,
          fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
          color = MaterialTheme.colorScheme.onSurface
        )
      }
    }
  }
}

// ---------------------------------------------------------------- grouped lists

@Composable
fun IOSSection(
  modifier: Modifier = Modifier,
  header: String? = null,
  footer: String? = null,
  content: @Composable ColumnScope.() -> Unit
) {
  Column(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
    if (header != null) {
      Text(
        header.uppercase(Locale.getDefault()),
        fontSize = 13.sp,
        color = IOS.secondaryLabel,
        modifier = Modifier.padding(start = 16.dp, bottom = 6.dp)
      )
    }
    Column(
      Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(IOS.groupedCard),
      content = content
    )
    if (footer != null) {
      Text(
        footer,
        fontSize = 13.sp,
        color = IOS.secondaryLabel,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 6.dp)
      )
    }
  }
}

@Composable
fun IOSDivider(startInset: Dp = 16.dp) {
  HorizontalDivider(
    modifier = Modifier.padding(start = startInset),
    thickness = 0.5.dp,
    color = IOS.separator
  )
}

@Composable
fun IOSRow(
  title: String,
  modifier: Modifier = Modifier,
  subtitle: String? = null,
  value: String? = null,
  leading: (@Composable () -> Unit)? = null,
  trailing: (@Composable () -> Unit)? = null,
  chevron: Boolean = false,
  destructive: Boolean = false,
  showDivider: Boolean = true,
  dividerInset: Dp = 16.dp,
  onClick: (() -> Unit)? = null
) {
  Column(modifier) {
    Row(
      Modifier
        .fillMaxWidth()
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
        .heightIn(min = 46.dp)
        .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (leading != null) {
        leading()
        Spacer(Modifier.width(12.dp))
      }
      Column(Modifier.weight(1f)) {
        Text(
          title,
          fontSize = 17.sp,
          color = if (destructive) DangerRed else MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        if (subtitle != null) {
          Text(
            subtitle,
            fontSize = 14.sp,
            color = IOS.secondaryLabel,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }
      if (value != null) {
        Text(
          value,
          fontSize = 17.sp,
          color = IOS.secondaryLabel,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.padding(start = 8.dp).widthIn(max = 190.dp)
        )
      }
      if (trailing != null) {
        Spacer(Modifier.width(8.dp))
        trailing()
      }
      if (chevron) {
        Icon(
          Icons.AutoMirrored.Filled.ArrowForwardIos,
          contentDescription = null,
          tint = IOS.secondaryLabel.copy(alpha = 0.7f),
          modifier = Modifier.padding(start = 8.dp).size(13.dp)
        )
      }
    }
    if (showDivider) IOSDivider(dividerInset)
  }
}

/** Rounded-square coloured icon used on Settings rows. */
@Composable
fun IOSIconBadge(icon: ImageVector, color: Color) {
  Box(
    Modifier.size(29.dp).clip(RoundedCornerShape(7.dp)).background(color),
    contentAlignment = Alignment.Center
  ) {
    Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
  }
}

// ---------------------------------------------------------------- avatar / badges

private val AvatarPalette = listOf(
  0xFF5E5CE6, 0xFFFF9F0A, 0xFF30B0C7, 0xFFFF375F, 0xFF34C759, 0xFFAF52DE, 0xFF007AFF
)

@Composable
fun Avatar(
  url: String,
  name: String,
  size: Dp = 50.dp,
  online: Boolean = false,
  modifier: Modifier = Modifier
) {
  val initials = name.trim().split(" ").filter { it.isNotEmpty() }
    .take(2).joinToString("") { it.first().uppercase() }.ifEmpty { "?" }
  val bg = Color(AvatarPalette[(name.hashCode() and Int.MAX_VALUE) % AvatarPalette.size])

  Box(modifier.size(size)) {
    Box(
      Modifier.size(size).clip(CircleShape).background(bg),
      contentAlignment = Alignment.Center
    ) {
      Text(initials, color = Color.White, fontSize = (size.value * 0.38f).sp, fontWeight = FontWeight.Medium)
    }
    if (url.startsWith("http")) {
      AsyncImage(
        model = url,
        contentDescription = name,
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(CircleShape)
      )
    }
    if (online) {
      Box(
        Modifier
          .align(Alignment.BottomEnd)
          .size(size * 0.28f)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.background)
          .padding(2.dp)
          .clip(CircleShape)
          .background(OnlineGreen)
      )
    }
  }
}

@Composable
fun CountBadge(count: Long, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
  if (count <= 0) return
  Box(
    modifier
      .heightIn(min = 20.dp)
      .widthIn(min = 20.dp)
      .clip(CircleShape)
      .background(color)
      .padding(horizontal = 6.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      if (count > 99) "99+" else count.toString(),
      color = Color.White,
      fontSize = 12.sp,
      fontWeight = FontWeight.SemiBold
    )
  }
}

@Composable
fun IOSEmptyState(
  icon: ImageVector,
  title: String,
  message: String,
  modifier: Modifier = Modifier
) {
  Column(
    modifier.fillMaxSize().padding(horizontal = 40.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Icon(icon, null, tint = IOS.secondaryLabel.copy(alpha = 0.6f), modifier = Modifier.size(56.dp))
    Spacer(Modifier.height(14.dp))
    Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
    Spacer(Modifier.height(6.dp))
    Text(message, fontSize = 15.sp, color = IOS.secondaryLabel, textAlign = TextAlign.Center)
  }
}

// ---------------------------------------------------------------- action sheet

data class SheetAction(
  val label: String,
  val destructive: Boolean = false,
  val onClick: () -> Unit
)

@Composable
fun IOSActionSheet(
  actions: List<SheetAction>,
  onDismiss: () -> Unit,
  title: String? = null
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Box(
      Modifier
        .fillMaxSize()
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null,
          onClick = onDismiss
        ),
      contentAlignment = Alignment.BottomCenter
    ) {
      Column(
        Modifier
          .padding(horizontal = 10.dp)
          .navigationBarsPadding()
          .padding(bottom = 8.dp)
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = {}
          )
      ) {
        Column(
          Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(IOS.groupedCard)
        ) {
          if (title != null) {
            Text(
              title,
              fontSize = 13.sp,
              color = IOS.secondaryLabel,
              textAlign = TextAlign.Center,
              modifier = Modifier.fillMaxWidth().padding(14.dp)
            )
          }
          actions.forEachIndexed { i, action ->
            if (i > 0 || title != null) HorizontalDivider(thickness = 0.5.dp, color = IOS.separator)
            Text(
              action.label,
              fontSize = 20.sp,
              color = if (action.destructive) DangerRed else MaterialTheme.colorScheme.primary,
              textAlign = TextAlign.Center,
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  onDismiss()
                  action.onClick()
                }
                .padding(vertical = 16.dp)
            )
          }
        }
        Spacer(Modifier.height(8.dp))
        Text(
          "Cancel",
          fontSize = 20.sp,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.primary,
          textAlign = TextAlign.Center,
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(IOS.groupedCard)
            .clickable(onClick = onDismiss)
            .padding(vertical = 16.dp)
        )
      }
    }
  }
}

// ---------------------------------------------------------------- tab bar

private data class TabSpec(
  val tab: MainTab,
  val label: String,
  val filled: ImageVector,
  val outlined: ImageVector
)

private val Tabs = listOf(
  TabSpec(MainTab.CHATS, "Chats", Icons.Filled.ChatBubble, Icons.Outlined.ChatBubbleOutline),
  TabSpec(MainTab.STATUS, "Status", Icons.Filled.DonutLarge, Icons.Outlined.DonutLarge),
  TabSpec(MainTab.FRIENDS, "Friends", Icons.Filled.Group, Icons.Outlined.Group),
  TabSpec(MainTab.SEARCH, "Search", Icons.Filled.Search, Icons.Outlined.Search),
  TabSpec(MainTab.PROFILE, "Profile", Icons.Filled.Person, Icons.Outlined.PersonOutline)
)

@Composable
fun IOSTabBar(
  selectedTab: MainTab,
  onTabSelected: (MainTab) -> Unit,
  unreadChatsCount: Long = 0L,
  pendingFriendRequestsCount: Int = 0
) {
  Column(Modifier.fillMaxWidth().background(IOS.bar).navigationBarsPadding()) {
    HorizontalDivider(thickness = 0.5.dp, color = IOS.separator)
    Row(Modifier.fillMaxWidth().height(50.dp)) {
      Tabs.forEach { spec ->
        val selected = spec.tab == selectedTab
        val tint = if (selected) MaterialTheme.colorScheme.primary else IOS.secondaryLabel
        val badge = when (spec.tab) {
          MainTab.CHATS -> unreadChatsCount
          MainTab.FRIENDS -> pendingFriendRequestsCount.toLong()
          else -> 0L
        }
        Column(
          Modifier
            .weight(1f)
            .fillMaxSize()
            .testTag("nav_${spec.label.lowercase()}")
            .clickable(
              interactionSource = remember { MutableInteractionSource() },
              indication = null
            ) { onTabSelected(spec.tab) },
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Box {
            Icon(
              if (selected) spec.filled else spec.outlined,
              contentDescription = spec.label,
              tint = tint,
              modifier = Modifier.size(26.dp)
            )
            if (badge > 0) {
              CountBadge(
                badge,
                Modifier.align(Alignment.TopEnd).padding(start = 16.dp),
                color = DangerRed
              )
            }
          }
          Text(spec.label, fontSize = 10.sp, color = tint, fontWeight = FontWeight.Medium)
        }
      }
    }
  }
}

// ---------------------------------------------------------------- formatting

private fun startOfDay(cal: Calendar): Long {
  val c = cal.clone() as Calendar
  c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
  c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
  return c.timeInMillis
}

/** Chat-list style timestamp: 14:32 / Yesterday / Mon / 12/03/26. */
fun formatListTime(ts: Timestamp?): String {
  val date = ts?.toDate() ?: return ""
  val today = startOfDay(Calendar.getInstance())
  val day = 24L * 60 * 60 * 1000
  val t = date.time
  return when {
    t >= today -> SimpleDateFormat("HH:mm", Locale.getDefault()).format(date)
    t >= today - day -> "Yesterday"
    t >= today - 6 * day -> SimpleDateFormat("EEEE", Locale.getDefault()).format(date)
    else -> SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(date)
  }
}

fun formatClock(ts: Timestamp?): String =
  ts?.toDate()?.let { SimpleDateFormat("HH:mm", Locale.getDefault()).format(it) } ?: ""

/** Centered day header inside a conversation. */
fun formatDayHeader(ts: Timestamp?): String {
  val date = ts?.toDate() ?: return ""
  val today = startOfDay(Calendar.getInstance())
  val day = 24L * 60 * 60 * 1000
  val clock = SimpleDateFormat("HH:mm", Locale.getDefault()).format(date)
  return when {
    date.time >= today -> "Today $clock"
    date.time >= today - day -> "Yesterday $clock"
    date.time >= today - 6 * day -> SimpleDateFormat("EEEE HH:mm", Locale.getDefault()).format(date)
    else -> SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(date)
  }
}

fun sameDay(a: Timestamp?, b: Timestamp?): Boolean {
  if (a == null || b == null) return false
  val fmt = SimpleDateFormat("yyyyMMdd", Locale.US)
  return fmt.format(a.toDate()) == fmt.format(b.toDate())
}

fun lastSeenText(isOnline: Boolean, lastSeen: Timestamp?): String {
  if (isOnline) return "Online"
  val date = lastSeen?.toDate() ?: return "Offline"
  val diff = System.currentTimeMillis() - date.time
  return when {
    diff < 60_000 -> "Last seen just now"
    diff < 3_600_000 -> "Last seen ${diff / 60_000} min ago"
    else -> "Last seen ${formatListTime(lastSeen).let { if (it.contains(":")) "today at $it" else it.lowercase(Locale.getDefault()) }}"
  }
}

// ---------------------------------------------------------------- switch / dialog

@Composable
fun IOSSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
  Switch(
    checked = checked,
    onCheckedChange = onCheckedChange,
    colors = SwitchDefaults.colors(
      checkedThumbColor = Color.White,
      checkedTrackColor = OnlineGreen,
      checkedBorderColor = OnlineGreen,
      uncheckedThumbColor = Color.White,
      uncheckedTrackColor = if (IOS.isDark) Color(0xFF39393D) else Color(0xFFE9E9EA),
      uncheckedBorderColor = Color.Transparent
    )
  )
}

/** Small centred dialog with one text field, used to edit a single account value. */
@Composable
fun IOSTextEditDialog(
  title: String,
  initial: String,
  placeholder: String,
  onDismiss: () -> Unit,
  onSave: (String) -> Unit,
  modifier: Modifier = Modifier,
  keyboardType: KeyboardType = KeyboardType.Text,
  prefix: String = "",
  maxLength: Int = 100
) {
  var value by remember { mutableStateOf(initial) }
  Dialog(onDismissRequest = onDismiss) {
    Column(
      modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .background(IOS.groupedCard)
        .padding(20.dp)
    ) {
      Text(
        title,
        fontSize = 17.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth()
      )
      Spacer(Modifier.height(14.dp))
      Row(
        Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(IOS.fill)
          .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (prefix.isNotEmpty()) Text(prefix, fontSize = 17.sp, color = IOS.secondaryLabel)
        Box(Modifier.weight(1f)) {
          if (value.isEmpty()) Text(placeholder, fontSize = 17.sp, color = IOS.secondaryLabel)
          BasicTextField(
            value = value,
            onValueChange = { value = it.take(maxLength) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            textStyle = TextStyle(fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            modifier = Modifier.fillMaxWidth().testTag("edit_field")
          )
        }
      }
      Spacer(Modifier.height(16.dp))
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        IOSTextButton("Cancel", onDismiss)
        IOSTextButton("Save", onClick = { onSave(value.trim()) }, bold = true)
      }
    }
  }
}
