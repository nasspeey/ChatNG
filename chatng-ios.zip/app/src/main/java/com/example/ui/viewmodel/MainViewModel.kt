package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Chat
import com.example.data.model.FriendRequest
import com.example.data.model.Message
import com.example.data.model.PrivacyKey
import com.example.data.model.PrivacyMode
import com.example.data.model.PrivacyRule
import com.example.data.model.PrivateData
import com.example.data.model.VisibleProfile
import com.example.data.model.Status
import com.example.data.model.User
import com.example.data.repository.ChatRepository
import com.example.data.repository.FriendRepository
import com.example.data.repository.FriendStatus
import com.example.data.repository.StatusRepository
import com.example.data.repository.ThemePreferencesRepository
import com.example.data.repository.UserRepository
import com.example.ui.navigation.MainTab
import com.example.ui.navigation.Screen
import com.example.ui.theme.AccentColor
import com.example.ui.theme.AppThemeMode
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

  val userRepository = UserRepository(application)
  val friendRepository = FriendRepository(application)
  val chatRepository = ChatRepository(application)
  val statusRepository = StatusRepository(application)
  val themePreferencesRepository = ThemePreferencesRepository(application)

  val themeMode: StateFlow<AppThemeMode> = themePreferencesRepository.themeModeFlow
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppThemeMode.SYSTEM)

  val accent: StateFlow<AccentColor> = themePreferencesRepository.accentFlow
    .stateIn(viewModelScope, SharingStarted.Eagerly, AccentColor.BLUE)
  val increaseContrast: StateFlow<Boolean> = themePreferencesRepository.increaseContrastFlow
    .stateIn(viewModelScope, SharingStarted.Eagerly, false)
  val animationsEnabled: StateFlow<Boolean> = themePreferencesRepository.animationsEnabledFlow
    .stateIn(viewModelScope, SharingStarted.Eagerly, true)

  private val auth: FirebaseAuth = Firebase.auth

  // ------------------------------------------------------------ navigation
  private val _currentScreen = MutableStateFlow<Screen>(Screen.Splash)
  val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

  private val _currentTab = MutableStateFlow(MainTab.CHATS)
  val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

  // ------------------------------------------------------------ data
  /** Public profile document exactly as stored. */
  private val _rawUser = MutableStateFlow<User?>(null)

  /** The signed-in user's protected data (photo, about, email, phone, privacy settings). */
  private val _private = MutableStateFlow(PrivateData())

  /** The signed-in user's full profile: public fields plus their own private ones. */
  val currentUser: StateFlow<User?> = combine(_rawUser, _private) { raw, priv ->
    raw?.copy(
      profileImage = priv.photo.ifBlank { raw.profileImage },
      bio = priv.about.ifBlank { raw.bio },
      email = priv.email.ifBlank { raw.email },
      phoneNumber = priv.phone.ifBlank { raw.phoneNumber }
    )
  }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

  val privacy: StateFlow<Map<PrivacyKey, PrivacyRule>> = _private
    .map { priv -> PrivacyKey.entries.associateWith { priv.rule(it) } }
    .stateIn(
      viewModelScope, SharingStarted.Eagerly,
      PrivacyKey.entries.associateWith { PrivacyRule(it.default) }
    )

  /** Other people's profile pictures that the privacy rules allowed us to read. */
  private val _photos = MutableStateFlow<Map<String, String>>(emptyMap())
  private val photoRequested = mutableSetOf<String>()

  private val _chats = MutableStateFlow<List<Chat>>(emptyList())
  val chats: StateFlow<List<Chat>> = _chats.asStateFlow()

  private val _friendUids = MutableStateFlow<List<String>>(emptyList())

  private val _incomingRequests = MutableStateFlow<List<FriendRequest>>(emptyList())
  val incomingRequests: StateFlow<List<FriendRequest>> = _incomingRequests.asStateFlow()

  private val _outgoingRequests = MutableStateFlow<List<FriendRequest>>(emptyList())
  val outgoingRequests: StateFlow<List<FriendRequest>> = _outgoingRequests.asStateFlow()

  private val _blockedUids = MutableStateFlow<Set<String>>(emptySet())
  val blockedUids: StateFlow<Set<String>> = _blockedUids.asStateFlow()

  private val _statuses = MutableStateFlow<List<Status>>(emptyList())
  val statuses: StateFlow<List<Status>> = _statuses.asStateFlow()

  /** Live profiles for chat partners, friends and blocked users. */
  private val _liveUsers = MutableStateFlow<Map<String, User>>(emptyMap())
  /** Profiles seen in search results (static snapshot). */
  private val _cachedUsers = MutableStateFlow<Map<String, User>>(emptyMap())

  val userMap: StateFlow<Map<String, User>> =
    combine(_cachedUsers, _liveUsers, _photos) { cached, live, photos ->
      (cached + live).mapValues { (uid, user) ->
        photos[uid]?.takeIf { it.isNotBlank() }?.let { user.copy(profileImage = it) } ?: user
      }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

  val friends: StateFlow<List<User>> =
    combine(_friendUids, userMap) { uids, map -> uids.mapNotNull { map[it] }.sortedBy { it.name.lowercase() } }
      .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _searchResults = MutableStateFlow<List<User>>(emptyList())
  val searchResults: StateFlow<List<User>> = _searchResults.asStateFlow()

  private val _activeChatMessages = MutableStateFlow<List<Message>>(emptyList())
  val activeChatMessages: StateFlow<List<Message>> = _activeChatMessages.asStateFlow()

  private val _viewedProfile = MutableStateFlow<VisibleProfile?>(null)
  val viewedProfile: StateFlow<VisibleProfile?> = _viewedProfile.asStateFlow()
  private var profileReturn: Screen = Screen.MainTabs
  private var migrationDone = false

  private val _isUploading = MutableStateFlow(false)
  val isUploading: StateFlow<Boolean> = _isUploading.asStateFlow()

  private val _toast = MutableSharedFlow<String>(extraBufferCapacity = 8)
  val toast: SharedFlow<String> = _toast.asSharedFlow()

  private var activeChatJob: Job? = null
  private var activeSearchJob: Job? = null
  private var userObserverJob: Job? = null
  private val dataJobs = mutableListOf<Job>()

  init {
    auth.addAuthStateListener { firebaseAuth ->
      val user = firebaseAuth.currentUser
      if (user != null) onUserAuthenticated(user.uid) else onUserLoggedOut()
    }
  }

  /** Runs [block]; failures become a toast instead of crashing the app. */
  private fun launchSafe(errorMessage: String? = null, block: suspend () -> Unit) {
    viewModelScope.launch {
      try {
        block()
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        val denied = e.message?.contains("PERMISSION_DENIED", ignoreCase = true) == true
        _toast.tryEmit(
          when {
            errorMessage != null && denied -> "$errorMessage. You may not have permission."
            errorMessage != null -> errorMessage
            else -> e.localizedMessage ?: "Something went wrong"
          }
        )
      }
    }
  }

  // ------------------------------------------------------------ navigation
  fun navigateTo(screen: Screen) {
    _currentScreen.value = screen
  }

  fun selectTab(tab: MainTab) {
    _currentTab.value = tab
    _currentScreen.value = Screen.MainTabs
  }

  fun onSplashComplete() {
    val user = auth.currentUser
    _currentScreen.value = when {
      user == null -> Screen.SignIn
      _rawUser.value != null -> Screen.MainTabs
      else -> Screen.ProfileSetup
    }
  }

  // ------------------------------------------------------------ auth lifecycle
  fun onUserAuthenticated(uid: String) {
    userObserverJob?.cancel()
    userObserverJob = viewModelScope.launch {
      userRepository.observeUser(uid).collectLatest { profile ->
        _rawUser.value = profile
        if (profile == null) {
          if (_currentScreen.value !is Screen.ProfileSetup) _currentScreen.value = Screen.ProfileSetup
        } else {
          userRepository.updatePresence(uid, true)
          userRepository.registerDevice()
          if (_currentScreen.value is Screen.Splash || _currentScreen.value is Screen.SignIn) {
            _currentScreen.value = Screen.MainTabs
          }
        }
      }
    }
    startDataObservers(uid)
  }

  private fun startDataObservers(uid: String) {
    dataJobs.forEach { it.cancel() }
    dataJobs.clear()

    dataJobs += viewModelScope.launch {
      userRepository.observePrivate(uid).collectLatest { _private.value = it }
    }
    // Move pre-privacy profiles (public email/phone/bio/photo) into protected documents once.
    dataJobs += viewModelScope.launch {
      combine(_rawUser, _private) { raw, priv -> raw to priv }.collectLatest { (raw, priv) ->
        if (!migrationDone && raw != null && priv.loaded) {
          migrationDone = true
          userRepository.migrateLegacyProfile(raw, priv)
        }
      }
    }
    dataJobs += viewModelScope.launch {
      chatRepository.observeChats(uid).collectLatest { _chats.value = it }
    }
    dataJobs += viewModelScope.launch {
      friendRepository.observeIncomingRequests(uid).collectLatest { _incomingRequests.value = it }
    }
    dataJobs += viewModelScope.launch {
      friendRepository.observeOutgoingRequests(uid).collectLatest { _outgoingRequests.value = it }
    }
    dataJobs += viewModelScope.launch {
      friendRepository.observeFriends(uid).collectLatest { list ->
        _friendUids.value = list.map { it.friendUid }
      }
    }
    dataJobs += viewModelScope.launch {
      friendRepository.observeBlocked(uid).collectLatest { _blockedUids.value = it }
    }
    dataJobs += viewModelScope.launch {
      statusRepository.observeStatuses(uid).collectLatest { _statuses.value = it }
    }
    // Keep live profiles only for the people that matter right now.
    dataJobs += viewModelScope.launch {
      combine(_chats, _friendUids, _blockedUids, _incomingRequests, _outgoingRequests) { chats, friendUids, blocked, inc, out ->
        (chats.flatMap { it.participants } + friendUids + blocked +
          inc.map { it.senderId } + out.map { it.receiverId }).filter { it != uid }.toSet()
      }.distinctUntilChanged().collectLatest { ids ->
        loadPhotos(ids)
        userRepository.observeUsers(ids).collect { users ->
          _liveUsers.value = users.associateBy { it.uid }
        }
      }
    }
  }

  fun onUserLoggedOut() {
    dataJobs.forEach { it.cancel() }
    dataJobs.clear()
    userObserverJob?.cancel()
    activeChatJob?.cancel()
    _rawUser.value = null
    _private.value = PrivateData()
    _photos.value = emptyMap()
    photoRequested.clear()
    migrationDone = false
    _viewedProfile.value = null
    _chats.value = emptyList()
    _friendUids.value = emptyList()
    _incomingRequests.value = emptyList()
    _outgoingRequests.value = emptyList()
    _blockedUids.value = emptySet()
    _statuses.value = emptyList()
    _liveUsers.value = emptyMap()
    _cachedUsers.value = emptyMap()
    _searchResults.value = emptyList()
    _activeChatMessages.value = emptyList()
    _currentScreen.value = Screen.SignIn
  }

  fun signOut() {
    val uid = auth.currentUser?.uid
    viewModelScope.launch {
      if (uid != null) {
        userRepository.updatePresence(uid, false)
        userRepository.unregisterDevice()
      }
      auth.signOut()
    }
  }

  fun setPresence(isOnline: Boolean) {
    val uid = auth.currentUser?.uid ?: return
    if (_rawUser.value == null) return
    viewModelScope.launch { userRepository.updatePresence(uid, isOnline) }
  }

  // ------------------------------------------------------------ search / friends
  fun setSearchQuery(query: String) {
    _searchQuery.value = query
    activeSearchJob?.cancel()
    activeSearchJob = viewModelScope.launch {
      userRepository.searchUsersByUserId(query).collectLatest { results ->
        _searchResults.value = results
        if (results.isNotEmpty()) {
          _cachedUsers.value = _cachedUsers.value + results.associateBy { it.uid }
          loadPhotos(results.map { it.uid })
        }
      }
    }
  }

  fun getFriendStatus(otherUid: String): FriendStatus = when {
    _friendUids.value.contains(otherUid) -> FriendStatus.FRIENDS
    _outgoingRequests.value.any { it.receiverId == otherUid } -> FriendStatus.REQUEST_SENT
    _incomingRequests.value.any { it.senderId == otherUid } -> FriendStatus.REQUEST_RECEIVED
    else -> FriendStatus.NONE
  }

  fun sendFriendRequest(targetUid: String) = launchSafe("Couldn't send friend request") {
    friendRepository.sendFriendRequest(targetUid)
    _toast.tryEmit("Friend request sent")
  }

  fun acceptFriendRequest(req: FriendRequest) = launchSafe("Couldn't accept request") {
    friendRepository.acceptFriendRequest(req.requestId, req.senderId, req.receiverId)
  }

  fun rejectFriendRequest(req: FriendRequest) = launchSafe("Couldn't decline request") {
    friendRepository.rejectFriendRequest(req.requestId)
  }

  fun unfriend(uid: String) = launchSafe("Couldn't remove friend") {
    friendRepository.unfriend(uid)
  }

  fun blockUser(uid: String) = launchSafe("Couldn't block user") {
    friendRepository.blockUser(uid)
    _toast.tryEmit("User blocked")
  }

  fun unblockUser(uid: String) = launchSafe("Couldn't unblock user") {
    friendRepository.unblockUser(uid)
  }

  // ------------------------------------------------------------ chat
  fun openChat(chat: Chat, otherUser: User?) {
    val myUid = auth.currentUser?.uid ?: return
    val otherUid = otherUser?.uid ?: chat.participants.firstOrNull { it != myUid } ?: return
    val known = otherUser ?: userMap.value[otherUid]
    showChat(chat.chatId, otherUid, known)
  }

  fun startChatWithUser(user: User) = launchSafe("Couldn't open chat") {
    val chatId = chatRepository.getOrCreateChatId(user.uid)
    showChat(chatId, user.uid, user)
  }

  private fun showChat(chatId: String, otherUid: String, user: User?) {
    subscribeToChatMessages(chatId)
    _currentScreen.value = Screen.ChatConversation(
      chatId = chatId,
      otherUid = otherUid,
      otherName = user?.name ?: "Chat",
      otherUserId = user?.userId ?: "",
      otherAvatar = user?.profileImage ?: "",
      isOnline = user?.isOnline ?: false
    )
  }

  fun closeChat(chatId: String?) {
    if (chatId != null) viewModelScope.launch { chatRepository.setTyping(chatId, false) }
    activeChatJob?.cancel()
    _activeChatMessages.value = emptyList()
    _currentScreen.value = Screen.MainTabs
  }

  private fun subscribeToChatMessages(chatId: String) {
    activeChatJob?.cancel()
    _activeChatMessages.value = emptyList()
    activeChatJob = viewModelScope.launch {
      chatRepository.observeMessages(chatId).collectLatest { _activeChatMessages.value = it }
    }
  }

  fun sendMessage(chatId: String, text: String, type: String = "text") =
    launchSafe("Message couldn't be sent") { chatRepository.sendMessage(chatId, text, type) }

  fun sendImage(chatId: String, uri: Uri) = launchSafe("Photo couldn't be sent") {
    _isUploading.value = true
    try {
      chatRepository.sendImage(chatId, uri)
    } finally {
      _isUploading.value = false
    }
  }

  fun deleteMessage(messageId: String) = launchSafe("Couldn't unsend message") {
    chatRepository.deleteMessage(messageId)
  }

  fun setTyping(chatId: String, typing: Boolean) {
    viewModelScope.launch { chatRepository.setTyping(chatId, typing) }
  }

  fun markActiveChatSeen(chatId: String) {
    viewModelScope.launch { chatRepository.markChatSeen(chatId) }
  }

  fun togglePinChat(chatId: String) = launchSafe {
    val myUid = auth.currentUser?.uid
    val wasPinned = _chats.value.firstOrNull { it.chatId == chatId }?.pinnedBy?.contains(myUid) == true
    val nowPinned = chatRepository.togglePinChat(chatId)
    if (!wasPinned && !nowPinned) _toast.tryEmit("You can pin up to 3 chats")
  }

  // ------------------------------------------------------------ status
  fun postStatus(text: String, imageUri: Uri?) = launchSafe("Couldn't post status") {
    _isUploading.value = true
    try {
      val rule = _private.value.rule(PrivacyKey.STATUS)
      val viewers = when (rule.mode) {
        PrivacyMode.ONLY_ME -> emptyList()
        PrivacyMode.FRIENDS_EXCEPT -> _friendUids.value.filter { it !in rule.excluded }
        else -> _friendUids.value
      }
      statusRepository.postStatus(text, imageUri, viewers)
    } finally {
      _isUploading.value = false
    }
  }

  fun deleteStatus(statusId: String) = launchSafe("Couldn't delete status") {
    statusRepository.deleteStatus(statusId)
  }

  // ------------------------------------------------------------ other people's profiles
  /** Fetches profile pictures once per session; the rules decide which ones come back. */
  private fun loadPhotos(uids: Collection<String>) {
    val me = auth.currentUser?.uid
    val todo = uids.filter { it.isNotBlank() && it != me && photoRequested.add(it) }
    if (todo.isEmpty()) return
    viewModelScope.launch {
      val fetched = todo.map { uid -> async { uid to userRepository.getPhoto(uid) } }.map { it.await() }
      _photos.value = _photos.value + fetched.toMap()
    }
  }

  fun openUserProfile(uid: String) {
    profileReturn = _currentScreen.value
    _viewedProfile.value = null
    _currentScreen.value = Screen.UserProfile(uid)
    viewModelScope.launch {
      _viewedProfile.value = userRepository.getVisibleProfile(uid)
    }
  }

  fun closeUserProfile() {
    _viewedProfile.value = null
    _currentScreen.value = profileReturn
  }

  // ------------------------------------------------------------ account settings
  private fun updateProfile(successMessage: String, errorMessage: String, transform: (User) -> User) =
    launchSafe(errorMessage) {
      val user = currentUser.value ?: return@launchSafe
      userRepository.saveProfile(transform(user))
      _toast.tryEmit(successMessage)
    }

  fun updateProfilePhoto(uri: Uri) = launchSafe("Couldn't update your photo") {
    val user = currentUser.value ?: return@launchSafe
    _isUploading.value = true
    try {
      userRepository.saveProfile(user.copy(profileImage = uri.toString()))
      _toast.tryEmit("Profile picture updated")
    } finally {
      _isUploading.value = false
    }
  }

  fun updateName(name: String) {
    if (name.isBlank()) { _toast.tryEmit("Name can't be empty"); return }
    updateProfile("Name updated", "Couldn't update your name") { it.copy(name = name.trim()) }
  }

  fun updateUsername(input: String) = launchSafe("Couldn't update your username") {
    val clean = input.trim().removePrefix("@").lowercase()
    if (!Regex("^[a-z0-9_.]{3,30}$").matches(clean)) {
      _toast.tryEmit("Use 3–30 letters, numbers, dots or underscores")
      return@launchSafe
    }
    val user = currentUser.value ?: return@launchSafe
    if (clean == user.userId) return@launchSafe
    if (!userRepository.isUserIdAvailable(clean, user.uid)) {
      _toast.tryEmit("@$clean is already taken")
      return@launchSafe
    }
    userRepository.saveProfile(user.copy(userId = clean))
    _toast.tryEmit("Username updated")
  }

  fun updateEmail(email: String) {
    if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
      _toast.tryEmit("Enter a valid email address"); return
    }
    updateProfile("Email updated", "Couldn't update your email") { it.copy(email = email) }
  }

  fun updatePhone(phone: String) {
    val digits = phone.count { it.isDigit() }
    if (digits < 7 || digits > 15 || !android.util.Patterns.PHONE.matcher(phone).matches()) {
      _toast.tryEmit("Enter a valid phone number"); return
    }
    updateProfile("Phone number updated", "Couldn't update your phone number") { it.copy(phoneNumber = phone) }
  }

  // ------------------------------------------------------------ privacy
  fun setPrivacy(key: PrivacyKey, mode: PrivacyMode, excluded: List<String>) =
    launchSafe("Couldn't save your privacy setting") {
      val kept = if (mode.usesExceptions) excluded.distinct() else emptyList()
      userRepository.savePrivacy(key, PrivacyRule(mode, kept))
    }

  // ------------------------------------------------------------ settings
  fun setThemeMode(mode: AppThemeMode) {
    viewModelScope.launch { themePreferencesRepository.setThemeMode(mode) }
  }

  fun setAccent(accent: AccentColor) {
    viewModelScope.launch { themePreferencesRepository.setAccent(accent) }
  }

  fun setIncreaseContrast(enabled: Boolean) {
    viewModelScope.launch { themePreferencesRepository.setIncreaseContrast(enabled) }
  }

  fun setAnimationsEnabled(enabled: Boolean) {
    viewModelScope.launch { themePreferencesRepository.setAnimationsEnabled(enabled) }
  }
}
