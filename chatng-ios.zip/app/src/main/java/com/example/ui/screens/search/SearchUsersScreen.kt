package com.example.ui.screens.search

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.data.repository.FriendStatus
import com.example.ui.components.Avatar
import com.example.ui.components.IOS
import com.example.ui.components.IOSDivider
import com.example.ui.components.IOSEmptyState
import com.example.ui.components.IOSLargeTitle
import com.example.ui.components.IOSNavBar
import com.example.ui.components.IOSSearchField
import com.example.ui.screens.friends.Pill

@Composable
fun SearchUsersScreen(
  searchResults: List<User>,
  searchQuery: String,
  blockedUids: Set<String>,
  onQueryChange: (String) -> Unit,
  onSendFriendRequest: (String) -> Unit,
  onStartChat: (User) -> Unit,
  onOpenRequests: () -> Unit,
  onViewProfile: (User) -> Unit,
  getFriendStatus: (String) -> FriendStatus,
  onBack: () -> Unit,
  isEmbeddedInTab: Boolean,
  modifier: Modifier = Modifier
) {
  if (!isEmbeddedInTab) BackHandler(onBack = onBack)
  val visible = searchResults.filter { it.uid !in blockedUids }

  Column(modifier.fillMaxSize()) {
    if (isEmbeddedInTab) IOSLargeTitle("Search")
    else IOSNavBar(title = "Search", onBack = onBack)

    IOSSearchField(
      value = searchQuery,
      onValueChange = onQueryChange,
      placeholder = "Search by @handle",
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
    )

    if (visible.isEmpty()) {
      IOSEmptyState(
        icon = Icons.Outlined.Search,
        title = if (searchQuery.isBlank()) "Find People" else "No Results",
        message = if (searchQuery.isBlank()) "Type a @handle to find friends." else "No one matches \"$searchQuery\"."
      )
    } else {
      LazyColumn(Modifier.fillMaxSize()) {
        items(visible, key = { it.uid }) { user ->
          val status = getFriendStatus(user.uid)
          Column {
            Row(
              Modifier.fillMaxWidth().clickable { onViewProfile(user) }.padding(horizontal = 16.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Avatar(user.profileImage, user.name, 46.dp, online = user.isOnline)
              Spacer(Modifier.width(12.dp))
              Column(Modifier.weight(1f)) {
                Text(
                  user.name,
                  fontSize = 17.sp,
                  fontWeight = FontWeight.Medium,
                  color = MaterialTheme.colorScheme.onSurface,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                Text("@${user.userId}", fontSize = 14.sp, color = IOS.secondaryLabel, maxLines = 1)
              }
              when (status) {
                FriendStatus.NONE -> Pill("Add", filled = true) { onSendFriendRequest(user.uid) }
                FriendStatus.REQUEST_SENT -> Pill("Requested", filled = false, enabled = false) {}
                FriendStatus.REQUEST_RECEIVED -> Pill("Respond", filled = true) { onOpenRequests() }
                FriendStatus.FRIENDS -> Pill("Message", filled = false) { onStartChat(user) }
              }
            }
            IOSDivider(startInset = 74.dp)
          }
        }
      }
    }
  }
}
