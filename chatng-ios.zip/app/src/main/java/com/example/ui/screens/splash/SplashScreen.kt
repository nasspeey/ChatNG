package com.example.ui.screens.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BottomWaveGraphic
import com.example.ui.components.ChatNGBubbleLogo
import com.example.ui.components.TopWaveGraphic
import com.example.ui.theme.BrandBlue
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
  onTimeout: () -> Unit
) {
  val scale = remember { Animatable(0.85f) }
  val alpha = remember { Animatable(0f) }

  LaunchedEffect(Unit) {
    scale.animateTo(1f, animationSpec = tween(700))
    alpha.animateTo(1f, animationSpec = tween(600))
    delay(900)
    onTimeout()
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.surface)
      .testTag("splash_screen")
  ) {
    // Top wave
    TopWaveGraphic(
      modifier = Modifier.align(Alignment.TopCenter),
      height = 180.dp
    )

    // Center Branding
    Column(
      modifier = Modifier
        .align(Alignment.Center)
        .scale(scale.value)
        .alpha(alpha.value),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      ChatNGBubbleLogo(size = 96.dp)

      Spacer(modifier = Modifier.height(18.dp))

      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "Chat",
          fontSize = 38.sp,
          fontWeight = FontWeight.ExtraBold,
          color = MaterialTheme.colorScheme.onSurface,
          letterSpacing = (-0.5).sp
        )
        Text(
          text = "NG",
          fontSize = 38.sp,
          fontWeight = FontWeight.ExtraBold,
          color = BrandBlue,
          letterSpacing = (-0.5).sp
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "Connect. Chat. Share.",
        fontSize = 15.sp,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        letterSpacing = 0.3.sp
      )
    }

    // Bottom wave
    BottomWaveGraphic(
      modifier = Modifier.align(Alignment.BottomCenter),
      height = 200.dp
    )
  }
}
