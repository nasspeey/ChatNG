package com.example.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.ui.components.Avatar
import com.example.ui.components.IOS
import com.example.ui.components.IOSDivider
import com.example.ui.components.IOSIconBadge
import com.example.ui.components.IOSLargeTitle
import com.example.ui.components.IOSRow
import com.example.ui.components.IOSSection

@Composable
fun ProfileScreen(
  user: User?,
  friendsCount: Int,
  chatsCount: Int,
  onEditProfile: () -> Unit,
  onOpenSettings: () -> Unit,
  modifier: Modifier = Modifier
) {
  val clipboard = LocalClipboardManager.current
  var copied by remember { mutableStateOf(false) }

  Column(modifier.fillMaxSize().background(IOS.groupedBg)) {
    IOSLargeTitle("Profile")

    Column(Modifier.verticalScroll(rememberScrollState())) {
      // Header card
      Column(
        Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 10.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(IOS.groupedCard)
          .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Avatar(user?.profileImage ?: "", user?.name ?: "?", 96.dp)
        Spacer(Modifier.height(12.dp))
        Text(
          user?.name ?: "",
          fontSize = 24.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text("@${user?.userId ?: ""}", fontSize = 16.sp, color = IOS.secondaryLabel)
        if (!user?.bio.isNullOrBlank()) {
          Spacer(Modifier.height(10.dp))
          Text(
            user?.bio ?: "",
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
          )
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
          Stat(friendsCount.toString(), "Friends")
          Stat(chatsCount.toString(), "Chats")
        }
      }

      IOSSection {
        IOSRow(
          title = "Edit Profile",
          leading = { IOSIconBadge(Icons.Outlined.Edit, Color(0xFF007AFF)) },
          chevron = true,
          dividerInset = 57.dp,
          onClick = onEditProfile
        )
        IOSRow(
          title = "Copy my @handle",
          leading = { IOSIconBadge(Icons.Outlined.ContentCopy, Color(0xFF5E5CE6)) },
          value = if (copied) "Copied" else null,
          dividerInset = 57.dp,
          onClick = {
            clipboard.setText(AnnotatedString("@${user?.userId ?: ""}"))
            copied = true
          }
        )
        IOSRow(
          title = "Settings",
          leading = { IOSIconBadge(Icons.Outlined.Settings, Color(0xFF8E8E93)) },
          chevron = true,
          showDivider = false,
          onClick = onOpenSettings
        )
      }

      val email = user?.email.orEmpty()
      val phone = user?.phoneNumber.orEmpty()
      if (email.isNotBlank() || phone.isNotBlank()) {
        IOSSection(header = "Account") {
          if (email.isNotBlank()) IOSRow(title = "Email", value = email, showDivider = phone.isNotBlank())
          if (phone.isNotBlank()) IOSRow(title = "Phone", value = phone, showDivider = false)
        }
      }
      Spacer(Modifier.height(24.dp))
    }
  }
}

@Composable
private fun Stat(value: String, label: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    Text(label, fontSize = 13.sp, color = IOS.secondaryLabel)
  }
}
