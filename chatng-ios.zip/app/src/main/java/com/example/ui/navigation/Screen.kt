package com.example.ui.navigation

sealed class Screen {
  object Splash : Screen()
  object SignIn : Screen()
  object ProfileSetup : Screen()
  object MainTabs : Screen()
  data class ChatConversation(
    val chatId: String,
    val otherUid: String,
    val otherName: String,
    val otherUserId: String,
    val otherAvatar: String,
    val isOnline: Boolean
  ) : Screen()
  object FriendRequests : Screen()
  object SearchUsers : Screen()
  object EditProfile : Screen()
  object Settings : Screen()
  object BlockedUsers : Screen()
  object ThemeSettings : Screen()
  object Privacy : Screen()
  data class PrivacySetting(val key: com.example.data.model.PrivacyKey) : Screen()
  data class UserProfile(val uid: String) : Screen()
}

enum class MainTab {
  CHATS,
  STATUS,
  FRIENDS,
  SEARCH,
  PROFILE
}
