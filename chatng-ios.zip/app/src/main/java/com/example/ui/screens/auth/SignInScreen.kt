package com.example.ui.screens.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.ui.components.BottomWaveGraphic
import com.example.ui.components.ChatNGBubbleLogo
import com.example.ui.components.TopWaveGraphic
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

@Composable
fun SignInScreen(
  onAuthSuccess: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember { CredentialManager.create(context) }

  var phoneNumber by remember { mutableStateOf("") }
  var otpCode by remember { mutableStateOf("") }
  var verificationId by remember { mutableStateOf<String?>(null) }
  var isAwaitingOtp by remember { mutableStateOf(false) }

  var isLoading by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  fun onGoogleSignIn() {
    isLoading = true
    errorMessage = null

    val clientId = try {
      context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
      isLoading = false
      errorMessage = "Google Sign-In configuration missing: default_web_client_id not found"
      return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

    scope.launch {
      try {
        val result = credentialManager.getCredential(context as Activity, request)
        val credential = result.credential
        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
          val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
          val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
          Firebase.auth.signInWithCredential(authCredential).await()
          isLoading = false
          onAuthSuccess()
        } else {
          isLoading = false
          errorMessage = "Unexpected credential format"
        }
      } catch (e: GetCredentialCancellationException) {
        Log.w("Auth", "Google Sign-In flow cancelled: ${e.message}", e)
        isLoading = false
      } catch (e: Exception) {
        Log.e("Auth", "Google Sign-In failed", e)
        isLoading = false
        errorMessage = e.localizedMessage ?: "Sign in failed"
      }
    }
  }

  fun sendPhoneOtp() {
    val cleanPhone = phoneNumber.trim()
    if (cleanPhone.length < 8) {
      errorMessage = "Please enter a valid phone number with country code"
      return
    }

    isLoading = true
    errorMessage = null

    val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
      override fun onVerificationCompleted(credential: PhoneAuthCredential) {
        scope.launch {
          try {
            Firebase.auth.signInWithCredential(credential).await()
            isLoading = false
            onAuthSuccess()
          } catch (e: Exception) {
            isLoading = false
            errorMessage = e.localizedMessage ?: "Phone authentication failed"
          }
        }
      }

      override fun onVerificationFailed(e: FirebaseException) {
        isLoading = false
        errorMessage = e.localizedMessage ?: "Verification failed. Check phone format."
      }

      override fun onCodeSent(
        vId: String,
        token: PhoneAuthProvider.ForceResendingToken
      ) {
        isLoading = false
        verificationId = vId
        isAwaitingOtp = true
      }
    }

    val options = PhoneAuthOptions.newBuilder(Firebase.auth)
      .setPhoneNumber(if (cleanPhone.startsWith("+")) cleanPhone else "+$cleanPhone")
      .setTimeout(60L, TimeUnit.SECONDS)
      .setActivity(context as Activity)
      .setCallbacks(callbacks)
      .build()

    PhoneAuthProvider.verifyPhoneNumber(options)
  }

  fun verifyOtp() {
    val vId = verificationId ?: return
    val code = otpCode.trim()
    if (code.length < 6) {
      errorMessage = "Please enter the 6-digit OTP code"
      return
    }

    isLoading = true
    errorMessage = null

    scope.launch {
      try {
        val credential = PhoneAuthProvider.getCredential(vId, code)
        Firebase.auth.signInWithCredential(credential).await()
        isLoading = false
        onAuthSuccess()
      } catch (e: Exception) {
        isLoading = false
        errorMessage = e.localizedMessage ?: "Invalid verification code"
      }
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.surface)
      .testTag("signin_screen")
  ) {
    TopWaveGraphic(
      modifier = Modifier.align(Alignment.TopCenter),
      height = 150.dp
    )

    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 28.dp)
        .imePadding(),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Spacer(modifier = Modifier.height(60.dp))

      // Logo
      ChatNGBubbleLogo(size = 80.dp)

      Spacer(modifier = Modifier.height(20.dp))

      // Headings
      Text(
        text = "Welcome Back",
        fontSize = 26.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
        letterSpacing = (-0.3).sp
      )

      Text(
        text = if (isAwaitingOtp) "Enter the OTP sent to $phoneNumber" else "Sign in to continue",
        fontSize = 14.sp,
        fontWeight = FontWeight.Normal,
        color = Slate500,
        modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
      )

      // Phone Input / OTP form
      if (!isAwaitingOtp) {
        OutlinedTextField(
          value = phoneNumber,
          onValueChange = {
            phoneNumber = it
            errorMessage = null
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("phone_input"),
          placeholder = { Text("Enter Phone Number (e.g. +1234567890)", fontSize = 14.sp, color = Slate400) },
          leadingIcon = {
            Icon(
              imageVector = Icons.Default.Phone,
              contentDescription = "Phone",
              tint = Slate400,
              modifier = Modifier.size(20.dp)
            )
          },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          shape = RoundedCornerShape(14.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BrandBlue,
            unfocusedBorderColor = Slate200,
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
          )
        )

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = { sendPhoneOtp() },
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .shadow(6.dp, CircleShape, spotColor = BrandBlue.copy(alpha = 0.4f))
            .testTag("continue_phone_button"),
          shape = CircleShape,
          colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
          enabled = !isLoading
        ) {
          if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
          } else {
            Text("Continue", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
          }
        }
      } else {
        // OTP Input
        OutlinedTextField(
          value = otpCode,
          onValueChange = {
            if (it.length <= 6) otpCode = it
            errorMessage = null
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("otp_input"),
          placeholder = { Text("Enter 6-digit OTP", fontSize = 14.sp, color = Slate400) },
          leadingIcon = {
            Icon(
              imageVector = Icons.Outlined.Lock,
              contentDescription = "Lock",
              tint = Slate400,
              modifier = Modifier.size(20.dp)
            )
          },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          shape = RoundedCornerShape(14.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BrandBlue,
            unfocusedBorderColor = Slate200,
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
          )
        )

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = { verifyOtp() },
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("verify_otp_button"),
          shape = CircleShape,
          colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
          enabled = !isLoading
        ) {
          if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
          } else {
            Text("Verify OTP", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = "Change Phone Number",
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium,
          color = BrandBlue,
          modifier = Modifier
            .clickable { isAwaitingOtp = false }
            .padding(8.dp)
        )
      }

      // Error message
      if (errorMessage != null) {
        Text(
          text = errorMessage ?: "",
          color = MaterialTheme.colorScheme.error,
          fontSize = 13.sp,
          textAlign = TextAlign.Center,
          modifier = Modifier.padding(top = 10.dp)
        )
      }

      // Divider "or"
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        HorizontalDivider(modifier = Modifier.weight(1f), color = Slate200)
        Text(
          text = "or",
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
          color = Slate400,
          modifier = Modifier.padding(horizontal = 12.dp)
        )
        HorizontalDivider(modifier = Modifier.weight(1f), color = Slate200)
      }

      // Google Sign In Button
      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .clip(CircleShape)
          .border(1.dp, Slate200, CircleShape)
          .clickable(enabled = !isLoading) { onGoogleSignIn() }
          .testTag("google_login_button"),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surface
      ) {
        Row(
          modifier = Modifier.fillMaxSize(),
          horizontalArrangement = Arrangement.Center,
          verticalAlignment = Alignment.CenterVertically
        ) {
          GoogleIconG(modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Continue with Gmail",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }

      Spacer(modifier = Modifier.height(90.dp))
    }

    BottomWaveGraphic(
      modifier = Modifier.align(Alignment.BottomCenter),
      height = 100.dp
    )
  }
}

@Composable
fun GoogleIconG(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height

    // Draw Google Quad-Color G icon
    val blue = Color(0xFF4285F4)
    val red = Color(0xFFEA4335)
    val yellow = Color(0xFFFBBC05)
    val green = Color(0xFF34A853)

    // Center horizontal bar
    drawLine(
      color = blue,
      start = Offset(w * 0.5f, h * 0.5f),
      end = Offset(w * 0.95f, h * 0.5f),
      strokeWidth = w * 0.18f
    )

    // Arcs
    val stroke = androidx.compose.ui.graphics.drawscope.Stroke(width = w * 0.18f)
    drawArc(
      color = blue,
      startAngle = -45f,
      sweepAngle = 90f,
      useCenter = false,
      style = stroke
    )
    drawArc(
      color = green,
      startAngle = 45f,
      sweepAngle = 90f,
      useCenter = false,
      style = stroke
    )
    drawArc(
      color = yellow,
      startAngle = 135f,
      sweepAngle = 90f,
      useCenter = false,
      style = stroke
    )
    drawArc(
      color = red,
      startAngle = 225f,
      sweepAngle = 90f,
      useCenter = false,
      style = stroke
    )
  }
}
