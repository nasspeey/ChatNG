package com.example.ui.screens.friends

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.ui.components.Avatar
import com.example.ui.components.CountBadge
import com.example.ui.components.IOS
import com.example.ui.components.IOSActionSheet
import com.example.ui.components.IOSDivider
import com.example.ui.components.IOSEmptyState
import com.example.ui.components.IOSLargeTitle
import com.example.ui.components.IOSSearchField
import com.example.ui.components.SheetAction
import com.example.ui.components.lastSeenText
import com.example.ui.theme.DangerRed

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FriendsScreen(
  friends: List<User>,
  pendingRequestCount: Int,
  onOpenRequests: () -> Unit,
  onMessageFriend: (User) -> Unit,
  onViewProfile: (User) -> Unit,
  onUnfriend: (User) -> Unit,
  onBlock: (User) -> Unit,
  modifier: Modifier = Modifier
) {
  var query by remember { mutableStateOf("") }
  var sheetFor by remember { mutableStateOf<User?>(null) }

  val filtered = remember(friends, query) {
    friends.filter {
      query.isBlank() ||
        it.name.contains(query, ignoreCase = true) ||
        it.userId.contains(query.removePrefix("@"), ignoreCase = true)
    }
  }

  Column(modifier.fillMaxSize()) {
    IOSLargeTitle("Friends")
    IOSSearchField(
      value = query,
      onValueChange = { query = it },
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
    )

    if (query.isBlank()) {
      Column {
        Row(
          Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onOpenRequests)
            .padding(horizontal = 16.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            Icons.Filled.Group,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.width(30.dp)
          )
          Spacer(Modifier.width(12.dp))
          Text(
            "Friend Requests",
            fontSize = 17.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
          )
          CountBadge(pendingRequestCount.toLong(), color = DangerRed)
          Icon(
            Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = IOS.secondaryLabel.copy(alpha = 0.7f),
            modifier = Modifier.padding(start = 8.dp).width(13.dp)
          )
        }
        IOSDivider()
      }
    }

    if (filtered.isEmpty()) {
      IOSEmptyState(
        icon = Icons.Outlined.Group,
        title = if (query.isBlank()) "No Friends Yet" else "No Results",
        message = if (query.isBlank()) "Find people by their @handle in the Search tab." else "No friends match \"$query\"."
      )
    } else {
      LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(filtered, key = { _, u -> u.uid }) { index, friend ->
          val letter = friend.name.firstOrNull()?.uppercaseChar()?.toString() ?: "#"
          val prevLetter = filtered.getOrNull(index - 1)?.name?.firstOrNull()?.uppercaseChar()?.toString() ?: "#"
          Column {
            if (index == 0 || letter != prevLetter) {
              Text(
                letter,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = IOS.secondaryLabel,
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, top = 10.dp, bottom = 2.dp)
              )
            }
            FriendRow(friend, onClick = { onMessageFriend(friend) }, onLongClick = { sheetFor = friend })
          }
        }
      }
    }
  }

  sheetFor?.let { friend ->
    IOSActionSheet(
      title = friend.name,
      actions = listOf(
        SheetAction("Message") { onMessageFriend(friend) },
        SheetAction("View Profile") { onViewProfile(friend) },
        SheetAction("Remove Friend", destructive = true) { onUnfriend(friend) },
        SheetAction("Block", destructive = true) { onBlock(friend) }
      ),
      onDismiss = { sheetFor = null }
    )
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FriendRow(user: User, onClick: () -> Unit, onLongClick: () -> Unit) {
  Column {
    Row(
      Modifier
        .fillMaxWidth()
        .combinedClickable(onClick = onClick, onLongClick = onLongClick)
        .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Avatar(user.profileImage, user.name, 46.dp, online = user.isOnline)
      Spacer(Modifier.width(12.dp))
      Column(Modifier.weight(1f)) {
        Text(
          user.name,
          fontSize = 17.sp,
          fontWeight = FontWeight.Medium,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          "@${user.userId} · ${lastSeenText(user.isOnline, user.lastSeen)}",
          fontSize = 14.sp,
          color = IOS.secondaryLabel,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
    IOSDivider(startInset = 74.dp)
  }
}
