package com.example.ui.screens.status

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.DonutLarge
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.Status
import com.example.data.model.User
import com.example.ui.components.Avatar
import com.example.ui.components.IOS
import com.example.ui.components.IOSDivider
import com.example.ui.components.IOSLargeTitle
import com.example.ui.components.IOSSection
import com.example.ui.components.IOSTextButton
import com.example.ui.components.formatDayHeader
import kotlinx.coroutines.delay

private val StoryColors = listOf(
  Color(0xFF5E5CE6), Color(0xFFFF9F0A), Color(0xFF30B0C7), Color(0xFFFF375F), Color(0xFF34C759), Color(0xFFAF52DE)
)

@Composable
fun StatusScreen(
  currentUser: User?,
  friends: List<User>,
  statuses: List<Status>,
  isUploading: Boolean,
  onPost: (String, Uri?) -> Unit,
  onDelete: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val myUid = currentUser?.uid ?: ""
  var composing by remember { mutableStateOf(false) }
  var viewingUid by remember { mutableStateOf<String?>(null) }

  val byUser = remember(statuses) { statuses.groupBy { it.uid } }
  val mine = byUser[myUid].orEmpty()
  val recent = remember(byUser, friends) {
    friends.filter { byUser.containsKey(it.uid) }
      .sortedByDescending { byUser[it.uid]?.lastOrNull()?.createdAt?.toDate()?.time ?: 0L }
  }

  Column(modifier.fillMaxSize().background(IOS.groupedBg)) {
    IOSLargeTitle("Status")

    Column(Modifier.verticalScroll(rememberScrollState())) {
      IOSSection(footer = "Status updates disappear after 24 hours.") {
        Row(
          Modifier
            .fillMaxWidth()
            .clickable { if (mine.isNotEmpty()) viewingUid = myUid else composing = true }
            .padding(horizontal = 16.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box {
            StoryRing(active = mine.isNotEmpty()) {
              Avatar(currentUser?.profileImage ?: "", currentUser?.name ?: "?", 50.dp)
            }
            Box(
              Modifier
                .align(Alignment.BottomEnd)
                .size(22.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .border(2.dp, IOS.groupedCard, CircleShape)
                .clickable { composing = true },
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Filled.Add, "Add status", tint = Color.White, modifier = Modifier.size(14.dp))
            }
          }
          Spacer(Modifier.width(14.dp))
          Column(Modifier.weight(1f)) {
            Text("My Status", fontSize = 17.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Text(
              if (mine.isEmpty()) "Tap to add a status update"
              else formatDayHeader(mine.last().createdAt),
              fontSize = 14.sp,
              color = IOS.secondaryLabel
            )
          }
        }
      }

      if (recent.isNotEmpty()) {
        IOSSection(header = "Recent updates") {
          recent.forEachIndexed { i, friend ->
            val latest = byUser[friend.uid]?.lastOrNull()
            Column {
              Row(
                Modifier
                  .fillMaxWidth()
                  .clickable { viewingUid = friend.uid }
                  .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                StoryRing(active = true) { Avatar(friend.profileImage, friend.name, 50.dp) }
                Spacer(Modifier.width(14.dp))
                Column {
                  Text(friend.name, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                  Text(formatDayHeader(latest?.createdAt), fontSize = 14.sp, color = IOS.secondaryLabel)
                }
              }
              if (i < recent.lastIndex) IOSDivider(startInset = 84.dp)
            }
          }
        }
      } else {
        Text(
          "When friends share a status update, it will appear here.",
          fontSize = 15.sp,
          color = IOS.secondaryLabel,
          textAlign = TextAlign.Center,
          modifier = Modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 32.dp)
        )
      }
    }
  }

  if (composing) {
    StatusComposer(
      isUploading = isUploading,
      onDismiss = { composing = false },
      onPost = { text, uri ->
        onPost(text, uri)
        composing = false
      }
    )
  }

  viewingUid?.let { uid ->
    val list = byUser[uid].orEmpty()
    val owner = if (uid == myUid) currentUser else friends.firstOrNull { it.uid == uid }
    if (list.isEmpty() || owner == null) {
      LaunchedEffect(uid) { viewingUid = null }
    } else {
      StatusViewer(
        owner = owner,
        statuses = list,
        isMine = uid == myUid,
        onDelete = onDelete,
        onClose = { viewingUid = null }
      )
    }
  }
}

@Composable
private fun StoryRing(active: Boolean, content: @Composable () -> Unit) {
  Box(
    Modifier
      .size(58.dp)
      .border(
        width = 2.5.dp,
        color = if (active) MaterialTheme.colorScheme.primary else Color.Transparent,
        shape = CircleShape
      )
      .padding(4.dp),
    contentAlignment = Alignment.Center
  ) { content() }
}

@Composable
private fun StatusComposer(
  isUploading: Boolean,
  onDismiss: () -> Unit,
  onPost: (String, Uri?) -> Unit
) {
  var text by remember { mutableStateOf("") }
  var imageUri by remember { mutableStateOf<Uri?>(null) }
  val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
    if (uri != null) imageUri = uri
  }
  val canPost = (text.isNotBlank() || imageUri != null) && !isUploading

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Column(
      Modifier
        .fillMaxSize()
        .background(IOS.groupedBg)
        .statusBarsPadding()
        .navigationBarsPadding()
        .imePadding()
    ) {
      Row(
        Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IOSTextButton("Cancel", onDismiss)
        Text(
          "New Status",
          fontSize = 17.sp,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurface,
          textAlign = TextAlign.Center,
          modifier = Modifier.weight(1f)
        )
        IOSTextButton("Post", onClick = { onPost(text, imageUri) }, enabled = canPost, bold = true)
      }

      Column(
        Modifier
          .padding(16.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(IOS.groupedCard)
          .padding(16.dp)
      ) {
        Box(Modifier.fillMaxWidth().height(140.dp)) {
          if (text.isEmpty()) Text("What's on your mind?", fontSize = 17.sp, color = IOS.secondaryLabel)
          BasicTextField(
            value = text,
            onValueChange = { text = it.take(500) },
            textStyle = TextStyle(fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            modifier = Modifier.fillMaxSize()
          )
        }

        if (imageUri != null) {
          Box(Modifier.padding(top = 8.dp)) {
            AsyncImage(
              model = imageUri,
              contentDescription = "Selected photo",
              contentScale = ContentScale.Crop,
              modifier = Modifier.size(120.dp).clip(RoundedCornerShape(12.dp))
            )
            Box(
              Modifier
                .align(Alignment.TopEnd)
                .padding(4.dp)
                .size(24.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.6f))
                .clickable { imageUri = null },
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Filled.Close, "Remove photo", tint = Color.White, modifier = Modifier.size(14.dp))
            }
          }
        } else {
          Row(
            Modifier
              .padding(top = 8.dp)
              .clip(RoundedCornerShape(10.dp))
              .clickable {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
              }
              .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Outlined.Image, null, tint = MaterialTheme.colorScheme.primary)
            Text("Add Photo", fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
          }
        }
      }
    }
  }
}

@Composable
private fun StatusViewer(
  owner: User,
  statuses: List<Status>,
  isMine: Boolean,
  onDelete: (String) -> Unit,
  onClose: () -> Unit
) {
  var index by remember { mutableIntStateOf(0) }
  val safeIndex = index.coerceIn(0, statuses.lastIndex)
  val current = statuses[safeIndex]

  fun next() { if (safeIndex < statuses.lastIndex) index = safeIndex + 1 else onClose() }
  fun previous() { if (safeIndex > 0) index = safeIndex - 1 }

  // Auto-advance after 5 seconds.
  LaunchedEffect(safeIndex, current.statusId) {
    delay(5000)
    next()
  }

  Dialog(
    onDismissRequest = onClose,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Box(
      Modifier
        .fillMaxSize()
        .background(
          if (current.imageUrl.isBlank()) StoryColors[(owner.uid.hashCode() and Int.MAX_VALUE) % StoryColors.size]
          else Color.Black
        )
    ) {
      if (current.imageUrl.isNotBlank()) {
        AsyncImage(
          model = current.imageUrl,
          contentDescription = "Status photo",
          contentScale = ContentScale.Fit,
          modifier = Modifier.fillMaxSize()
        )
      }
      if (current.text.isNotBlank()) {
        Text(
          current.text,
          color = Color.White,
          fontSize = if (current.imageUrl.isBlank()) 28.sp else 17.sp,
          fontWeight = if (current.imageUrl.isBlank()) FontWeight.SemiBold else FontWeight.Normal,
          textAlign = TextAlign.Center,
          modifier = Modifier
            .align(if (current.imageUrl.isBlank()) Alignment.Center else Alignment.BottomCenter)
            .then(
              if (current.imageUrl.isBlank()) Modifier else Modifier.background(Color.Black.copy(alpha = 0.45f)).fillMaxWidth()
            )
            .padding(horizontal = 28.dp, vertical = 28.dp)
            .navigationBarsPadding()
        )
      }

      // Tap zones: left = previous, right = next.
      Row(Modifier.fillMaxSize()) {
        Box(
          Modifier.weight(1f).fillMaxHeight().clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null
          ) { previous() }
        )
        Box(
          Modifier.weight(1f).fillMaxHeight().clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null
          ) { next() }
        )
      }

      Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
          statuses.forEachIndexed { i, _ ->
            Box(
              Modifier
                .weight(1f)
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White.copy(alpha = if (i <= safeIndex) 0.95f else 0.35f))
            )
          }
        }
        Row(
          Modifier.fillMaxWidth().padding(top = 10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Avatar(owner.profileImage, owner.name, 36.dp)
          Spacer(Modifier.width(10.dp))
          Column(Modifier.weight(1f)) {
            Text(if (isMine) "My Status" else owner.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(formatDayHeader(current.createdAt), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
          }
          if (isMine) {
            Box(
              Modifier.size(40.dp).clip(CircleShape).clickable {
                onDelete(current.statusId)
                if (statuses.size == 1) onClose()
              },
              contentAlignment = Alignment.Center
            ) { Icon(Icons.Outlined.Delete, "Delete status", tint = Color.White) }
          }
          Box(
            Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClose),
            contentAlignment = Alignment.Center
          ) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
        }
      }
    }
  }
}
