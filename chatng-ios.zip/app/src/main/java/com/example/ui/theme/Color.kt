package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// iOS system palette. Legacy names are kept so untouched screens keep compiling.
val BrandBlue = Color(0xFF007AFF)
val BrandBlueDark = Color(0xFF0A60D0)
val BrandBlueLight = Color(0xFF0A84FF)
val BrandBlue50 = Color(0xFFE5F1FF)
val BrandBlue100 = Color(0xFFCCE4FF)

val CharcoalDark = Color(0xFF000000)
val CardDark = Color(0xFF1C1C1E)
val SurfaceDark = Color(0xFF2C2C2E)

val Slate50 = Color(0xFFF2F2F7)
val Slate100 = Color(0xFFEEEEF0)
val Slate200 = Color(0xFFE5E5EA)
val Slate300 = Color(0xFFC7C7CC)
val Slate400 = Color(0xFF8E8E93)
val Slate500 = Color(0xFF6C6C70)
val Slate700 = Color(0xFF38383A)
val Slate800 = Color(0xFF2C2C2E)
val Slate900 = Color(0xFF000000)

val OnlineGreen = Color(0xFF34C759)
val DangerRed = Color(0xFFFF3B30)
val DangerRedBg = Color(0xFFFFE5E3)
