package com.example.ui.screens.chat

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.Chat
import com.example.data.model.Message
import com.example.data.model.User
import com.example.ui.components.Avatar
import com.example.ui.components.IOS
import com.example.ui.components.IOSActionSheet
import com.example.ui.components.IOSNavBar
import com.example.ui.components.IOSTextButton
import com.example.ui.components.SheetAction
import com.example.ui.components.formatClock
import com.example.ui.components.formatDayHeader
import com.example.ui.theme.LocalAnimationsEnabled
import com.example.ui.components.lastSeenText
import com.google.firebase.Timestamp
import kotlinx.coroutines.delay

private const val GROUP_GAP_MS = 5 * 60 * 1000L
private const val HEADER_GAP_MS = 30 * 60 * 1000L

private fun millis(ts: Timestamp?): Long = ts?.toDate()?.time ?: 0L

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(
  chatId: String,
  otherUser: User,
  currentUserId: String,
  messages: List<Message>,
  chat: Chat?,
  isBlocked: Boolean,
  isUploading: Boolean,
  onSendMessage: (String, String) -> Unit,
  onSendImage: (Uri) -> Unit,
  onUnsend: (String) -> Unit,
  onTyping: (Boolean) -> Unit,
  onMarkSeen: () -> Unit,
  onBlock: () -> Unit,
  onUnblock: () -> Unit,
  onOpenProfile: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)
  val animate = LocalAnimationsEnabled.current

  val listState = rememberLazyListState()
  val clipboard = LocalClipboardManager.current
  var text by remember { mutableStateOf("") }
  var typingSent by remember { mutableStateOf(false) }
  var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
  var menuOpen by remember { mutableStateOf(false) }
  var selected by remember { mutableStateOf<Message?>(null) }
  var viewerUrl by remember { mutableStateOf<String?>(null) }

  val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
    if (uri != null) onSendImage(uri)
  }

  // Tick so a stale "typing…" marker expires on its own.
  LaunchedEffect(Unit) {
    while (true) {
      delay(2000)
      now = System.currentTimeMillis()
    }
  }
  val otherTyping = chat?.typing?.get(otherUser.uid)?.let { now - millis(it) < 8000 } == true

  // Mark incoming messages as read whenever new ones arrive while the chat is open.
  val hasUnseenIncoming = messages.any { it.senderId != currentUserId && !it.seen }
  LaunchedEffect(messages.size, hasUnseenIncoming) {
    if (hasUnseenIncoming) onMarkSeen()
  }

  LaunchedEffect(messages.size, otherTyping) {
    val last = messages.size - 1 + (if (otherTyping) 1 else 0)
    if (last >= 0) {
      if (animate) listState.animateScrollToItem(last) else listState.scrollToItem(last)
    }
  }

  // Typing indicator: send "typing" once, clear after 3 s of inactivity.
  LaunchedEffect(text) {
    if (text.isNotBlank()) {
      if (!typingSent) {
        typingSent = true
        onTyping(true)
      }
      delay(3000)
      typingSent = false
      onTyping(false)
    } else if (typingSent) {
      typingSent = false
      onTyping(false)
    }
  }

  val lastMineId = messages.lastOrNull { it.senderId == currentUserId }?.messageId

  Column(
    modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    IOSNavBar(
      onBack = onBack,
      backLabel = "Chats",
      titleContent = {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.widthIn(max = 200.dp).clip(RoundedCornerShape(8.dp)).clickable(onClick = onOpenProfile)
        ) {
          Avatar(otherUser.profileImage, otherUser.name, 34.dp)
          Spacer(Modifier.width(8.dp))
          Column {
            Text(
              otherUser.name,
              fontSize = 16.sp,
              fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onBackground,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Text(
              if (otherTyping) "typing…" else lastSeenText(otherUser.isOnline, otherUser.lastSeen),
              fontSize = 12.sp,
              color = if (otherTyping || otherUser.isOnline) MaterialTheme.colorScheme.primary else IOS.secondaryLabel,
              maxLines = 1
            )
          }
        }
      },
      trailing = {
        Box(
          Modifier.size(40.dp).clip(CircleShape).clickable { menuOpen = true },
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Filled.MoreHoriz, "More", tint = MaterialTheme.colorScheme.primary)
        }
      }
    )
    if (isUploading) {
      LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp))
    }

    LazyColumn(
      state = listState,
      modifier = Modifier.weight(1f).fillMaxWidth(),
      contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp)
    ) {
      itemsIndexed(messages, key = { i, m -> m.messageId.ifEmpty { "local_$i" } }) { i, msg ->
        val prev = messages.getOrNull(i - 1)
        val next = messages.getOrNull(i + 1)
        val mine = msg.senderId == currentUserId

        val showHeader = prev == null || millis(msg.timestamp) - millis(prev.timestamp) > HEADER_GAP_MS
        val firstInGroup = showHeader || prev?.senderId != msg.senderId ||
          millis(msg.timestamp) - millis(prev.timestamp) > GROUP_GAP_MS
        val nextStartsHeader = next != null && millis(next.timestamp) - millis(msg.timestamp) > HEADER_GAP_MS
        val lastInGroup = next == null || nextStartsHeader || next.senderId != msg.senderId ||
          millis(next.timestamp) - millis(msg.timestamp) > GROUP_GAP_MS

        if (showHeader) {
          Text(
            formatDayHeader(msg.timestamp),
            fontSize = 12.sp,
            color = IOS.secondaryLabel,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp)
          )
        }

        Column(
          Modifier
            .fillMaxWidth()
            .padding(top = if (firstInGroup && !showHeader) 8.dp else 2.dp),
          horizontalAlignment = if (mine) Alignment.End else Alignment.Start
        ) {
          Bubble(
            msg = msg,
            mine = mine,
            firstInGroup = firstInGroup,
            lastInGroup = lastInGroup,
            onImageClick = { viewerUrl = it },
            onLongPress = { if (msg.type == "text" || mine) selected = msg }
          )
          if (lastInGroup) {
            val receipt = when {
              mine && msg.messageId == lastMineId -> if (msg.seen) " · Read" else " · Delivered"
              else -> ""
            }
            Text(
              formatClock(msg.timestamp) + receipt,
              fontSize = 11.sp,
              color = IOS.secondaryLabel,
              modifier = Modifier.padding(top = 2.dp, start = 6.dp, end = 6.dp)
            )
          }
        }
      }
      if (otherTyping) {
        item(key = "typing") {
          Box(
            Modifier
              .padding(top = 8.dp)
              .clip(RoundedCornerShape(18.dp))
              .background(IOS.receivedBubble)
              .padding(horizontal = 16.dp, vertical = 10.dp)
          ) {
            Text("•••", fontSize = 16.sp, color = IOS.secondaryLabel)
          }
        }
      }
    }

    // ---- composer ----
    Column(
      Modifier
        .fillMaxWidth()
        .background(IOS.bar)
        .navigationBarsPadding()
        .imePadding()
    ) {
      HorizontalDivider(thickness = 0.5.dp, color = IOS.separator)
      if (isBlocked) {
        Row(
          Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "You blocked ${otherUser.name}.",
            fontSize = 15.sp,
            color = IOS.secondaryLabel,
            modifier = Modifier.weight(1f)
          )
          IOSTextButton("Unblock", onUnblock, bold = true)
        }
      } else {
        Row(
          Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
          verticalAlignment = Alignment.Bottom,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(IOS.fill)
              .clickable {
                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
              }
              .testTag("attach_button"),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Filled.Add, "Attach photo", tint = IOS.secondaryLabel, modifier = Modifier.size(22.dp))
          }

          Box(
            Modifier
              .weight(1f)
              .clip(RoundedCornerShape(18.dp))
              .border(0.5.dp, IOS.separator, RoundedCornerShape(18.dp))
              .padding(start = 14.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
            contentAlignment = Alignment.CenterStart
          ) {
            if (text.isEmpty()) {
              Text("Message", fontSize = 17.sp, color = IOS.secondaryLabel)
            }
            BasicTextField(
              value = text,
              onValueChange = { text = it.take(2000) },
              maxLines = 5,
              textStyle = TextStyle(fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface),
              cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
              modifier = Modifier.fillMaxWidth().testTag("message_input")
            )
          }

          val canSend = text.isNotBlank()
          Box(
            Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(if (canSend) MaterialTheme.colorScheme.primary else IOS.fill)
              .clickable(enabled = canSend) {
                onSendMessage(text.trim(), "text")
                text = ""
              }
              .testTag("send_button"),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Filled.ArrowUpward,
              "Send",
              tint = if (canSend) Color.White else IOS.secondaryLabel,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }
    }
  }

  // ---- overlays ----
  selected?.let { msg ->
    val actions = buildList {
      if (msg.type == "text") add(SheetAction("Copy") { clipboard.setText(AnnotatedString(msg.message)) })
      if (msg.senderId == currentUserId) add(SheetAction("Unsend", destructive = true) { onUnsend(msg.messageId) })
    }
    IOSActionSheet(actions = actions, onDismiss = { selected = null })
  }

  if (menuOpen) {
    IOSActionSheet(
      title = otherUser.name,
      actions = listOf(
        if (isBlocked) SheetAction("Unblock ${otherUser.name}") { onUnblock() }
        else SheetAction("Block ${otherUser.name}", destructive = true) { onBlock() }
      ),
      onDismiss = { menuOpen = false }
    )
  }

  viewerUrl?.let { url ->
    Dialog(
      onDismissRequest = { viewerUrl = null },
      properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
      Box(
        Modifier
          .fillMaxSize()
          .background(Color.Black)
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
          ) { viewerUrl = null },
        contentAlignment = Alignment.Center
      ) {
        AsyncImage(
          model = url,
          contentDescription = "Photo",
          contentScale = ContentScale.Fit,
          modifier = Modifier.fillMaxSize()
        )
      }
    }
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Bubble(
  msg: Message,
  mine: Boolean,
  firstInGroup: Boolean,
  lastInGroup: Boolean,
  onImageClick: (String) -> Unit,
  onLongPress: () -> Unit
) {
  val big = 18.dp
  val small = 5.dp
  val shape = if (mine) {
    RoundedCornerShape(
      topStart = big,
      topEnd = if (firstInGroup) big else small,
      bottomEnd = if (lastInGroup) big else small,
      bottomStart = big
    )
  } else {
    RoundedCornerShape(
      topStart = if (firstInGroup) big else small,
      topEnd = big,
      bottomEnd = big,
      bottomStart = if (lastInGroup) big else small
    )
  }

  if (msg.type == "image") {
    AsyncImage(
      model = msg.message,
      contentDescription = "Photo",
      contentScale = ContentScale.Crop,
      modifier = Modifier
        .size(width = 220.dp, height = 260.dp)
        .clip(shape)
        .background(IOS.receivedBubble)
        .combinedClickable(onClick = { onImageClick(msg.message) }, onLongClick = onLongPress)
    )
  } else {
    Box(
      Modifier
        .widthIn(max = 290.dp)
        .clip(shape)
        .background(if (mine) MaterialTheme.colorScheme.primary else IOS.receivedBubble)
        .combinedClickable(onClick = {}, onLongClick = onLongPress)
        .padding(horizontal = 13.dp, vertical = 8.dp)
    ) {
      Text(
        msg.message,
        fontSize = 17.sp,
        lineHeight = 22.sp,
        color = if (mine) Color.White else MaterialTheme.colorScheme.onSurface
      )
    }
  }
}
