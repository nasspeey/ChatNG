package com.example.ui.screens.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.PrivacyKey
import com.example.data.model.PrivacyMode
import com.example.data.model.PrivacyRule
import com.example.data.model.User
import com.example.ui.components.Avatar
import com.example.ui.components.IOS
import com.example.ui.components.IOSNavBar
import com.example.ui.components.IOSRow
import com.example.ui.components.IOSSection

private fun summary(rule: PrivacyRule): String {
  val label = rule.mode.label.removeSuffix("…")
  return if (rule.mode.usesExceptions && rule.excluded.isNotEmpty()) "$label (${rule.excluded.size})" else label.trim()
}

private fun footerFor(key: PrivacyKey): String? = when (key) {
  PrivacyKey.PERSONAL_INFO ->
    "Your email and phone number are only shown when this setting and their own setting both allow it."
  PrivacyKey.STATUS -> "Applies to status updates you post from now on."
  PrivacyKey.GROUP -> "Group chats aren't available yet. This will apply when they are."
  else -> null
}

/** Overview: one row per privacy control, showing its current choice. */
@Composable
fun PrivacyScreen(
  settings: Map<PrivacyKey, PrivacyRule>,
  blockedCount: Int,
  onOpen: (PrivacyKey) -> Unit,
  onOpenBlocked: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  Column(modifier.fillMaxSize().background(IOS.groupedBg)) {
    IOSNavBar(title = "Privacy", onBack = onBack, backLabel = "Settings")

    Column(Modifier.verticalScroll(rememberScrollState())) {
      IOSSection(header = "Who can see my personal info") {
        val first = PrivacyKey.PERSONAL_INFO
        IOSRow(
          title = "Personal info",
          value = summary(settings[first] ?: PrivacyRule(first.default)),
          chevron = true,
          showDivider = false,
          onClick = { onOpen(first) }
        )
      }

      val others = PrivacyKey.entries.filter { it != PrivacyKey.PERSONAL_INFO }
      IOSSection(
        header = "Who can see",
        footer = "Choose who can see each part of your profile. Hidden details are protected on the server, not just in the app."
      ) {
        others.forEachIndexed { i, key ->
          IOSRow(
            title = key.title,
            value = summary(settings[key] ?: PrivacyRule(key.default)),
            chevron = true,
            showDivider = i < others.lastIndex,
            onClick = { onOpen(key) }
          )
        }
      }

      IOSSection {
        IOSRow(
          title = "Blocked Users",
          value = if (blockedCount > 0) blockedCount.toString() else null,
          chevron = true,
          showDivider = false,
          onClick = onOpenBlocked
        )
      }
      Spacer(Modifier.height(32.dp))
    }
  }
}

/** One control: pick a mode, and for the "…except" modes pick the excluded people. */
@Composable
fun PrivacySettingScreen(
  key: PrivacyKey,
  rule: PrivacyRule,
  candidates: List<User>,
  onChange: (PrivacyMode, List<String>) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)
  val primary = MaterialTheme.colorScheme.primary

  Column(modifier.fillMaxSize().background(IOS.groupedBg)) {
    IOSNavBar(title = key.title, onBack = onBack, backLabel = "Privacy")

    Column(Modifier.verticalScroll(rememberScrollState())) {
      IOSSection(footer = footerFor(key)) {
        key.options.forEachIndexed { i, mode ->
          IOSRow(
            title = mode.label,
            trailing = {
              if (rule.mode == mode) Icon(Icons.Filled.Check, "Selected", tint = primary)
            },
            showDivider = i < key.options.lastIndex,
            onClick = { onChange(mode, rule.excluded) }
          )
        }
      }

      if (rule.mode.usesExceptions) {
        val header = if (rule.mode == PrivacyMode.EVERYONE_EXCEPT) "Hide from" else "Hide from these friends"
        if (candidates.isEmpty()) {
          IOSSection(
            header = header,
            footer = "Add friends or start a chat to choose people to exclude."
          ) {
            IOSRow(title = "No people yet", showDivider = false)
          }
        } else {
          IOSSection(
            header = header,
            footer = "${rule.excluded.size} selected. Tap a person to exclude or include them."
          ) {
            candidates.forEachIndexed { i, person ->
              val excluded = person.uid in rule.excluded
              IOSRow(
                title = person.name,
                subtitle = "@${person.userId}",
                leading = { Avatar(person.profileImage, person.name, 40.dp) },
                trailing = {
                  Icon(
                    if (excluded) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                    contentDescription = if (excluded) "Excluded" else "Included",
                    tint = if (excluded) primary else IOS.secondaryLabel,
                    modifier = Modifier.size(24.dp)
                  )
                },
                showDivider = i < candidates.lastIndex,
                dividerInset = 68.dp,
                onClick = {
                  val updated = if (excluded) rule.excluded - person.uid else rule.excluded + person.uid
                  onChange(rule.mode, updated)
                }
              )
            }
          }
        }
      }
      Spacer(Modifier.height(32.dp))
    }
  }
}
