package com.example.ui.screens.auth

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.User
import com.example.data.repository.UserRepository
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlue50
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ProfileSetupScreen(
  userRepository: UserRepository,
  onProfileComplete: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val currentUser = Firebase.auth.currentUser

  var fullName by remember { mutableStateOf(currentUser?.displayName ?: "") }
  var userId by remember { mutableStateOf("") }
  var bio by remember { mutableStateOf("") }
  var selectedImageUri by remember { mutableStateOf<Uri?>(currentUser?.photoUrl) }

  var isCheckingUserId by remember { mutableStateOf(false) }
  var isUserIdAvailable by remember { mutableStateOf<Boolean?>(null) }
  var checkJob by remember { mutableStateOf<Job?>(null) }

  var isSaving by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri ->
    if (uri != null) {
      selectedImageUri = uri
    }
  }

  // Pre-seed username handle from email or name if blank
  LaunchedEffect(currentUser) {
    if (userId.isEmpty() && currentUser != null) {
      val base = (currentUser.email?.substringBefore("@") ?: currentUser.displayName?.replace(" ", "") ?: "user")
        .lowercase().filter { it.isLetterOrDigit() }
      if (base.isNotBlank()) {
        userId = base
      }
    }
  }

  // Debounced user ID uniqueness check
  LaunchedEffect(userId) {
    val clean = userId.trim().removePrefix("@").lowercase()
    if (clean.length < 3) {
      isUserIdAvailable = null
      return@LaunchedEffect
    }

    checkJob?.cancel()
    checkJob = scope.launch {
      isCheckingUserId = true
      delay(400)
      val available = userRepository.isUserIdAvailable(clean, currentUser?.uid)
      isUserIdAvailable = available
      isCheckingUserId = false
    }
  }

  fun handleSave() {
    val uid = currentUser?.uid ?: return
    val cleanUserId = userId.trim().removePrefix("@").lowercase()

    if (fullName.isBlank()) {
      errorMessage = "Please enter your full name"
      return
    }
    if (cleanUserId.length < 3) {
      errorMessage = "User ID must be at least 3 characters"
      return
    }
    if (isUserIdAvailable == false) {
      errorMessage = "User ID @$cleanUserId is already taken"
      return
    }

    isSaving = true
    errorMessage = null

    scope.launch {
      try {
        val user = User(
          uid = uid,
          name = fullName.trim(),
          email = currentUser.email ?: "",
          userId = cleanUserId,
          profileImage = selectedImageUri?.toString() ?: "",
          bio = bio.trim(),
          phoneNumber = currentUser.phoneNumber ?: "",
          isOnline = true
        )
        userRepository.saveProfile(user)
        isSaving = false
        onProfileComplete()
      } catch (e: Exception) {
        isSaving = false
        errorMessage = e.localizedMessage ?: "Failed to save profile. Please try again."
      }
    }
  }

  Scaffold(
    topBar = {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onBack, modifier = Modifier.testTag("profile_setup_back")) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = MaterialTheme.colorScheme.onSurface
          )
        }
        Text(
          text = "Profile Setup",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
          modifier = Modifier
            .weight(1f)
            .padding(end = 48.dp),
          textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
      }
    },
    bottomBar = {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 24.dp, vertical = 20.dp)
      ) {
        Button(
          onClick = { handleSave() },
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .shadow(8.dp, CircleShape, spotColor = BrandBlue.copy(alpha = 0.35f))
            .testTag("profile_setup_continue_button"),
          shape = CircleShape,
          colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
          enabled = !isSaving
        ) {
          if (isSaving) {
            CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
          } else {
            Text("Continue", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
          }
        }
      }
    },
    modifier = modifier.imePadding()
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(modifier = Modifier.height(12.dp))

      // Avatar selection container
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(116.dp)
      ) {
        Box(
          modifier = Modifier
            .size(116.dp)
            .clip(CircleShape)
            .background(BrandBlue50)
            .border(3.dp, Color.White, CircleShape)
        ) {
          if (selectedImageUri != null) {
            AsyncImage(
              model = ImageRequest.Builder(context)
                .data(selectedImageUri)
                .crossfade(true)
                .build(),
              contentDescription = "Profile picture",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
          } else {
            Icon(
              imageVector = Icons.Outlined.Person,
              contentDescription = "Avatar Placeholder",
              tint = BrandBlue,
              modifier = Modifier
                .size(60.dp)
                .align(Alignment.Center)
            )
          }
        }

        // Camera badge
        Box(
          modifier = Modifier
            .size(34.dp)
            .align(Alignment.BottomEnd)
            .shadow(4.dp, CircleShape)
            .clip(CircleShape)
            .background(BrandBlue)
            .border(2.dp, Color.White, CircleShape)
            .clickable {
              photoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
              )
            }
            .testTag("avatar_upload_button"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.CameraAlt,
            contentDescription = "Upload photo",
            tint = Color.White,
            modifier = Modifier.size(16.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(28.dp))

      // Field 1: Full Name
      OutlinedTextField(
        value = fullName,
        onValueChange = { fullName = it },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("full_name_input"),
        label = { Text("FULL NAME", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Slate400) },
        placeholder = { Text("Enter full name", fontSize = 14.sp) },
        leadingIcon = {
          Icon(Icons.Outlined.Person, contentDescription = "Full Name", tint = Slate400, modifier = Modifier.size(20.dp))
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = BrandBlue,
          unfocusedBorderColor = Slate200,
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Field 2: User ID with Availability indicator
      OutlinedTextField(
        value = userId,
        onValueChange = { userId = it.trim().removePrefix("@") },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("user_id_input"),
        label = { Text("USER ID", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Slate400) },
        placeholder = { Text("e.g. dhiraj247", fontSize = 14.sp) },
        leadingIcon = {
          Icon(Icons.Outlined.Group, contentDescription = "User ID", tint = Slate400, modifier = Modifier.size(20.dp))
        },
        trailingIcon = {
          if (isCheckingUserId) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = BrandBlue)
          } else if (isUserIdAvailable == true) {
            Box(
              modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(OnlineGreen),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Check, contentDescription = "Available", tint = Color.White, modifier = Modifier.size(14.dp))
            }
          } else if (isUserIdAvailable == false) {
            Box(
              modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.error),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Close, contentDescription = "Unavailable", tint = Color.White, modifier = Modifier.size(14.dp))
            }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = BrandBlue,
          unfocusedBorderColor = Slate200,
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
      )

      // Availability text status
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 4.dp, end = 4.dp),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (isUserIdAvailable == true) {
          Icon(Icons.Default.Check, contentDescription = null, tint = OnlineGreen, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Available", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = OnlineGreen)
        } else if (isUserIdAvailable == false) {
          Icon(Icons.Default.Close, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Already taken", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Field 3: Bio (Optional)
      OutlinedTextField(
        value = bio,
        onValueChange = { bio = it },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("bio_input"),
        label = { Text("BIO (OPTIONAL)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Slate400) },
        placeholder = { Text("A tech enthusiast...", fontSize = 14.sp) },
        leadingIcon = {
          Icon(Icons.Outlined.Edit, contentDescription = "Bio", tint = Slate400, modifier = Modifier.size(20.dp))
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = BrandBlue,
          unfocusedBorderColor = Slate200,
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
      )

      if (errorMessage != null) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = errorMessage ?: "",
          color = MaterialTheme.colorScheme.error,
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium
        )
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
