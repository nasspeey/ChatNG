package com.example.ui.screens.profile

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.User
import com.example.data.repository.UserRepository
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlue50
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
  currentUser: User?,
  userRepository: UserRepository,
  onProfileUpdated: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  var fullName by remember { mutableStateOf(currentUser?.name ?: "") }
  var userId by remember { mutableStateOf(currentUser?.userId ?: "") }
  var bio by remember { mutableStateOf(currentUser?.bio ?: "") }
  var selectedImageUri by remember {
    mutableStateOf(currentUser?.profileImage?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) })
  }

  var isCheckingUserId by remember { mutableStateOf(false) }
  var isUserIdAvailable by remember { mutableStateOf<Boolean?>(true) }
  var checkJob by remember { mutableStateOf<Job?>(null) }

  var isSaving by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  BackHandler { onBack() }

  val photoPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri ->
    if (uri != null) {
      selectedImageUri = uri
    }
  }

  // Debounced check if user ID was changed
  LaunchedEffect(userId) {
    val clean = userId.trim().removePrefix("@").lowercase()
    if (clean == currentUser?.userId?.lowercase()) {
      isUserIdAvailable = true
      return@LaunchedEffect
    }
    if (clean.length < 3) {
      isUserIdAvailable = false
      return@LaunchedEffect
    }

    checkJob?.cancel()
    checkJob = scope.launch {
      isCheckingUserId = true
      delay(400)
      isUserIdAvailable = userRepository.isUserIdAvailable(clean, currentUser?.uid)
      isCheckingUserId = false
    }
  }

  fun handleSave() {
    val uid = currentUser?.uid ?: return
    val cleanUserId = userId.trim().removePrefix("@").lowercase()

    if (fullName.isBlank()) {
      errorMessage = "Please enter your full name"
      return
    }
    if (cleanUserId.length < 3) {
      errorMessage = "User ID must be at least 3 characters"
      return
    }
    if (isUserIdAvailable == false) {
      errorMessage = "User ID @$cleanUserId is already taken"
      return
    }

    isSaving = true
    errorMessage = null

    scope.launch {
      try {
        val updated = currentUser.copy(
          name = fullName.trim(),
          userId = cleanUserId,
          bio = bio.trim(),
          profileImage = selectedImageUri?.toString() ?: currentUser.profileImage
        )
        userRepository.saveProfile(updated)
        isSaving = false
        onProfileUpdated()
      } catch (e: Exception) {
        isSaving = false
        errorMessage = e.localizedMessage ?: "Failed to save profile changes"
      }
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Edit Profile",
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("edit_profile_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface
        )
      )
    },
    bottomBar = {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 24.dp, vertical = 20.dp)
      ) {
        Button(
          onClick = { handleSave() },
          shape = CircleShape,
          colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .shadow(8.dp, CircleShape, spotColor = BrandBlue.copy(alpha = 0.3f))
            .testTag("save_profile_changes_button"),
          enabled = !isSaving
        ) {
          if (isSaving) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
          } else {
            Text("Save Changes", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
          }
        }
      }
    },
    modifier = modifier.imePadding()
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(modifier = Modifier.height(16.dp))

      // Avatar
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(110.dp)
      ) {
        Box(
          modifier = Modifier
            .size(110.dp)
            .clip(CircleShape)
            .background(BrandBlue50)
            .border(3.dp, MaterialTheme.colorScheme.surface, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          if (selectedImageUri != null) {
            AsyncImage(
              model = ImageRequest.Builder(context)
                .data(selectedImageUri)
                .crossfade(true)
                .build(),
              contentDescription = "Profile photo",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
          } else {
            Icon(
              imageVector = Icons.Default.CameraAlt,
              contentDescription = null,
              tint = BrandBlue,
              modifier = Modifier.size(44.dp)
            )
          }
        }

        // Camera badge
        Box(
          modifier = Modifier
            .size(32.dp)
            .align(Alignment.BottomEnd)
            .shadow(4.dp, CircleShape)
            .clip(CircleShape)
            .background(BrandBlue)
            .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
            .clickable {
              photoPicker.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
              )
            }
            .testTag("edit_avatar_button"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.CameraAlt,
            contentDescription = "Edit photo",
            tint = Color.White,
            modifier = Modifier.size(14.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(28.dp))

      // Field 1: Full Name
      OutlinedTextField(
        value = fullName,
        onValueChange = { fullName = it },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("edit_full_name_input"),
        label = { Text("Full Name", fontSize = 12.sp, color = Slate400) },
        leadingIcon = {
          Icon(Icons.Outlined.Person, contentDescription = null, tint = Slate400, modifier = Modifier.size(20.dp))
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = BrandBlue,
          unfocusedBorderColor = Slate200,
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Field 2: User ID
      OutlinedTextField(
        value = userId,
        onValueChange = { userId = it.trim().removePrefix("@") },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("edit_user_id_input"),
        label = { Text("User ID", fontSize = 12.sp, color = Slate400) },
        leadingIcon = {
          Icon(Icons.Outlined.Group, contentDescription = null, tint = Slate400, modifier = Modifier.size(20.dp))
        },
        trailingIcon = {
          if (isCheckingUserId) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = BrandBlue)
          } else if (isUserIdAvailable == true) {
            Box(
              modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(OnlineGreen),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Check, contentDescription = "Available", tint = Color.White, modifier = Modifier.size(14.dp))
            }
          } else if (isUserIdAvailable == false) {
            Box(
              modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.error),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Close, contentDescription = "Unavailable", tint = Color.White, modifier = Modifier.size(14.dp))
            }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = BrandBlue,
          unfocusedBorderColor = Slate200,
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Field 3: Bio
      OutlinedTextField(
        value = bio,
        onValueChange = { bio = it },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("edit_bio_input"),
        label = { Text("Bio", fontSize = 12.sp, color = Slate400) },
        leadingIcon = {
          Icon(Icons.Outlined.Edit, contentDescription = null, tint = Slate400, modifier = Modifier.size(20.dp))
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = BrandBlue,
          unfocusedBorderColor = Slate200,
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
      )

      if (errorMessage != null) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = errorMessage ?: "",
          color = MaterialTheme.colorScheme.error,
          fontSize = 13.sp
        )
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
