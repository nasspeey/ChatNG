package com.example.ui.screens.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Block
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.User
import com.example.ui.components.Avatar
import com.example.ui.components.IOS
import com.example.ui.components.IOSEmptyState
import com.example.ui.components.IOSNavBar
import com.example.ui.components.IOSRow
import com.example.ui.components.IOSSection
import com.example.ui.screens.friends.Pill

@Composable
fun BlockedUsersScreen(
  blocked: List<User>,
  onUnblock: (User) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  Column(modifier.fillMaxSize().background(IOS.groupedBg)) {
    IOSNavBar(title = "Blocked Users", onBack = onBack, backLabel = "Privacy")
    if (blocked.isEmpty()) {
      IOSEmptyState(
        icon = Icons.Outlined.Block,
        title = "No Blocked Users",
        message = "People you block can't message you or send friend requests."
      )
    } else {
      Column(Modifier.verticalScroll(rememberScrollState())) {
        IOSSection(footer = "Blocked people aren't told that you blocked them.") {
          blocked.forEachIndexed { i, user ->
            IOSRow(
              title = user.name,
              subtitle = "@${user.userId}",
              leading = { Avatar(user.profileImage, user.name, 44.dp) },
              trailing = { Pill("Unblock", filled = false) { onUnblock(user) } },
              showDivider = i < blocked.lastIndex,
              dividerInset = 72.dp
            )
          }
        }
      }
    }
  }
}
