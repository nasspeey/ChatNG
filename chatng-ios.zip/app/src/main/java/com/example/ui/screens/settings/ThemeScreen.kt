package com.example.ui.screens.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.example.ui.components.IOS
import com.example.ui.components.IOSNavBar
import com.example.ui.components.IOSRow
import com.example.ui.components.IOSSection
import com.example.ui.theme.AccentColor
import com.example.ui.theme.AppThemeMode

@Composable
fun ThemeScreen(
  themeMode: AppThemeMode,
  accent: AccentColor,
  onThemeMode: (AppThemeMode) -> Unit,
  onAccent: (AccentColor) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)
  val primary = MaterialTheme.colorScheme.primary

  Column(modifier.fillMaxSize().background(IOS.groupedBg)) {
    IOSNavBar(title = "Manage Theme", onBack = onBack, backLabel = "Settings")

    Column(Modifier.verticalScroll(rememberScrollState())) {
      IOSSection(header = "Mode", footer = "System follows your device's light or dark setting.") {
        val modes = listOf(
          AppThemeMode.SYSTEM to "System",
          AppThemeMode.LIGHT to "Light",
          AppThemeMode.DARK to "Dark"
        )
        modes.forEachIndexed { i, (mode, label) ->
          IOSRow(
            title = label,
            trailing = {
              if (themeMode == mode) Icon(Icons.Filled.Check, "Selected", tint = primary)
            },
            showDivider = i < modes.lastIndex,
            onClick = { onThemeMode(mode) }
          )
        }
      }

      IOSSection(header = "Accent colour") {
        val all = AccentColor.entries
        all.forEachIndexed { i, option ->
          IOSRow(
            title = option.label,
            leading = {
              Box(
                Modifier
                  .size(24.dp)
                  .clip(CircleShape)
                  .background(if (IOS.isDark) option.dark else option.light)
              )
            },
            trailing = {
              if (accent == option) Icon(Icons.Filled.Check, "Selected", tint = primary)
            },
            showDivider = i < all.lastIndex,
            dividerInset = 52.dp,
            onClick = { onAccent(option) }
          )
        }
      }
    }
  }
}
