package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.lerp
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

// Plain screens are white / black (iOS "systemBackground");
// grouped screens use IOS.groupedBg from components/IOS.kt.
val DarkColorScheme = darkColorScheme(
  primary = BrandBlueLight,
  onPrimary = Color.White,
  primaryContainer = Color(0xFF0A3A75),
  onPrimaryContainer = Color.White,
  secondary = Slate400,
  onSecondary = Color.White,
  background = Color.Black,
  onBackground = Color.White,
  surface = Color.Black,
  onSurface = Color.White,
  surfaceVariant = CardDark,
  onSurfaceVariant = Slate400,
  outline = Slate700,
  error = Color(0xFFFF453A),
  onError = Color.White
)

val LightColorScheme = lightColorScheme(
  primary = BrandBlue,
  onPrimary = Color.White,
  primaryContainer = BrandBlue50,
  onPrimaryContainer = BrandBlueDark,
  secondary = Slate500,
  onSecondary = Color.White,
  background = Color.White,
  onBackground = Color.Black,
  surface = Color.White,
  onSurface = Color.Black,
  surfaceVariant = Slate50,
  onSurfaceVariant = Slate500,
  outline = Slate200,
  error = DangerRed,
  onError = Color.White
)

enum class AppThemeMode {
  SYSTEM, LIGHT, DARK
}

/** Accent colours the user can pick in Settings → Manage Theme. */
enum class AccentColor(val label: String, val light: Color, val dark: Color) {
  BLUE("Blue", Color(0xFF007AFF), Color(0xFF0A84FF)),
  PURPLE("Purple", Color(0xFF5E5CE6), Color(0xFF7D7AFF)),
  GREEN("Green", Color(0xFF248A3D), Color(0xFF30D158)),
  ORANGE("Orange", Color(0xFFC95F00), Color(0xFFFF9F0A)),
  PINK("Pink", Color(0xFFD6336C), Color(0xFFFF375F))
}

val LocalHighContrast = compositionLocalOf { false }
val LocalAnimationsEnabled = compositionLocalOf { true }

private val IOSShapes = Shapes(
  extraSmall = RoundedCornerShape(6.dp),
  small = RoundedCornerShape(10.dp),
  medium = RoundedCornerShape(12.dp),
  large = RoundedCornerShape(16.dp),
  extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun ChatNGTheme(
  themeMode: AppThemeMode = AppThemeMode.SYSTEM,
  highContrast: Boolean = false,
  accent: AccentColor = AccentColor.BLUE,
  animationsEnabled: Boolean = true,
  content: @Composable () -> Unit
) {
  val isDark = when (themeMode) {
    AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    AppThemeMode.LIGHT -> false
    AppThemeMode.DARK -> true
  }

  // Keep status/navigation bar icons readable when the in-app theme
  // differs from the system theme.
  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window ?: return@SideEffect
      val controller = WindowCompat.getInsetsController(window, view)
      controller.isAppearanceLightStatusBars = !isDark
      controller.isAppearanceLightNavigationBars = !isDark
    }
  }

  // Increase contrast pushes the accent and secondary text further from the background.
  val baseAccent = if (isDark) accent.dark else accent.light
  val primary = if (highContrast) lerp(baseAccent, if (isDark) Color.White else Color.Black, 0.25f) else baseAccent
  val base = if (isDark) DarkColorScheme else LightColorScheme
  val scheme = base.copy(
    primary = primary,
    onSurfaceVariant = if (highContrast) (if (isDark) Color(0xFFD1D1D6) else Color(0xFF3C3C43)) else base.onSurfaceVariant,
    outline = if (highContrast) (if (isDark) Color(0xFF8E8E93) else Color(0xFF6C6C70)) else base.outline
  )

  CompositionLocalProvider(
    LocalHighContrast provides highContrast,
    LocalAnimationsEnabled provides animationsEnabled
  ) {
    MaterialTheme(
      colorScheme = scheme,
      typography = Typography,
      shapes = IOSShapes,
      content = content
    )
  }
}
