package com.example.ui.screens.friends

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FriendRequest
import com.example.data.model.User
import com.example.ui.components.Avatar
import com.example.ui.components.IOS
import com.example.ui.components.IOSEmptyState
import com.example.ui.components.IOSNavBar
import com.example.ui.components.IOSRow
import com.example.ui.components.IOSSection

@Composable
fun FriendRequestsScreen(
  incomingRequests: List<FriendRequest>,
  outgoingRequests: List<FriendRequest>,
  userMap: Map<String, User>,
  onAccept: (FriendRequest) -> Unit,
  onReject: (FriendRequest) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  Column(modifier.fillMaxSize().background(IOS.groupedBg)) {
    IOSNavBar(title = "Friend Requests", onBack = onBack, backLabel = "Friends")

    if (incomingRequests.isEmpty() && outgoingRequests.isEmpty()) {
      IOSEmptyState(
        icon = Icons.Outlined.PersonAdd,
        title = "No Requests",
        message = "Friend requests you send or receive will appear here."
      )
      return@Column
    }

    Column(Modifier.verticalScroll(rememberScrollState())) {
      if (incomingRequests.isNotEmpty()) {
        IOSSection(header = "Received") {
          incomingRequests.forEachIndexed { i, req ->
            val user = userMap[req.senderId]
            IOSRow(
              title = user?.name ?: "Loading…",
              subtitle = user?.userId?.let { "@$it" },
              leading = { Avatar(user?.profileImage ?: "", user?.name ?: "?", 44.dp) },
              trailing = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Pill("Decline", filled = false) { onReject(req) }
                  Spacer(Modifier.width(8.dp))
                  Pill("Accept", filled = true) { onAccept(req) }
                }
              },
              showDivider = i < incomingRequests.lastIndex,
              dividerInset = 72.dp
            )
          }
        }
      }
      if (outgoingRequests.isNotEmpty()) {
        IOSSection(header = "Sent") {
          outgoingRequests.forEachIndexed { i, req ->
            val user = userMap[req.receiverId]
            IOSRow(
              title = user?.name ?: "Loading…",
              subtitle = user?.userId?.let { "@$it" },
              leading = { Avatar(user?.profileImage ?: "", user?.name ?: "?", 44.dp) },
              value = "Pending",
              showDivider = i < outgoingRequests.lastIndex,
              dividerInset = 72.dp
            )
          }
        }
      }
    }
  }
}

@Composable
fun Pill(label: String, filled: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
  val bg = if (filled) MaterialTheme.colorScheme.primary else IOS.fill
  val fg = when {
    !enabled -> IOS.secondaryLabel
    filled -> Color.White
    else -> MaterialTheme.colorScheme.onSurface
  }
  Text(
    label,
    color = fg,
    fontSize = 14.sp,
    fontWeight = FontWeight.SemiBold,
    modifier = Modifier
      .clip(RoundedCornerShape(50))
      .background(if (enabled) bg else IOS.fill)
      .clickable(enabled = enabled, onClick = onClick)
      .padding(horizontal = 14.dp, vertical = 7.dp)
  )
}
