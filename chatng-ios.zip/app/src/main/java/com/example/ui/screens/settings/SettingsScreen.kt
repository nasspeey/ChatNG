package com.example.ui.screens.settings

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.User
import com.example.ui.components.Avatar
import com.example.ui.components.IOS
import com.example.ui.components.IOSActionSheet
import com.example.ui.components.IOSIconBadge
import com.example.ui.components.IOSNavBar
import com.example.ui.components.IOSRow
import com.example.ui.components.IOSSection
import com.example.ui.components.IOSSwitch
import com.example.ui.components.IOSTextEditDialog
import com.example.ui.components.SheetAction
import com.example.ui.theme.AppThemeMode

@Composable
fun SettingsScreen(
  user: User?,
  isUploading: Boolean,
  themeMode: AppThemeMode,
  increaseContrast: Boolean,
  animationsEnabled: Boolean,
  onChangePhoto: (Uri) -> Unit,
  onEditName: (String) -> Unit,
  onEditUsername: (String) -> Unit,
  onEditEmail: (String) -> Unit,
  onEditPhone: (String) -> Unit,
  onIncreaseContrast: (Boolean) -> Unit,
  onAnimations: (Boolean) -> Unit,
  onOpenTheme: () -> Unit,
  onOpenPrivacy: () -> Unit,
  onLogout: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var editing by remember { mutableStateOf<String?>(null) }
  var confirmLogout by remember { mutableStateOf(false) }
  BackHandler(onBack = onBack)

  val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
    if (uri != null) onChangePhoto(uri)
  }
  val version = remember {
    runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "1.0"
  }

  Column(modifier.fillMaxSize().background(IOS.groupedBg)) {
    IOSNavBar(title = "Settings", onBack = onBack, backLabel = "Profile")

    Column(Modifier.verticalScroll(rememberScrollState())) {
      // ---------------- Account ----------------
      IOSSection(header = "Account") {
        IOSRow(
          title = "Profile Picture",
          value = if (isUploading) "Uploading…" else null,
          trailing = { Avatar(user?.profileImage ?: "", user?.name ?: "?", 40.dp) },
          chevron = true,
          onClick = {
            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
          }
        )
        IOSRow(title = "Name", value = user?.name, chevron = true, onClick = { editing = "name" })
        IOSRow(
          title = "Username",
          value = user?.userId?.let { "@$it" },
          chevron = true,
          onClick = { editing = "username" }
        )
        IOSRow(
          title = "Email",
          value = user?.email?.ifBlank { "Add" },
          chevron = true,
          onClick = { editing = "email" }
        )
        IOSRow(
          title = "Phone number",
          value = user?.phoneNumber?.ifBlank { "Add" },
          chevron = true,
          onClick = { editing = "phone" }
        )
        IOSRow(
          title = "Log out",
          destructive = true,
          showDivider = false,
          modifier = Modifier.testTag("logout_button"),
          onClick = { confirmLogout = true }
        )
      }

      // ---------------- Accessibility ----------------
      IOSSection(
        header = "Accessibility",
        footer = "Increase contrast darkens text, separators and buttons. Turn off Animation to remove screen transitions and motion."
      ) {
        IOSRow(
          title = "Increase contrast",
          trailing = { IOSSwitch(increaseContrast, onIncreaseContrast) },
          onClick = { onIncreaseContrast(!increaseContrast) }
        )
        IOSRow(
          title = "Animation",
          trailing = { IOSSwitch(animationsEnabled, onAnimations) },
          showDivider = false,
          onClick = { onAnimations(!animationsEnabled) }
        )
      }

      // ---------------- Appearance ----------------
      IOSSection(header = "Appearance") {
        IOSRow(
          title = "Manage Theme",
          value = when (themeMode) {
            AppThemeMode.SYSTEM -> "System"
            AppThemeMode.LIGHT -> "Light"
            AppThemeMode.DARK -> "Dark"
          },
          chevron = true,
          showDivider = false,
          onClick = onOpenTheme
        )
      }

      // ---------------- Privacy ----------------
      IOSSection(header = "Privacy") {
        IOSRow(title = "Privacy", chevron = true, showDivider = false, onClick = onOpenPrivacy)
      }

      // ---------------- General ----------------
      IOSSection(header = "General") {
        IOSRow(
          title = "Notifications",
          leading = { IOSIconBadge(Icons.Outlined.Notifications, Color(0xFFFF9500)) },
          chevron = true,
          dividerInset = 57.dp,
          onClick = {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
              .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
              .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { context.startActivity(intent) }
          }
        )
        IOSRow(
          title = "Version",
          leading = { IOSIconBadge(Icons.Outlined.Info, Color(0xFF8E8E93)) },
          value = version,
          showDivider = false
        )
      }
      Spacer(Modifier.height(32.dp))
    }
  }

  when (editing) {
    "name" -> IOSTextEditDialog(
      title = "Name",
      initial = user?.name ?: "",
      placeholder = "Your name",
      onDismiss = { editing = null },
      onSave = { editing = null; onEditName(it) }
    )
    "username" -> IOSTextEditDialog(
      title = "Username",
      initial = user?.userId ?: "",
      placeholder = "username",
      prefix = "@",
      maxLength = 30,
      onDismiss = { editing = null },
      onSave = { editing = null; onEditUsername(it) }
    )
    "email" -> IOSTextEditDialog(
      title = "Email",
      initial = user?.email ?: "",
      placeholder = "name@example.com",
      keyboardType = KeyboardType.Email,
      maxLength = 254,
      onDismiss = { editing = null },
      onSave = { editing = null; onEditEmail(it) }
    )
    "phone" -> IOSTextEditDialog(
      title = "Phone number",
      initial = user?.phoneNumber ?: "",
      placeholder = "+1 555 123 4567",
      keyboardType = KeyboardType.Phone,
      maxLength = 32,
      onDismiss = { editing = null },
      onSave = { editing = null; onEditPhone(it) }
    )
  }

  if (confirmLogout) {
    IOSActionSheet(
      title = "Are you sure you want to log out?",
      actions = listOf(SheetAction("Log out", destructive = true) { onLogout() }),
      onDismiss = { confirmLogout = false }
    )
  }
}
