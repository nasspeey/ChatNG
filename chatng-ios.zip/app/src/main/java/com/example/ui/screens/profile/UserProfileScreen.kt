package com.example.ui.screens.profile

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.data.model.VisibleProfile
import com.example.data.repository.FriendStatus
import com.example.ui.components.Avatar
import com.example.ui.components.IOS
import com.example.ui.components.IOSActionSheet
import com.example.ui.components.IOSNavBar
import com.example.ui.components.IOSRow
import com.example.ui.components.IOSSection
import com.example.ui.components.SheetAction
import com.example.ui.components.lastSeenText
import com.example.ui.screens.friends.Pill

/** Someone else's profile: only the details their privacy settings let you see. */
@Composable
fun UserProfileScreen(
  user: User,
  visible: VisibleProfile?,
  friendStatus: FriendStatus,
  isBlocked: Boolean,
  onMessage: () -> Unit,
  onAddFriend: () -> Unit,
  onOpenRequests: () -> Unit,
  onBlock: () -> Unit,
  onUnblock: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)
  var confirmBlock by remember { mutableStateOf(false) }

  val photo = visible?.photo ?: user.profileImage
  val about = visible?.about
  val email = visible?.email
  val phone = visible?.phone
  val hasAny = about != null || email != null || phone != null

  Column(modifier.fillMaxSize().background(IOS.groupedBg)) {
    IOSNavBar(title = null, onBack = onBack, backLabel = "Back")

    Column(Modifier.verticalScroll(rememberScrollState())) {
      Column(
        Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 10.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(IOS.groupedCard)
          .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Avatar(photo, user.name, 96.dp, online = user.isOnline)
        Spacer(Modifier.height(12.dp))
        Text(user.name, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        Text("@${user.userId}", fontSize = 16.sp, color = IOS.secondaryLabel)
        Text(
          lastSeenText(user.isOnline, user.lastSeen),
          fontSize = 13.sp,
          color = if (user.isOnline) MaterialTheme.colorScheme.primary else IOS.secondaryLabel,
          modifier = Modifier.padding(top = 2.dp)
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          if (!isBlocked) Pill("Message", filled = friendStatus == FriendStatus.FRIENDS, onClick = onMessage)
          if (!isBlocked) when (friendStatus) {
            FriendStatus.NONE -> Pill("Add Friend", filled = true, onClick = onAddFriend)
            FriendStatus.REQUEST_SENT -> Pill("Requested", filled = false, enabled = false) {}
            FriendStatus.REQUEST_RECEIVED -> Pill("Respond", filled = true, onClick = onOpenRequests)
            FriendStatus.FRIENDS -> {}
          }
        }
      }

      if (about != null) {
        IOSSection(header = "About") {
          Text(
            about,
            fontSize = 17.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
          )
        }
      }

      if (email != null || phone != null) {
        IOSSection(header = "Contact") {
          if (email != null) IOSRow(title = "Email", value = email, showDivider = phone != null)
          if (phone != null) IOSRow(title = "Phone", value = phone, showDivider = false)
        }
      }

      if (visible != null && !hasAny) {
        Text(
          "${user.name} keeps their other details private.",
          fontSize = 14.sp,
          color = IOS.secondaryLabel,
          textAlign = TextAlign.Center,
          modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 8.dp)
        )
      }

      IOSSection {
        IOSRow(
          title = if (isBlocked) "Unblock ${user.name}" else "Block ${user.name}",
          destructive = !isBlocked,
          showDivider = false,
          onClick = { if (isBlocked) onUnblock() else confirmBlock = true }
        )
      }
      Spacer(Modifier.height(32.dp))
    }
  }

  if (confirmBlock) {
    IOSActionSheet(
      title = "${user.name} won't be able to message you or send friend requests.",
      actions = listOf(SheetAction("Block ${user.name}", destructive = true) { onBlock() }),
      onDismiss = { confirmBlock = false }
    )
  }
}
