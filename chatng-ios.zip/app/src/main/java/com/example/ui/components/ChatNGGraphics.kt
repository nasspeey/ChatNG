package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun ChatNGBubbleLogo(
  modifier: Modifier = Modifier,
  size: Dp = 80.dp
) {
  Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height

    // Main speech bubble path
    val bubblePath = Path().apply {
      // Circle-like oval with tail at bottom-left
      moveTo(w * 0.5f, h * 0.88f)
      cubicTo(w * 0.72f, h * 0.88f, w * 0.90f, h * 0.70f, w * 0.90f, h * 0.49f)
      cubicTo(w * 0.90f, h * 0.27f, w * 0.72f, h * 0.10f, w * 0.50f, h * 0.10f)
      cubicTo(w * 0.28f, h * 0.10f, w * 0.10f, h * 0.27f, w * 0.10f, h * 0.49f)
      cubicTo(w * 0.10f, h * 0.58f, w * 0.13f, h * 0.66f, w * 0.18f, h * 0.72f)
      lineTo(w * 0.14f, h * 0.90f)
      lineTo(w * 0.32f, h * 0.84f)
      cubicTo(w * 0.38f, h * 0.86f, w * 0.44f, h * 0.88f, w * 0.50f, h * 0.88f)
      close()
    }

    drawPath(
      path = bubblePath,
      brush = Brush.verticalGradient(
        colors = listOf(Color(0xFF2563EB), Color(0xFF0062FF), Color(0xFF1D4ED8))
      )
    )

    // Green accent curve on bottom-left tail
    val accentPath = Path().apply {
      moveTo(w * 0.20f, h * 0.85f)
      quadraticBezierTo(w * 0.32f, h * 0.95f, w * 0.54f, h * 0.91f)
    }
    drawPath(
      path = accentPath,
      color = Color(0xFF22C55E),
      style = Stroke(width = w * 0.055f, cap = StrokeCap.Round)
    )

    // Three white dots
    val dotRadius = w * 0.05f
    val dotY = h * 0.49f
    drawCircle(color = Color.White, radius = dotRadius, center = Offset(w * 0.35f, dotY))
    drawCircle(color = Color.White, radius = dotRadius, center = Offset(w * 0.50f, dotY))
    drawCircle(color = Color.White, radius = dotRadius, center = Offset(w * 0.65f, dotY))
  }
}

@Composable
fun TopWaveGraphic(
  modifier: Modifier = Modifier,
  height: Dp = 140.dp
) {
  Canvas(
    modifier = modifier
      .fillMaxWidth()
      .height(height)
  ) {
    val w = size.width
    val h = size.height

    val path1 = Path().apply {
      moveTo(0f, 0f)
      lineTo(w, 0f)
      lineTo(w, h * 0.45f)
      cubicTo(w * 0.85f, h * 0.75f, w * 0.65f, h * 0.35f, w * 0.45f, h * 0.60f)
      cubicTo(w * 0.25f, h * 0.85f, w * 0.12f, h * 0.55f, 0f, h * 0.75f)
      close()
    }
    drawPath(
      path = path1,
      brush = Brush.verticalGradient(
        listOf(Color(0xFF3B82F6).copy(alpha = 0.35f), Color(0xFF93C5FD).copy(alpha = 0.10f))
      )
    )

    val path2 = Path().apply {
      moveTo(0f, 0f)
      lineTo(w, 0f)
      lineTo(w, h * 0.28f)
      cubicTo(w * 0.80f, h * 0.65f, w * 0.55f, h * 0.15f, w * 0.30f, h * 0.50f)
      cubicTo(w * 0.15f, h * 0.70f, w * 0.08f, h * 0.40f, 0f, h * 0.50f)
      close()
    }
    drawPath(
      path = path2,
      brush = Brush.verticalGradient(
        listOf(Color(0xFF60A5FA).copy(alpha = 0.25f), Color.White.copy(alpha = 0f))
      )
    )
  }
}

@Composable
fun BottomWaveGraphic(
  modifier: Modifier = Modifier,
  height: Dp = 120.dp
) {
  Canvas(
    modifier = modifier
      .fillMaxWidth()
      .height(height)
  ) {
    val w = size.width
    val h = size.height

    val path1 = Path().apply {
      moveTo(0f, h * 0.55f)
      cubicTo(w * 0.20f, h * 0.20f, w * 0.40f, h * 0.70f, w * 0.65f, h * 0.35f)
      cubicTo(w * 0.82f, h * 0.05f, w * 0.92f, h * 0.28f, w, h * 0.18f)
      lineTo(w, h)
      lineTo(0f, h)
      close()
    }
    drawPath(
      path = path1,
      brush = Brush.verticalGradient(
        listOf(Color(0xFF93C5FD).copy(alpha = 0.35f), Color(0xFF3B82F6).copy(alpha = 0.75f))
      )
    )

    val path2 = Path().apply {
      moveTo(0f, h * 0.75f)
      cubicTo(w * 0.25f, h * 0.42f, w * 0.48f, h * 0.80f, w * 0.70f, h * 0.52f)
      cubicTo(w * 0.85f, h * 0.30f, w * 0.95f, h * 0.45f, w, h * 0.40f)
      lineTo(w, h)
      lineTo(0f, h)
      close()
    }
    drawPath(
      path = path2,
      brush = Brush.verticalGradient(
        listOf(Color(0xFFBFDBFE).copy(alpha = 0.25f), Color(0xFF2563EB).copy(alpha = 0.65f))
      )
    )
  }
}
