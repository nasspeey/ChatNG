package com.example.ui.screens.chats

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Chat
import com.example.data.model.User
import com.example.ui.components.Avatar
import com.example.ui.components.CountBadge
import com.example.ui.components.IOS
import com.example.ui.components.IOSActionSheet
import com.example.ui.components.IOSDivider
import com.example.ui.components.IOSEmptyState
import com.example.ui.components.IOSIconButton
import com.example.ui.components.IOSLargeTitle
import com.example.ui.components.IOSSearchField
import com.example.ui.components.SheetAction
import com.example.ui.components.formatListTime

private data class ChatRowData(val chat: Chat, val otherUid: String, val other: User?)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatsScreen(
  chats: List<Chat>,
  userMap: Map<String, User>,
  currentUserId: String,
  blockedUids: Set<String>,
  onChatSelected: (Chat, User?) -> Unit,
  onNewChatClicked: () -> Unit,
  onTogglePin: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var query by remember { mutableStateOf("") }
  var sheetFor by remember { mutableStateOf<ChatRowData?>(null) }

  val rows = remember(chats, userMap, query, currentUserId) {
    chats
      .filter { it.lastMessage.isNotBlank() }
      .map { chat ->
        val otherUid = chat.participants.firstOrNull { it != currentUserId } ?: ""
        ChatRowData(chat, otherUid, userMap[otherUid])
      }
      .filter { row ->
        query.isBlank() ||
          (row.other?.name ?: "").contains(query, ignoreCase = true) ||
          (row.other?.userId ?: "").contains(query.removePrefix("@"), ignoreCase = true) ||
          row.chat.lastMessage.contains(query, ignoreCase = true)
      }
      .sortedWith(
        compareByDescending<ChatRowData> { it.chat.pinnedBy.contains(currentUserId) }
          .thenByDescending { it.chat.timestamp?.toDate()?.time ?: 0L }
      )
  }

  Column(modifier.fillMaxSize()) {
    IOSLargeTitle("Chats") {
      IOSIconButton(Icons.Outlined.Edit, "New message", onNewChatClicked)
    }
    IOSSearchField(
      value = query,
      onValueChange = { query = it },
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
    )

    if (rows.isEmpty()) {
      if (query.isBlank()) {
        IOSEmptyState(
          icon = Icons.Outlined.ChatBubbleOutline,
          title = "No Messages",
          message = "Start a conversation from your Friends, or find someone in Search."
        )
      } else {
        IOSEmptyState(
          icon = Icons.Outlined.ChatBubbleOutline,
          title = "No Results",
          message = "No conversations match \"$query\"."
        )
      }
    } else {
      LazyColumn(Modifier.fillMaxSize()) {
        items(rows, key = { it.chat.chatId }) { row ->
          ChatRow(
            row = row,
            currentUserId = currentUserId,
            blocked = blockedUids.contains(row.otherUid),
            onClick = { onChatSelected(row.chat, row.other) },
            onLongClick = { sheetFor = row }
          )
        }
      }
    }
  }

  sheetFor?.let { row ->
    val pinned = row.chat.pinnedBy.contains(currentUserId)
    IOSActionSheet(
      title = row.other?.name,
      actions = listOf(
        SheetAction(if (pinned) "Unpin" else "Pin") { onTogglePin(row.chat.chatId) }
      ),
      onDismiss = { sheetFor = null }
    )
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRow(
  row: ChatRowData,
  currentUserId: String,
  blocked: Boolean,
  onClick: () -> Unit,
  onLongClick: () -> Unit
) {
  val chat = row.chat
  val unread = chat.unreadCounts[currentUserId] ?: 0L
  val pinned = chat.pinnedBy.contains(currentUserId)
  val name = row.other?.name?.ifBlank { null } ?: "Unknown"
  val preview = when {
    blocked -> "Blocked"
    chat.lastSenderId == currentUserId -> "You: ${chat.lastMessage}"
    else -> chat.lastMessage
  }

  Column {
    Row(
      Modifier
        .fillMaxWidth()
        .combinedClickable(onClick = onClick, onLongClick = onLongClick)
        .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Avatar(
        url = row.other?.profileImage ?: "",
        name = name,
        size = 52.dp,
        online = row.other?.isOnline == true && !blocked
      )
      Spacer(Modifier.width(12.dp))
      Column(Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            name,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
          )
          Text(
            formatListTime(chat.timestamp),
            fontSize = 14.sp,
            color = if (unread > 0) MaterialTheme.colorScheme.primary else IOS.secondaryLabel
          )
        }
        Spacer(Modifier.size(2.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            preview,
            fontSize = 15.sp,
            color = if (unread > 0) MaterialTheme.colorScheme.onSurface else IOS.secondaryLabel,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
          )
          if (pinned && unread == 0L) {
            Icon(
              Icons.Filled.PushPin,
              contentDescription = "Pinned",
              tint = IOS.secondaryLabel,
              modifier = Modifier.padding(start = 8.dp).size(15.dp)
            )
          }
          if (unread > 0) {
            CountBadge(unread, Modifier.padding(start = 8.dp))
          }
        }
      }
    }
    IOSDivider(startInset = 80.dp)
  }
}
