package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.PrivacyKey
import com.example.data.model.PrivacyRule
import com.example.data.model.User
import com.example.data.repository.FriendStatus
import com.example.ui.components.IOSTabBar
import com.example.ui.navigation.MainTab
import com.example.ui.navigation.Screen
import com.example.ui.screens.auth.ProfileSetupScreen
import com.example.ui.screens.auth.SignInScreen
import com.example.ui.screens.chat.ChatScreen
import com.example.ui.screens.chats.ChatsScreen
import com.example.ui.screens.friends.FriendRequestsScreen
import com.example.ui.screens.friends.FriendsScreen
import com.example.ui.screens.profile.EditProfileScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.profile.UserProfileScreen
import com.example.ui.screens.search.SearchUsersScreen
import com.example.ui.screens.settings.BlockedUsersScreen
import com.example.ui.screens.settings.PrivacyScreen
import com.example.ui.screens.settings.PrivacySettingScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.settings.ThemeScreen
import com.example.ui.screens.splash.SplashScreen
import com.example.ui.screens.status.StatusScreen
import com.example.ui.theme.ChatNGTheme
import com.example.ui.theme.LocalAnimationsEnabled
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: MainViewModel by viewModels()

  private val notificationPermission =
    registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    if (Build.VERSION.SDK_INT >= 33) {
      notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    setContent {
      val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
      val accent by viewModel.accent.collectAsStateWithLifecycle()
      val highContrast by viewModel.increaseContrast.collectAsStateWithLifecycle()
      val animations by viewModel.animationsEnabled.collectAsStateWithLifecycle()

      ChatNGTheme(
        themeMode = themeMode,
        highContrast = highContrast,
        accent = accent,
        animationsEnabled = animations
      ) {
        MainAppContent(viewModel = viewModel)
      }
    }
  }

  override fun onStart() {
    super.onStart()
    viewModel.setPresence(true)
  }

  override fun onStop() {
    super.onStop()
    viewModel.setPresence(false)
  }
}

/** Screens deeper in the stack slide in from the right, like an iOS navigation push. */
private fun depth(screen: Screen): Int = when (screen) {
  is Screen.Splash, is Screen.SignIn, is Screen.ProfileSetup, is Screen.MainTabs -> 0
  is Screen.ThemeSettings, is Screen.Privacy -> 2
  is Screen.BlockedUsers, is Screen.PrivacySetting -> 3
  else -> 1
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
  val context = LocalContext.current
  val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
  val animationsOn = LocalAnimationsEnabled.current

  LaunchedEffect(Unit) {
    viewModel.toast.collect { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
  }

  AnimatedContent(
    targetState = currentScreen,
    contentKey = { it::class },
    transitionSpec = {
      val from = depth(initialState)
      val to = depth(targetState)
      when {
        !animationsOn -> EnterTransition.None togetherWith ExitTransition.None
        to > from ->
          slideInHorizontally(tween(300)) { it } togetherWith slideOutHorizontally(tween(300)) { -it / 4 }
        to < from ->
          slideInHorizontally(tween(300)) { -it / 4 } togetherWith slideOutHorizontally(tween(300)) { it }
        else -> fadeIn(tween(200)) togetherWith fadeOut(tween(200))
      }
    },
    label = "navigation",
    modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
  ) { screen ->
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
      ScreenContent(screen, viewModel)
    }
  }
}

@Composable
private fun ScreenContent(screen: Screen, viewModel: MainViewModel) {
  val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
  val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
  val chats by viewModel.chats.collectAsStateWithLifecycle()
  val friends by viewModel.friends.collectAsStateWithLifecycle()
  val userMap by viewModel.userMap.collectAsStateWithLifecycle()
  val incomingRequests by viewModel.incomingRequests.collectAsStateWithLifecycle()
  val outgoingRequests by viewModel.outgoingRequests.collectAsStateWithLifecycle()
  val blockedUids by viewModel.blockedUids.collectAsStateWithLifecycle()
  val statuses by viewModel.statuses.collectAsStateWithLifecycle()
  val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
  val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
  val activeMessages by viewModel.activeChatMessages.collectAsStateWithLifecycle()
  val isUploading by viewModel.isUploading.collectAsStateWithLifecycle()
  val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
  val accent by viewModel.accent.collectAsStateWithLifecycle()
  val increaseContrast by viewModel.increaseContrast.collectAsStateWithLifecycle()
  val animationsEnabled by viewModel.animationsEnabled.collectAsStateWithLifecycle()
  val privacy by viewModel.privacy.collectAsStateWithLifecycle()
  val viewedProfile by viewModel.viewedProfile.collectAsStateWithLifecycle()

  // Derived from collected state so the UI recomposes as requests/friends change.
  val friendStatusOf: (String) -> FriendStatus = { uid ->
    when {
      friends.any { it.uid == uid } -> FriendStatus.FRIENDS
      outgoingRequests.any { it.receiverId == uid } -> FriendStatus.REQUEST_SENT
      incomingRequests.any { it.senderId == uid } -> FriendStatus.REQUEST_RECEIVED
      else -> FriendStatus.NONE
    }
  }

  val myUid = currentUser?.uid ?: ""
  val totalUnreadChats = chats.sumOf { it.unreadCounts[myUid] ?: 0L }

  when (screen) {
    is Screen.Splash -> SplashScreen(onTimeout = { viewModel.onSplashComplete() })

    is Screen.SignIn -> SignInScreen(onAuthSuccess = { /* handled by the auth state listener */ })

    is Screen.ProfileSetup -> ProfileSetupScreen(
      userRepository = viewModel.userRepository,
      onProfileComplete = { viewModel.navigateTo(Screen.MainTabs) },
      onBack = { viewModel.signOut() }
    )

    is Screen.MainTabs -> Column(Modifier.fillMaxSize()) {
      Box(Modifier.weight(1f)) {
        when (currentTab) {
          MainTab.CHATS -> ChatsScreen(
            chats = chats,
            userMap = userMap,
            currentUserId = myUid,
            blockedUids = blockedUids,
            onChatSelected = { chat, other -> viewModel.openChat(chat, other) },
            onNewChatClicked = { viewModel.selectTab(MainTab.SEARCH) },
            onTogglePin = { viewModel.togglePinChat(it) }
          )

          MainTab.STATUS -> StatusScreen(
            currentUser = currentUser,
            friends = friends,
            statuses = statuses,
            isUploading = isUploading,
            onPost = { text, uri -> viewModel.postStatus(text, uri) },
            onDelete = { viewModel.deleteStatus(it) }
          )

          MainTab.FRIENDS -> FriendsScreen(
            friends = friends,
            pendingRequestCount = incomingRequests.size,
            onOpenRequests = { viewModel.navigateTo(Screen.FriendRequests) },
            onMessageFriend = { viewModel.startChatWithUser(it) },
            onViewProfile = { viewModel.openUserProfile(it.uid) },
            onUnfriend = { viewModel.unfriend(it.uid) },
            onBlock = { viewModel.blockUser(it.uid) }
          )

          MainTab.SEARCH -> SearchUsersScreen(
            searchResults = searchResults,
            searchQuery = searchQuery,
            blockedUids = blockedUids,
            onQueryChange = { viewModel.setSearchQuery(it) },
            onSendFriendRequest = { viewModel.sendFriendRequest(it) },
            onStartChat = { viewModel.startChatWithUser(it) },
            onOpenRequests = { viewModel.navigateTo(Screen.FriendRequests) },
            onViewProfile = { viewModel.openUserProfile(it.uid) },
            getFriendStatus = friendStatusOf,
            onBack = { viewModel.selectTab(MainTab.CHATS) },
            isEmbeddedInTab = true
          )

          MainTab.PROFILE -> ProfileScreen(
            user = currentUser,
            friendsCount = friends.size,
            chatsCount = chats.count { it.lastMessage.isNotBlank() },
            onEditProfile = { viewModel.navigateTo(Screen.EditProfile) },
            onOpenSettings = { viewModel.navigateTo(Screen.Settings) }
          )
        }
      }
      IOSTabBar(
        selectedTab = currentTab,
        onTabSelected = { viewModel.selectTab(it) },
        unreadChatsCount = totalUnreadChats,
        pendingFriendRequestsCount = incomingRequests.size
      )
    }

    is Screen.ChatConversation -> {
      val otherUser = userMap[screen.otherUid] ?: User(
        uid = screen.otherUid,
        name = screen.otherName,
        userId = screen.otherUserId,
        profileImage = screen.otherAvatar,
        isOnline = screen.isOnline
      )
      ChatScreen(
        chatId = screen.chatId,
        otherUser = otherUser,
        currentUserId = myUid,
        messages = activeMessages,
        chat = chats.firstOrNull { it.chatId == screen.chatId },
        isBlocked = screen.otherUid in blockedUids,
        isUploading = isUploading,
        onSendMessage = { text, type -> viewModel.sendMessage(screen.chatId, text, type) },
        onSendImage = { viewModel.sendImage(screen.chatId, it) },
        onUnsend = { viewModel.deleteMessage(it) },
        onTyping = { viewModel.setTyping(screen.chatId, it) },
        onMarkSeen = { viewModel.markActiveChatSeen(screen.chatId) },
        onBlock = { viewModel.blockUser(screen.otherUid) },
        onUnblock = { viewModel.unblockUser(screen.otherUid) },
        onOpenProfile = { viewModel.openUserProfile(screen.otherUid) },
        onBack = { viewModel.closeChat(screen.chatId) }
      )
    }

    is Screen.FriendRequests -> FriendRequestsScreen(
      incomingRequests = incomingRequests,
      outgoingRequests = outgoingRequests,
      userMap = userMap,
      onAccept = { viewModel.acceptFriendRequest(it) },
      onReject = { viewModel.rejectFriendRequest(it) },
      onBack = { viewModel.selectTab(MainTab.FRIENDS) }
    )

    is Screen.SearchUsers -> SearchUsersScreen(
      searchResults = searchResults,
      searchQuery = searchQuery,
      blockedUids = blockedUids,
      onQueryChange = { viewModel.setSearchQuery(it) },
      onSendFriendRequest = { viewModel.sendFriendRequest(it) },
      onStartChat = { viewModel.startChatWithUser(it) },
      onOpenRequests = { viewModel.navigateTo(Screen.FriendRequests) },
      onViewProfile = { viewModel.openUserProfile(it.uid) },
      getFriendStatus = friendStatusOf,
      onBack = { viewModel.navigateTo(Screen.MainTabs) },
      isEmbeddedInTab = false
    )

    is Screen.EditProfile -> EditProfileScreen(
      currentUser = currentUser,
      userRepository = viewModel.userRepository,
      onProfileUpdated = { viewModel.selectTab(MainTab.PROFILE) },
      onBack = { viewModel.selectTab(MainTab.PROFILE) }
    )

    is Screen.Settings -> SettingsScreen(
      user = currentUser,
      isUploading = isUploading,
      themeMode = themeMode,
      increaseContrast = increaseContrast,
      animationsEnabled = animationsEnabled,
      onChangePhoto = { viewModel.updateProfilePhoto(it) },
      onEditName = { viewModel.updateName(it) },
      onEditUsername = { viewModel.updateUsername(it) },
      onEditEmail = { viewModel.updateEmail(it) },
      onEditPhone = { viewModel.updatePhone(it) },
      onIncreaseContrast = { viewModel.setIncreaseContrast(it) },
      onAnimations = { viewModel.setAnimationsEnabled(it) },
      onOpenTheme = { viewModel.navigateTo(Screen.ThemeSettings) },
      onOpenPrivacy = { viewModel.navigateTo(Screen.Privacy) },
      onLogout = { viewModel.signOut() },
      onBack = { viewModel.selectTab(MainTab.PROFILE) }
    )

    is Screen.ThemeSettings -> ThemeScreen(
      themeMode = themeMode,
      accent = accent,
      onThemeMode = { viewModel.setThemeMode(it) },
      onAccent = { viewModel.setAccent(it) },
      onBack = { viewModel.navigateTo(Screen.Settings) }
    )

    is Screen.Privacy -> PrivacyScreen(
      settings = privacy,
      blockedCount = blockedUids.size,
      onOpen = { viewModel.navigateTo(Screen.PrivacySetting(it)) },
      onOpenBlocked = { viewModel.navigateTo(Screen.BlockedUsers) },
      onBack = { viewModel.navigateTo(Screen.Settings) }
    )

    is Screen.PrivacySetting -> {
      // People you can choose to exclude: friends plus anyone you've chatted with.
      val chatPartners = chats.flatMap { it.participants }.filter { it != myUid }
      val candidates = (friends.map { it.uid } + chatPartners).distinct()
        .filter { it !in blockedUids }
        .mapNotNull { userMap[it] }
        .let { list ->
          if (screen.key.options.contains(com.example.data.model.PrivacyMode.FRIENDS_EXCEPT) &&
            !screen.key.options.contains(com.example.data.model.PrivacyMode.EVERYONE_EXCEPT)
          ) list.filter { u -> friends.any { it.uid == u.uid } } else list
        }
        .sortedBy { it.name.lowercase() }
      PrivacySettingScreen(
        key = screen.key,
        rule = privacy[screen.key] ?: PrivacyRule(screen.key.default),
        candidates = candidates,
        onChange = { mode, excluded -> viewModel.setPrivacy(screen.key, mode, excluded) },
        onBack = { viewModel.navigateTo(Screen.Privacy) }
      )
    }

    is Screen.UserProfile -> UserProfileScreen(
      user = userMap[screen.uid] ?: User(uid = screen.uid, name = "Profile"),
      visible = viewedProfile,
      friendStatus = friendStatusOf(screen.uid),
      isBlocked = screen.uid in blockedUids,
      onMessage = { userMap[screen.uid]?.let { viewModel.startChatWithUser(it) } },
      onAddFriend = { viewModel.sendFriendRequest(screen.uid) },
      onOpenRequests = { viewModel.navigateTo(Screen.FriendRequests) },
      onBlock = { viewModel.blockUser(screen.uid) },
      onUnblock = { viewModel.unblockUser(screen.uid) },
      onBack = { viewModel.closeUserProfile() }
    )

    is Screen.BlockedUsers -> BlockedUsersScreen(
      blocked = blockedUids.mapNotNull { userMap[it] },
      onUnblock = { viewModel.unblockUser(it.uid) },
      onBack = { viewModel.navigateTo(Screen.Privacy) }
    )
  }
}
