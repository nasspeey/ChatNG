package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class User(
  val uid: String = "",
  val name: String = "",
  val email: String = "",
  val userId: String = "",
  val profileImage: String = "",
  val bio: String = "",
  val phoneNumber: String = "",
  val isOnline: Boolean = false,
  @ServerTimestamp val lastSeen: Timestamp? = null,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)
