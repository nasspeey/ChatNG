package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Message(
  @DocumentId val messageId: String = "",
  val chatId: String = "",
  val senderId: String = "",
  val message: String = "",
  @ServerTimestamp val timestamp: Timestamp? = null,
  val seen: Boolean = false,
  val delivered: Boolean = true,
  val type: String = "text" // text, image, file
)
