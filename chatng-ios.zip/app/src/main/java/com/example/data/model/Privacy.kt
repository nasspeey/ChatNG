package com.example.data.model

enum class PrivacyMode(val label: String) {
  ONLY_ME("Only me"),
  FRIENDS("My friends"),
  EVERYONE("Everyone"),
  NOBODY("Nobody"),
  EVERYONE_EXCEPT("Everyone except…"),
  FRIENDS_EXCEPT("My friends except…");

  val usesExceptions: Boolean get() = this == EVERYONE_EXCEPT || this == FRIENDS_EXCEPT
}

/** One privacy control, the choices it offers, and the value new accounts start with. */
enum class PrivacyKey(
  val field: String,
  val title: String,
  val options: List<PrivacyMode>,
  val default: PrivacyMode
) {
  PERSONAL_INFO(
    "personalInfo", "Who can see my personal info",
    listOf(PrivacyMode.ONLY_ME, PrivacyMode.FRIENDS, PrivacyMode.EVERYONE_EXCEPT), PrivacyMode.FRIENDS
  ),
  PROFILE_PICTURE(
    "profilePicture", "Profile picture",
    listOf(PrivacyMode.ONLY_ME, PrivacyMode.FRIENDS, PrivacyMode.EVERYONE_EXCEPT), PrivacyMode.EVERYONE_EXCEPT
  ),
  ABOUT(
    "about", "About",
    listOf(PrivacyMode.EVERYONE, PrivacyMode.ONLY_ME, PrivacyMode.FRIENDS, PrivacyMode.EVERYONE_EXCEPT), PrivacyMode.EVERYONE
  ),
  STATUS(
    "status", "Status",
    listOf(PrivacyMode.ONLY_ME, PrivacyMode.FRIENDS, PrivacyMode.FRIENDS_EXCEPT), PrivacyMode.FRIENDS
  ),
  GROUP(
    "group", "Group",
    listOf(PrivacyMode.NOBODY, PrivacyMode.FRIENDS, PrivacyMode.EVERYONE), PrivacyMode.FRIENDS
  ),
  EMAIL(
    "email", "Email",
    listOf(PrivacyMode.ONLY_ME, PrivacyMode.FRIENDS, PrivacyMode.FRIENDS_EXCEPT), PrivacyMode.ONLY_ME
  ),
  PHONE(
    "phone", "Phone number",
    listOf(PrivacyMode.ONLY_ME, PrivacyMode.FRIENDS, PrivacyMode.FRIENDS_EXCEPT), PrivacyMode.ONLY_ME
  )
}

/** A chosen mode plus the people it excludes (only used by the "…except" modes). */
data class PrivacyRule(
  val mode: PrivacyMode,
  val excluded: List<String> = emptyList()
)

/** The signed-in user's own protected data, from the users/{uid}/private collection. */
data class PrivateData(
  val photo: String = "",
  val about: String = "",
  val email: String = "",
  val phone: String = "",
  val settings: Map<PrivacyKey, PrivacyRule> = emptyMap(),
  val loaded: Boolean = false
) {
  fun rule(key: PrivacyKey): PrivacyRule = settings[key] ?: PrivacyRule(key.default)
}

/** What the viewer is allowed to see of someone else; null = hidden or not set. */
data class VisibleProfile(
  val photo: String? = null,
  val about: String? = null,
  val email: String? = null,
  val phone: String? = null
)
