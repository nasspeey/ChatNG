package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.Friend
import com.example.data.model.FriendRequest
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

enum class FriendStatus {
  NONE,
  REQUEST_SENT,
  REQUEST_RECEIVED,
  FRIENDS
}

class FriendRepository(private val db: FirebaseFirestore) {

  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    )
  )

  private val auth = FirebaseAuth.getInstance(db.app)

  fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be authenticated before performing friend operations")
  }

  suspend fun sendFriendRequest(receiverId: String) {
    val senderId = requireUserId()
    if (senderId == receiverId) return

    val reqDoc = db.collection("friendRequests").document("${senderId}_$receiverId")
    try {
      val existing = reqDoc.get().await()
      if (existing.exists()) {
        // Only a previously rejected request can be re-sent.
        if (existing.getString("status") == "rejected") {
          reqDoc.update(
            mapOf("status" to "pending", "createdAt" to FieldValue.serverTimestamp())
          ).await()
        }
        return
      }
      reqDoc.set(
        mapOf(
          "requestId" to reqDoc.id,
          "senderId" to senderId,
          "receiverId" to receiverId,
          "status" to "pending",
          "createdAt" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, reqDoc.path)
      throw e
    }
  }

  fun observeIncomingRequests(uid: String): Flow<List<FriendRequest>> {
    val path = "friendRequests"
    return db.collection(path)
      .whereEqualTo("receiverId", uid)
      .whereEqualTo("status", "pending")
      .snapshots()
      .map { snap -> snap.documents.mapNotNull { d -> d.toObject(FriendRequest::class.java)?.copy(requestId = d.id) } }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        emit(emptyList())
      }
  }

  fun observeOutgoingRequests(uid: String): Flow<List<FriendRequest>> {
    val path = "friendRequests"
    return db.collection(path)
      .whereEqualTo("senderId", uid)
      .whereEqualTo("status", "pending")
      .snapshots()
      .map { snap -> snap.documents.mapNotNull { d -> d.toObject(FriendRequest::class.java)?.copy(requestId = d.id) } }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        emit(emptyList())
      }
  }

  suspend fun acceptFriendRequest(requestId: String, senderId: String, receiverId: String) {
    requireUserId()
    val reqPath = "friendRequests/$requestId"

    try {
      // One atomic batch: either the request is accepted and both friendship
      // rows exist, or nothing changes.
      val batch = db.batch()
      batch.update(db.collection("friendRequests").document(requestId), "status", "accepted")
      batch.set(
        db.collection("friends").document("${senderId}_$receiverId"),
        mapOf(
          "uid" to senderId,
          "friendUid" to receiverId,
          "createdAt" to FieldValue.serverTimestamp()
        )
      )
      batch.set(
        db.collection("friends").document("${receiverId}_$senderId"),
        mapOf(
          "uid" to receiverId,
          "friendUid" to senderId,
          "createdAt" to FieldValue.serverTimestamp()
        )
      )
      batch.commit().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, reqPath)
      throw e
    }
  }

  suspend fun rejectFriendRequest(requestId: String) {
    val reqPath = "friendRequests/$requestId"
    try {
      db.collection("friendRequests").document(requestId).update(
        "status", "rejected"
      ).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, reqPath)
      throw e
    }
  }

  fun observeFriends(uid: String): Flow<List<Friend>> {
    val path = "friends"
    return db.collection(path)
      .whereEqualTo("uid", uid)
      .snapshots()
      .map { it.toObjects(Friend::class.java) }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        emit(emptyList())
      }
  }

  /** Removes the friendship both ways and clears old requests so people can re-add each other. */
  suspend fun unfriend(otherUid: String) {
    val me = requireUserId()
    try {
      val batch = db.batch()
      batch.delete(db.collection("friends").document("${me}_$otherUid"))
      batch.delete(db.collection("friends").document("${otherUid}_$me"))
      batch.delete(db.collection("friendRequests").document("${me}_$otherUid"))
      batch.delete(db.collection("friendRequests").document("${otherUid}_$me"))
      batch.commit().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, "friends/${me}_$otherUid")
      throw e
    }
  }

  /** Blocks a user: stored under blocks/, and any friendship/request is removed. */
  suspend fun blockUser(otherUid: String) {
    val me = requireUserId()
    if (me == otherUid) return
    try {
      val batch = db.batch()
      batch.set(
        db.collection("blocks").document("${me}_$otherUid"),
        mapOf(
          "uid" to me,
          "blockedUid" to otherUid,
          "createdAt" to FieldValue.serverTimestamp()
        )
      )
      batch.delete(db.collection("friends").document("${me}_$otherUid"))
      batch.delete(db.collection("friends").document("${otherUid}_$me"))
      batch.delete(db.collection("friendRequests").document("${me}_$otherUid"))
      batch.delete(db.collection("friendRequests").document("${otherUid}_$me"))
      batch.commit().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "blocks/${me}_$otherUid")
      throw e
    }
  }

  suspend fun unblockUser(otherUid: String) {
    val me = requireUserId()
    try {
      db.collection("blocks").document("${me}_$otherUid").delete().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, "blocks/${me}_$otherUid")
      throw e
    }
  }

  /** UIDs the current user has blocked. */
  fun observeBlocked(uid: String): Flow<Set<String>> {
    val path = "blocks"
    return db.collection(path)
      .whereEqualTo("uid", uid)
      .snapshots()
      .map { snap -> snap.documents.mapNotNull { it.getString("blockedUid") }.toSet() }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        emit(emptySet())
      }
  }

  fun observeFriendStatus(currentUid: String, targetUid: String): Flow<FriendStatus> {
    val friendsFlow = observeFriends(currentUid)
    val outgoingFlow = observeOutgoingRequests(currentUid)
    val incomingFlow = observeIncomingRequests(currentUid)

    return combine(friendsFlow, outgoingFlow, incomingFlow) { friends, outgoing, incoming ->
      when {
        friends.any { it.friendUid == targetUid } -> FriendStatus.FRIENDS
        outgoing.any { it.receiverId == targetUid } -> FriendStatus.REQUEST_SENT
        incoming.any { it.senderId == targetUid } -> FriendStatus.REQUEST_RECEIVED
        else -> FriendStatus.NONE
      }
    }
  }
}
