package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.PrivacyKey
import com.example.data.model.PrivacyMode
import com.example.data.model.PrivacyRule
import com.example.data.model.PrivateData
import com.example.data.model.User
import com.example.data.model.VisibleProfile
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import com.google.firebase.storage.FirebaseStorage
import android.net.Uri
import com.google.firebase.installations.FirebaseInstallations
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.tasks.await

class UserRepository(private val db: FirebaseFirestore) {

  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    )
  )

  private val auth = FirebaseAuth.getInstance(db.app)

  fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be authenticated before performing user operations")
  }

  fun observeUser(uid: String): Flow<User?> = callbackFlow {
    val path = "users/$uid"
    val registration = db.collection("users").document(uid)
      .addSnapshotListener { snapshot, error ->
        if (error != null) {
          handleFirestoreError(error, OperationType.GET, path)
          close(error)
          return@addSnapshotListener
        }
        val user = snapshot?.toObject(User::class.java)
        trySend(user)
      }
    awaitClose { registration.remove() }
  }

  suspend fun getUser(uid: String): User? {
    val path = "users/$uid"
    return try {
      val doc = db.collection("users").document(uid).get().await()
      doc.toObject(User::class.java)
    } catch (e: Exception) {
      println("GET_USER_EXCEPTION: ${e.message}")
      e.printStackTrace()
      handleFirestoreError(e, OperationType.GET, path)
      null
    }
  }

  suspend fun isUserIdAvailable(candidateUserId: String, currentUid: String? = null): Boolean {
    val cleanId = candidateUserId.trim().removePrefix("@").lowercase()
    if (cleanId.length < 3) return false
    val path = "users"
    return try {
      val snapshot = db.collection(path)
        .whereEqualTo("userId", cleanId)
        .get()
        .await()
      if (snapshot.isEmpty) {
        true
      } else {
        // If the only document is current user's profile, it is available for them
        if (currentUid != null && snapshot.documents.size == 1 && snapshot.documents.first().id == currentUid) {
          true
        } else {
          false
        }
      }
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.LIST, path)
      false
    }
  }

  /**
   * Public fields (name, handle, presence) go on users/{uid}. Everything the owner
   * can restrict (photo, about, email, phone) goes into protected the users/{uid}/private collection
   * documents, which the Firestore rules only release to permitted viewers.
   */
  suspend fun saveProfile(user: User) {
    val uid = requireUserId()
    val cleanUserId = user.userId.trim().removePrefix("@").lowercase()
    val docRef = db.collection("users").document(uid)
    val path = docRef.path
    try {
      val imageUrl = uploadProfileImageIfLocal(uid, user.profileImage)
      val email = user.email.ifBlank { auth.currentUser?.email ?: "" }
      val phone = user.phoneNumber.ifBlank { auth.currentUser?.phoneNumber ?: "" }

      docRef.set(
        mapOf(
          "uid" to uid,
          "name" to user.name.trim(),
          "userId" to cleanUserId,
          "profileImage" to "",
          "isOnline" to true,
          "lastSeen" to FieldValue.serverTimestamp(),
          "createdAt" to (user.createdAt ?: FieldValue.serverTimestamp()),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()

      writePrivateDocs(uid, photo = imageUrl, about = user.bio.trim(), email = email, phone = phone)
      writeDefaultSettingsIfMissing(uid)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, path)
      throw e
    }
  }

  private suspend fun writePrivateDocs(uid: String, photo: String, about: String, email: String, phone: String) {
    val priv = db.collection("users").document(uid).collection("private")
    val now = FieldValue.serverTimestamp()
    val batch = db.batch()
    batch.set(priv.document("photo"), mapOf("url" to photo, "updatedAt" to now))
    batch.set(priv.document("about"), mapOf("text" to about, "updatedAt" to now))
    batch.set(priv.document("email"), mapOf("value" to email, "updatedAt" to now))
    batch.set(priv.document("phone"), mapOf("value" to phone, "updatedAt" to now))
    batch.commit().await()
  }

  private suspend fun writeDefaultSettingsIfMissing(uid: String) {
    val ref = db.collection("users").document(uid).collection("private").document("settings")
    if (ref.get().await().exists()) return
    ref.set(PrivacyKey.entries.associate { it.field to ruleToMap(PrivacyRule(it.default)) }).await()
  }

  private fun ruleToMap(rule: PrivacyRule): Map<String, Any> =
    mapOf("mode" to rule.mode.name, "excluded" to rule.excluded)

  /** Persists one privacy control (merge, so other controls are untouched). */
  suspend fun savePrivacy(key: PrivacyKey, rule: PrivacyRule) {
    val uid = requireUserId()
    val ref = db.collection("users").document(uid).collection("private").document("settings")
    try {
      ref.set(mapOf(key.field to ruleToMap(rule)), SetOptions.merge()).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, ref.path)
      throw e
    }
  }

  /** Live copy of the signed-in user's own protected data. */
  fun observePrivate(uid: String): Flow<PrivateData> = callbackFlow {
    val registration = db.collection("users").document(uid).collection("private")
      .addSnapshotListener { snapshot, error ->
        if (error != null) {
          handleFirestoreError(error, OperationType.LIST, "users/$uid/private")
          trySend(PrivateData(loaded = true))
          return@addSnapshotListener
        }
        val docs = snapshot?.documents.orEmpty().associateBy { it.id }
        trySend(
          PrivateData(
            photo = docs["photo"]?.getString("url") ?: "",
            about = docs["about"]?.getString("text") ?: "",
            email = docs["email"]?.getString("value") ?: "",
            phone = docs["phone"]?.getString("value") ?: "",
            settings = parseSettings(docs["settings"]?.data),
            loaded = true
          )
        )
      }
    awaitClose { registration.remove() }
  }

  private fun parseSettings(data: Map<String, Any>?): Map<PrivacyKey, PrivacyRule> {
    if (data == null) return emptyMap()
    return PrivacyKey.entries.mapNotNull { key ->
      val raw = data[key.field] as? Map<*, *> ?: return@mapNotNull null
      val mode = runCatching { PrivacyMode.valueOf(raw["mode"] as? String ?: "") }.getOrNull()
        ?.takeIf { it in key.options } ?: key.default
      val excluded = (raw["excluded"] as? List<*>)?.filterIsInstance<String>() ?: emptyList()
      key to PrivacyRule(mode, excluded)
    }.toMap()
  }

  /** Reads someone's profile picture if the rules allow it; blank otherwise. */
  suspend fun getPhoto(uid: String): String = try {
    db.collection("users").document(uid).collection("private").document("photo")
      .get().await().getString("url") ?: ""
  } catch (e: Exception) {
    ""
  }

  /** Fetches whatever the owner's privacy settings let the current user see. */
  suspend fun getVisibleProfile(uid: String): VisibleProfile = coroutineScope {
    val priv = db.collection("users").document(uid).collection("private")
    suspend fun read(doc: String, field: String): String? = try {
      val snap = priv.document(doc).get().await()
      if (snap.exists()) snap.getString(field)?.takeIf { it.isNotBlank() } else null
    } catch (e: Exception) {
      null // denied by the owner's privacy settings
    }
    val photo = async { read("photo", "url") }
    val about = async { read("about", "text") }
    val email = async { read("email", "value") }
    val phone = async { read("phone", "value") }
    VisibleProfile(photo.await(), about.await(), email.await(), phone.await())
  }

  /**
   * One-time upgrade for profiles created before privacy controls existed: move
   * email / phone / about / photo out of the public document into private ones.
   */
  suspend fun migrateLegacyProfile(raw: User, existing: PrivateData) {
    val uid = requireUserId()
    val hasLegacy = raw.email.isNotBlank() || raw.phoneNumber.isNotBlank() ||
      raw.bio.isNotBlank() || raw.profileImage.isNotBlank()
    if (!hasLegacy) return
    try {
      writePrivateDocs(
        uid,
        photo = existing.photo.ifBlank { raw.profileImage },
        about = existing.about.ifBlank { raw.bio },
        email = existing.email.ifBlank { raw.email.ifBlank { auth.currentUser?.email ?: "" } },
        phone = existing.phone.ifBlank { raw.phoneNumber.ifBlank { auth.currentUser?.phoneNumber ?: "" } }
      )
      writeDefaultSettingsIfMissing(uid)
      db.collection("users").document(uid).update(
        mapOf(
          "email" to FieldValue.delete(),
          "phoneNumber" to FieldValue.delete(),
          "bio" to FieldValue.delete(),
          "profileImage" to ""
        )
      ).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "users/$uid")
    }
  }

  /**
   * Local picker URIs (content:// or file://) are only meaningful on this
   * device, so they are uploaded to Storage and replaced by a download URL
   * that other users can load. http(s) URLs and blanks pass through.
   */
  private suspend fun uploadProfileImageIfLocal(uid: String, image: String): String {
    if (!(image.startsWith("content://") || image.startsWith("file://"))) return image
    val ref = FirebaseStorage.getInstance(db.app)
      .reference.child("profile_images/$uid/avatar_${System.currentTimeMillis()}.jpg")
    ref.putFile(Uri.parse(image)).await()
    return ref.downloadUrl.await().toString()
  }

  /** Stores this device's FCM token under users/{uid}/devices/{installationId}. */
  suspend fun registerDevice(token: String? = null) {
    val uid = auth.currentUser?.uid ?: return
    try {
      val fcmToken = token ?: FirebaseMessaging.getInstance().token.await()
      val deviceId = FirebaseInstallations.getInstance(db.app).id.await()
      db.collection("users").document(uid)
        .collection("devices").document(deviceId)
        .set(
          mapOf(
            "token" to fcmToken,
            "platform" to "android",
            "updatedAt" to FieldValue.serverTimestamp(),
            "notificationsEnabled" to true
          )
        ).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "users/$uid/devices")
    }
  }

  /** Stops push notifications to this device after sign-out. */
  suspend fun unregisterDevice() {
    val uid = auth.currentUser?.uid ?: return
    try {
      val deviceId = FirebaseInstallations.getInstance(db.app).id.await()
      db.collection("users").document(uid).collection("devices").document(deviceId).delete().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, "users/$uid/devices")
    }
  }

  suspend fun updatePresence(uid: String, isOnline: Boolean) {
    val path = "users/$uid"
    try {
      db.collection("users").document(uid).update(
        mapOf(
          "isOnline" to isOnline,
          "lastSeen" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, path)
    }
  }

  /**
   * Server-side prefix search on the unique handle, capped at 20 results.
   * Empty queries return the first 20 users (alphabetical) for discovery.
   */
  fun searchUsersByUserId(query: String): Flow<List<User>> {
    val clean = query.trim().removePrefix("@").lowercase()
    val currentUid = auth.currentUser?.uid ?: ""
    val path = "users"
    val base = db.collection(path).orderBy("userId")
    val q = if (clean.isEmpty()) base else base.startAt(clean).endAt(clean + "\uf8ff")
    return q.limit(21)
      .snapshots()
      .map { snapshot ->
        snapshot.toObjects(User::class.java)
          .filter { it.uid != currentUid }
          .take(20)
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        emit(emptyList())
      }
  }

  /** Live profiles (presence, avatar, name) for just the given users. */
  fun observeUsers(uids: Collection<String>): Flow<List<User>> {
    val chunks = uids.filter { it.isNotBlank() }.distinct().chunked(10)
    if (chunks.isEmpty()) return flowOf(emptyList())
    val flows = chunks.map { chunk ->
      db.collection("users")
        .whereIn("uid", chunk)
        .snapshots()
        .map { it.toObjects(User::class.java) }
        .catch { error ->
          if (error is Exception) handleFirestoreError(error, OperationType.LIST, "users")
          emit(emptyList())
        }
    }
    return combine(flows) { arrays -> arrays.flatMap { it } }
  }

  /** Fetches only the profiles that are needed (chat partners, friends). */
  suspend fun getUsers(uids: Collection<String>): List<User> {
    return uids.distinct().chunked(10).flatMap { chunk ->
      try {
        db.collection("users")
          .whereIn("uid", chunk)
          .get()
          .await()
          .toObjects(User::class.java)
      } catch (e: Exception) {
        handleFirestoreError(e, OperationType.LIST, "users")
        emptyList()
      }
    }
  }
}
