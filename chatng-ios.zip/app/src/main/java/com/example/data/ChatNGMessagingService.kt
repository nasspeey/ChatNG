package com.example.data

import com.example.data.repository.UserRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessagingService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Keeps the server-side FCM token current. Notification messages are shown by
 * the system while the app is in the background, so no display code is needed.
 */
class ChatNGMessagingService : FirebaseMessagingService() {

  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

  override fun onNewToken(token: String) {
    if (FirebaseAuth.getInstance().currentUser == null) return
    scope.launch { UserRepository(applicationContext).registerDevice(token) }
  }
}
