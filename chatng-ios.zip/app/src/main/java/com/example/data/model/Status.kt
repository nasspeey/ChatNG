package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties

/** A 24-hour "story": text and/or a photo, visible to the viewers listed at post time. */
@IgnoreExtraProperties
data class Status(
  @DocumentId val statusId: String = "",
  val uid: String = "",
  val text: String = "",
  val imageUrl: String = "",
  val viewers: List<String> = emptyList(),
  val createdAt: Timestamp? = null,
  val expiresAt: Timestamp? = null
)
