package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.Chat
import com.example.data.model.Message
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID
import android.net.Uri
import com.google.firebase.storage.FirebaseStorage

class ChatRepository(private val db: FirebaseFirestore) {

  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    )
  )

  private val auth = FirebaseAuth.getInstance(db.app)

  fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be authenticated before performing chat operations")
  }

  fun observeChats(uid: String): Flow<List<Chat>> {
    val path = "chats"
    return db.collection(path)
      .whereArrayContains("participants", uid)
      .snapshots()
      .map { snapshot ->
        val list = snapshot.toObjects(Chat::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        list.sortedByDescending { it.timestamp?.toDate()?.time ?: it.createdAt?.toDate()?.time ?: 0L }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        emit(emptyList())
      }
  }

  fun observeMessages(chatId: String): Flow<List<Message>> {
    val path = "messages"
    return db.collection(path)
      .whereEqualTo("chatId", chatId)
      .snapshots()
      .map { snapshot ->
        val list = snapshot.toObjects(Message::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        list.sortedBy { it.timestamp?.toDate()?.time ?: 0L }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        emit(emptyList())
      }
  }

  suspend fun getOrCreateChatId(otherUid: String): String {
    val currentUid = requireUserId()
    // Canonical chat ID: sorted UIDs combined with '_'
    val sortedUids = listOf(currentUid, otherUid).sorted()
    val chatId = "${sortedUids[0]}_${sortedUids[1]}"
    val chatDoc = db.collection("chats").document(chatId)

    try {
      val existing = chatDoc.get().await()
      if (!existing.exists()) {
        val initialData = mapOf(
          "chatId" to chatId,
          "participants" to sortedUids,
          "lastMessage" to "",
          "lastSenderId" to "",
          "timestamp" to FieldValue.serverTimestamp(),
          "pinnedBy" to emptyList<String>(),
          "unreadCounts" to mapOf(currentUid to 0L, otherUid to 0L),
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp()
        )
        chatDoc.set(initialData).await()
      }
      return chatId
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, chatDoc.path)
      throw e
    }
  }

  suspend fun sendMessage(chatId: String, text: String, type: String = "text") {
    val senderId = requireUserId()
    val cleanText = text.trim()
    if (cleanText.isEmpty()) return

    val messageId = UUID.randomUUID().toString()
    val msgDoc = db.collection("messages").document(messageId)
    val chatDoc = db.collection("chats").document(chatId)

    try {
      // The receiving participant is derived from the canonical chat ID
      // ("<uidA>_<uidB>"), so no read is needed before writing.
      val receiverId = chatId.split("_").firstOrNull { it != senderId }

      val batch = db.batch()
      batch.set(
        msgDoc,
        mapOf(
          "messageId" to messageId,
          "chatId" to chatId,
          "senderId" to senderId,
          "message" to cleanText,
          "seen" to false,
          "delivered" to true,
          "type" to type,
          "timestamp" to FieldValue.serverTimestamp()
        )
      )

      val chatUpdate = mutableMapOf<String, Any>(
        "lastMessage" to (if (type == "image") "\uD83D\uDCF7 Photo" else cleanText),
        "lastSenderId" to senderId,
        "timestamp" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
        "unreadCounts.$senderId" to 0L
      )
      // Atomic server-side increment: safe under concurrent senders.
      if (receiverId != null) {
        chatUpdate["unreadCounts.$receiverId"] = FieldValue.increment(1L)
      }
      batch.update(chatDoc, chatUpdate)
      batch.commit().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, msgDoc.path)
      throw e
    }
  }

  /** Uploads a photo to Storage, then sends it as an "image" message holding the download URL. */
  suspend fun sendImage(chatId: String, uri: Uri) {
    val senderId = requireUserId()
    try {
      val ref = FirebaseStorage.getInstance(db.app)
        .reference.child("chat_attachments/$chatId/${UUID.randomUUID()}.jpg")
      ref.putFile(uri).await()
      val url = ref.downloadUrl.await().toString()
      sendMessage(chatId, url, "image")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "chat_attachments/$chatId")
      throw e
    }
  }

  /** "Unsend": a sender can remove their own message for everyone. */
  suspend fun deleteMessage(messageId: String) {
    val doc = db.collection("messages").document(messageId)
    try {
      doc.delete().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, doc.path)
      throw e
    }
  }

  /** Writes/removes the caller's "typing" marker on the chat document. */
  suspend fun setTyping(chatId: String, typing: Boolean) {
    val uid = auth.currentUser?.uid ?: return
    try {
      db.collection("chats").document(chatId).update(
        "typing.$uid", if (typing) FieldValue.serverTimestamp() else FieldValue.delete()
      ).await()
    } catch (e: Exception) {
      // Typing indicators are best-effort; never surface errors.
    }
  }

  suspend fun markChatSeen(chatId: String) {
    val currentUid = requireUserId()
    val chatDoc = db.collection("chats").document(chatId)

    try {
      val batch = db.batch()
      batch.update(chatDoc, "unreadCounts.$currentUid", 0L)

      // Only messages from the other participant that are still unseen.
      val unreadSnapshot = db.collection("messages")
        .whereEqualTo("chatId", chatId)
        .whereEqualTo("seen", false)
        .get()
        .await()

      unreadSnapshot.documents
        .filter { it.getString("senderId") != currentUid }
        .forEach { batch.update(it.reference, "seen", true) }

      batch.commit().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, chatDoc.path)
    }
  }

  suspend fun togglePinChat(chatId: String): Boolean {
    val currentUid = requireUserId()
    val chatDoc = db.collection("chats").document(chatId)

    try {
      val snap = chatDoc.get().await()
      val pinnedBy = (snap.get("pinnedBy") as? List<*>)?.map { it.toString() } ?: emptyList()
      val isPinned = pinnedBy.contains(currentUid)

      if (isPinned) {
        chatDoc.update("pinnedBy", FieldValue.arrayRemove(currentUid)).await()
        return false
      } else {
        // Enforce max 3 pinned chats per user requirement
        val allUserChats = db.collection("chats")
          .whereArrayContains("participants", currentUid)
          .get()
          .await()
        val userPinnedCount = allUserChats.documents.count {
          val list = (it.get("pinnedBy") as? List<*>)?.map { item -> item.toString() } ?: emptyList()
          list.contains(currentUid)
        }
        if (userPinnedCount >= 3) {
          return false
        }
        chatDoc.update("pinnedBy", FieldValue.arrayUnion(currentUid)).await()
        return true
      }
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, chatDoc.path)
      return false
    }
  }
}
