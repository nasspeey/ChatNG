package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Friend(
  @DocumentId val id: String = "",
  val uid: String = "",
  val friendUid: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null
)
