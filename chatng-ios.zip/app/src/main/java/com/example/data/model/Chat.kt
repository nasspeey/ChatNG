package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Chat(
  @DocumentId val chatId: String = "",
  val participants: List<String> = emptyList(),
  val lastMessage: String = "",
  val lastSenderId: String = "",
  @ServerTimestamp val timestamp: Timestamp? = null,
  val pinnedBy: List<String> = emptyList(),
  val unreadCounts: Map<String, Long> = emptyMap(),
  val typing: Map<String, Timestamp> = emptyMap(),
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)
