package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.AccentColor
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "chatng_settings")

/** On-device appearance and accessibility preferences. */
class ThemePreferencesRepository(private val context: Context) {

  private val themeKey = stringPreferencesKey("app_theme_mode")
  private val accentKey = stringPreferencesKey("accent_color")
  private val contrastKey = booleanPreferencesKey("increase_contrast")
  private val animationsKey = booleanPreferencesKey("animations_enabled")

  val themeModeFlow: Flow<AppThemeMode> = context.dataStore.data.map { preferences ->
    try {
      AppThemeMode.valueOf(preferences[themeKey] ?: AppThemeMode.SYSTEM.name)
    } catch (e: Exception) {
      AppThemeMode.SYSTEM
    }
  }

  val accentFlow: Flow<AccentColor> = context.dataStore.data.map { preferences ->
    try {
      AccentColor.valueOf(preferences[accentKey] ?: AccentColor.BLUE.name)
    } catch (e: Exception) {
      AccentColor.BLUE
    }
  }

  val increaseContrastFlow: Flow<Boolean> = context.dataStore.data.map { it[contrastKey] ?: false }

  val animationsEnabledFlow: Flow<Boolean> = context.dataStore.data.map { it[animationsKey] ?: true }

  suspend fun setThemeMode(mode: AppThemeMode) {
    context.dataStore.edit { it[themeKey] = mode.name }
  }

  suspend fun setAccent(accent: AccentColor) {
    context.dataStore.edit { it[accentKey] = accent.name }
  }

  suspend fun setIncreaseContrast(enabled: Boolean) {
    context.dataStore.edit { it[contrastKey] = enabled }
  }

  suspend fun setAnimationsEnabled(enabled: Boolean) {
    context.dataStore.edit { it[animationsKey] = enabled }
  }
}
