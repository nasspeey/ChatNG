package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.R
import com.example.data.model.Status
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class StatusRepository(private val db: FirebaseFirestore) {

  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    )
  )

  private val auth = FirebaseAuth.getInstance(db.app)

  /** Statuses (mine + friends') that are still within their 24h window. */
  fun observeStatuses(uid: String): Flow<List<Status>> {
    val path = "statuses"
    return db.collection(path)
      .whereArrayContains("viewers", uid)
      .snapshots()
      .map { snap ->
        val now = System.currentTimeMillis()
        snap.toObjects(Status::class.java)
          .filter { (it.expiresAt?.toDate()?.time ?: 0L) > now }
          .sortedBy { it.createdAt?.toDate()?.time ?: 0L }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        emit(emptyList())
      }
  }

  suspend fun postStatus(text: String, imageUri: Uri?, friendUids: List<String>) {
    val uid = auth.currentUser?.uid ?: throw IllegalStateException("Not signed in")
    val cleanText = text.trim()
    if (cleanText.isEmpty() && imageUri == null) return

    val id = UUID.randomUUID().toString()
    val doc = db.collection("statuses").document(id)
    try {
      var imageUrl = ""
      if (imageUri != null) {
        val ref = FirebaseStorage.getInstance(db.app).reference.child("status_images/$uid/$id.jpg")
        ref.putFile(imageUri).await()
        imageUrl = ref.downloadUrl.await().toString()
      }
      val expires = Timestamp(java.util.Date(System.currentTimeMillis() + 24L * 60 * 60 * 1000))
      doc.set(
        mapOf(
          "uid" to uid,
          "text" to cleanText,
          "imageUrl" to imageUrl,
          "viewers" to (friendUids + uid).distinct(),
          "createdAt" to FieldValue.serverTimestamp(),
          "expiresAt" to expires
        )
      ).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, doc.path)
      throw e
    }
  }

  suspend fun deleteStatus(statusId: String) {
    val doc = db.collection("statuses").document(statusId)
    try {
      doc.delete().await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, doc.path)
      throw e
    }
  }
}
