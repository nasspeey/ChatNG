package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class FriendRequest(
  val requestId: String = "",
  val senderId: String = "",
  val receiverId: String = "",
  val status: String = "pending",
  @ServerTimestamp val createdAt: Timestamp? = null
)
