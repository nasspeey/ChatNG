package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.User
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatNGRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun testUserProfileCreationAndRetrieval() = runBlocking {
    val uid = signInTestUser("alice@chatng.app")
    val userRepo = UserRepository(firestore)

    val user = User(
      uid = uid,
      name = "Alice Wonder",
      userId = "alicewonder",
      bio = "Testing ChatNG",
      isOnline = true
    )

    try {
      userRepo.saveProfile(user)
    } catch (e: Throwable) {
      println("DEBUG_SAVE_PROFILE_ERROR: ${e.message}")
      e.printStackTrace()
    }

    try {
      val doc = firestore.collection("users").document(uid).get().await()
      println("DEBUG_DOC_EXISTS: ${doc.exists()}, data: ${doc.data}")
    } catch (e: Throwable) {
      println("DEBUG_DIRECT_GET_ERROR: ${e.message}")
      e.printStackTrace()
    }

    val fetched = userRepo.getUser(uid)
    assertNotNull("fetched user is null", fetched)
    assertEquals("Alice Wonder", fetched?.name)
    assertEquals("alicewonder", fetched?.userId)
  }

  @Test
  fun testFriendRequestAndChatWorkflow() = runBlocking {
    val uid1 = signInTestUser("user1@chatng.app")
    val userRepo1 = UserRepository(firestore)
    userRepo1.saveProfile(
      User(uid = uid1, name = "User One", userId = "userone", isOnline = true)
    )

    val friendRepo1 = FriendRepository(firestore)

    val uid2 = signInTestUser("user2@chatng.app")
    val userRepo2 = UserRepository(firestore)
    userRepo2.saveProfile(
      User(uid = uid2, name = "User Two", userId = "usertwo", isOnline = true)
    )

    // User 1 signs in and sends friend request to User 2
    signInTestUser("user1@chatng.app")
    friendRepo1.sendFriendRequest(uid2)

    // User 2 signs in and observes incoming request
    signInTestUser("user2@chatng.app")
    val friendRepo2 = FriendRepository(firestore)
    val incoming = friendRepo2.observeIncomingRequests(uid2).first()
    assertTrue(incoming.any { it.senderId == uid1 })

    val req = incoming.first { it.senderId == uid1 }
    friendRepo2.acceptFriendRequest(req.requestId, uid1, uid2)

    // User 1 creates/retrieves chat and sends message
    signInTestUser("user1@chatng.app")
    val chatRepo1 = ChatRepository(firestore)
    val chatId = chatRepo1.getOrCreateChatId(uid2)
    assertNotNull(chatId)

    chatRepo1.sendMessage(chatId, "Hello User 2!")
    val messages = chatRepo1.observeMessages(chatId).first()
    assertTrue(messages.any { it.message == "Hello User 2!" && it.senderId == uid1 })
  }

  @Test(expected = IllegalStateException::class)
  fun testUnauthenticatedUserCannotSendMessage() = runBlocking {
    auth.signOut()
    val chatRepo = ChatRepository(firestore)
    chatRepo.sendMessage("any_chat", "Unauthorized message")
  }
}
