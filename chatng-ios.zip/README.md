# ChatNG — Real-Time Android Messenger Application

ChatNG is a production-grade, real-time messaging application for Android built using Kotlin, Jetpack Compose, Material Design 3, and Firebase (Authentication, Cloud Firestore, Firebase Storage, and Cloud Messaging).

---

## 🌟 Key Features

1. **Authentication System**
   - **Google Sign-In** via Jetpack Credential Manager (`GetSignInWithGoogleOption`).
   - **Phone Number Authentication & OTP Login** via Firebase `PhoneAuthProvider`.
   - **Session Persistence**: Stay logged in across app launches; auto-restores active sessions and routes appropriately.

2. **User Profile & Handle System**
   - **Profile Setup**: Required for first-time users to upload a photo, set full name, and pick a unique User ID.
   - **Unique Username Handles (`@username`)**: Real-time debounced availability check preventing handle collision.
   - **Profile Management**: View and edit display name, bio, profile picture, and account options.

3. **User Search & Discovery**
   - **Real-time User Search**: Search users by unique User ID (`@handle`).
   - **Relationship Status Indicators**: Interactive action chips ("Add Friend", "Request Sent", "Friends", "Respond").

4. **Friend Request & Friendship System**
   - **Bilateral Relationship Workflows**: Send, receive, accept, or reject friend requests.
   - **Friends Directory**: View all friends with presence badges (`Online` vs `Last seen...`) and quick message shortcut.

5. **Real-Time One-on-One Messaging**
   - **Instant Synchronized Chat**: Real-time snapshot listeners powered by Cloud Firestore.
   - **Message Status Tracing**: Sent (`✓`), Delivered (`✓✓`), and Read/Seen (`✓✓` Cyan) status indicators.
   - **Recent Chats & Previews**: Sorted by latest activity timestamp with unread message counter badges.
   - **Pinned Chats**: Pin up to 3 priority conversations to the top of the feed.

6. **System & Custom Appearance Theme**
   - Dynamic support for **System Default**, **Light Mode**, and **Dark Mode** with DataStore persistence.

---

## 🛠 Tech Stack & Architecture

- **Language**: Kotlin
- **UI Framework**: Jetpack Compose (Material Design 3)
- **Architecture**: MVVM (Model-View-ViewModel) + Clean Data Layer
- **Backend Services**:
  - **Firebase Authentication** (Google & Phone OTP)
  - **Cloud Firestore** (Database & Real-time Sync)
  - **Firebase Storage** (Profile Photos & Media)
  - **Cloud Functions for Firebase** (Push Notifications)
  - **Firebase App Check** (dependencies present; enforcement must be enabled in the console and initialised in code)

---

## 📁 Repository Structure

```
├── app/
│   ├── build.gradle.kts
│   ├── google-services.json
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── java/com/example/
│       │   │   ├── MainActivity.kt
│       │   │   ├── data/
│       │   │   │   ├── model/         # User, Chat, Message, FriendRequest, Friend
│       │   │   │   └── repository/    # UserRepository, ChatRepository, FriendRepository, ThemePreferencesRepository
│       │   │   ├── ui/
│       │   │   │   ├── components/    # BottomNavBar, ChatNGBubbleLogo, Wave Graphics
│       │   │   │   ├── navigation/    # Screen targets and tab definitions
│       │   │   │   ├── screens/       # SignIn, ProfileSetup, Home, Chats, Chat, Friends, Search, Profile, Settings, Status
│       │   │   │   ├── theme/         # Color, Theme, Type
│       │   │   │   └── viewmodel/     # MainViewModel
│       │   │   └── base/              # Firestore test base harness
│       │   └── res/
├── firebase-blueprint.json             # Schema definitions
├── firestore.rules                     # Zero-trust Firestore security rules
├── firestore.indexes.json               # Composite index configurations
├── storage.rules                       # Storage security rules
└── functions/                          # TypeScript Cloud Functions (push notifications)
    ├── package.json
    ├── tsconfig.json
    └── src/index.ts
```

---

## 🚀 Firebase Setup & Deployment Guide

### 1. Deploy Firestore Security Rules
```bash
firebase deploy --only firestore:rules
```

### 2. Deploy Storage Rules
```bash
firebase deploy --only storage
```

### 3. Deploy Composite Indexes
```bash
firebase deploy --only firestore:indexes
```

### 4. Deploy Cloud Functions
```bash
cd functions
npm install
npm run build
firebase deploy --only functions
```

---

## ✨ Features

- Google and phone sign-in, unique `@handles`, profile photos stored in Firebase Storage
- iOS-style interface: large titles, translucent tab bar, grouped settings, action sheets, push-style transitions, light/dark/system themes
- 1:1 chat with grouped bubbles, day headers, **Delivered / Read** receipts, **typing indicator**, **photo messages**, long-press **Copy / Unsend**, pinned chats (max 3)
- **Status**: 24-hour text/photo updates visible to your friends, with a story viewer
- Friend requests (send, accept, decline, re-send), remove friend, **block / unblock**
- **Settings**: account (photo, name, username, email, phone, log out), accessibility (increase contrast, animation on/off), theme manager (mode + accent colour) and a full privacy section
- **Privacy that is enforced server-side**: photo, About, email and phone live in protected `users/{uid}/private/*` documents. Firestore rules read the owner's settings (Only me / My friends / Everyone except… / My friends except…) before releasing them. Status audiences are fixed at post time.
- Live presence ("Online" / "Last seen"), push notifications through Cloud Functions + FCM

> Tip: enable a Firestore **TTL policy** on `statuses.expiresAt` (Firebase console → Firestore → TTL) so expired status documents are deleted automatically.

## ✅ Data model (rules and app now agree)

| Collection | Doc ID | Who may write |
|---|---|---|
| `users/{uid}` | auth uid | owner only (validated handle, name, bio) |
| `users/{uid}/devices/{id}` | installation id | owner only (FCM token) |
| `friendRequests/{sender}_{receiver}` | canonical | sender creates; **receiver only** may accept/reject |
| `friends/{uid}_{friendUid}` | canonical | only alongside an accepted request (atomic batch) |
| `chats/{uidA}_{uidB}` | sorted uids | participants; participant list immutable |
| `messages/{id}` | uuid | participants (and not blocked); sender identity enforced; recipient may only set `seen`; sender may delete |
| `users/{uid}/private/{settings,photo,about,email,phone}` | fixed names | owner writes; others read only what the owner's privacy settings allow |
| `blocks/{uid}_{blockedUid}` | canonical | owner only; invisible to the blocked user |
| `statuses/{id}` | uuid | owner creates/deletes; readable by owner and the `viewers` list captured at post time |

Unread counters use `FieldValue.increment`, and message + chat metadata are written in a single batch.

## 🔒 Security Invariants

1. **Zero-Trust Rules**: Every collection requires `request.auth != null`, strict document ownership, and model attribute type validation.
2. **Credential Manager Exclusivity**: Google Sign-In is executed via Jetpack `CredentialManager` using `GetSignInWithGoogleOption`.
3. **Custom Database ID**: All Firestore calls reference `context.getString(R.string.firestore_database_id)`.
4. **Storage**: chat attachments are readable/writable only by the two participants (derived from the `uidA_uidB` chat ID).
5. **Known trade-off**: profiles (including email/phone) are readable by any signed-in user so search works. Move `email`/`phoneNumber` to a private document if that matters for your users.
6. **Privacy migration**: profiles created before the privacy update have their email, phone, About and photo moved from the public document into protected ones the first time the owner opens the app.
7. **Group privacy** is stored but not yet enforced because group chats don't exist yet.
8. **Profile pictures** are fetched once per session, so a changed or newly hidden photo may take until the next launch to update for others.

## 📦 Building the APK

- **Android Studio**: open the folder, let Gradle sync, then *Build → Build APK(s)*. Output: `app/build/outputs/apk/debug/app-debug.apk`.
- **Command line**: `./build-apk.sh` (JDK 17+, Android SDK, Gradle 9.3.1+).
- **GitHub Actions**: push the project to GitHub and run the *Build APK* workflow (Actions tab). The APK is attached to the run as `chatng-debug-apk`.

The bundled `debug.keystore` is the standard throwaway debug key (password `android`). Register its SHA-1 in Firebase (Project settings → Your apps → Add fingerprint) or Google sign-in will fail. For a release build, provide `KEYSTORE_PATH`, `STORE_PASSWORD` and `KEY_PASSWORD` and run `:app:assembleRelease`.
