import * as functions from "firebase-functions";
import * as admin from "firebase-admin";

admin.initializeApp();
const db = admin.firestore();

// If the app uses a named Firestore database (see firebase.json), point the
// Admin SDK at it; otherwise this resolves to "(default)".
// import { getFirestore } from "firebase-admin/firestore";
// const db = getFirestore("<database-id>");

/**
 * On every new message, push a notification to the other participant.
 * Stale tokens reported by FCM are removed from the user's devices.
 */
export const onNewMessageSent = functions.firestore
  .document("messages/{messageId}")
  .onCreate(async (snapshot) => {
    const message = snapshot.data();
    if (!message) return;

    const { chatId, senderId } = message as { chatId: string; senderId: string };
    const type: string = message.type ?? "text";
    const body =
      type === "image" ? "Sent a photo" :
      type === "file" ? "Sent a file" :
      String(message.message ?? "Sent a message").slice(0, 200);

    const chatDoc = await db.collection("chats").doc(chatId).get();
    const participants: string[] = chatDoc.data()?.participants ?? [];
    const recipientUid = participants.find((uid) => uid !== senderId);
    if (!recipientUid) return;

    const [senderDoc, devicesSnap] = await Promise.all([
      db.collection("users").doc(senderId).get(),
      db.collection("users").doc(recipientUid).collection("devices").get(),
    ]);
    const senderName: string = senderDoc.data()?.name || "ChatNG";

    const devices = devicesSnap.docs.filter(
      (d) => d.data().token && d.data().notificationsEnabled !== false
    );
    if (devices.length === 0) return;

    const response = await admin.messaging().sendEachForMulticast({
      tokens: devices.map((d) => d.data().token as string),
      notification: { title: senderName, body },
      data: { chatId, senderId, type: "NEW_MESSAGE" },
      android: { priority: "high" },
    });

    // Clean up tokens FCM says are no longer valid.
    const stale: Promise<unknown>[] = [];
    response.responses.forEach((r, i) => {
      const code = r.error?.code;
      if (
        code === "messaging/registration-token-not-registered" ||
        code === "messaging/invalid-registration-token"
      ) {
        stale.push(devices[i].ref.delete());
      }
    });
    await Promise.all(stale);
  });
