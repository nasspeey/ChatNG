const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const firebase = require("firebase/compat/app");
require("firebase/compat/firestore");

const PROJECT_ID = "demo-no-project";
const TS = () => firebase.firestore.FieldValue.serverTimestamp();
let testEnv;

const as = (uid) => testEnv.authenticatedContext(uid).firestore();

const profile = (uid, extra = {}) => ({
  uid, name: `User ${uid}`, userId: uid, email: "", profileImage: "", bio: "",
  phoneNumber: "", isOnline: true, createdAt: TS(), updatedAt: TS(), ...extra,
});

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: { rules: fs.readFileSync("firestore.rules", "utf8"), host: "127.0.0.1", port: 8085 },
  });
});
after(async () => { if (testEnv) await testEnv.cleanup(); });
beforeEach(async () => { if (testEnv) await testEnv.clearFirestore(); });

// ---------- users ----------
test("unauthenticated access is denied", async () => {
  const db = testEnv.unauthenticatedContext().firestore();
  await assertFails(db.collection("users").doc("user1").get());
  await assertFails(db.collection("users").doc("user1").set(profile("user1")));
});

test("user can create and read own profile; cannot create someone else's", async () => {
  await assertSucceeds(as("user1").collection("users").doc("user1").set(profile("user1")));
  await assertSucceeds(as("user2").collection("users").doc("user1").get());
  await assertFails(as("user2").collection("users").doc("user3").set(profile("user3")));
});

test("user cannot edit another user's profile or use an invalid handle", async () => {
  await assertSucceeds(as("user1").collection("users").doc("user1").set(profile("user1")));
  await assertFails(as("user2").collection("users").doc("user1").update({ name: "Hacked" }));
  await assertFails(as("user2").collection("users").doc("user2").set(profile("user2", { userId: "Bad Handle!" })));
});

// ---------- friend requests / friends ----------
test("friend request must use canonical id and sender identity", async () => {
  const db = as("user1");
  const base = { senderId: "user1", receiverId: "user2", status: "pending", createdAt: TS() };
  await assertSucceeds(db.collection("friendRequests").doc("user1_user2").set({ requestId: "user1_user2", ...base }));
  await assertFails(db.collection("friendRequests").doc("random").set({ requestId: "random", ...base }));
  await assertFails(as("user3").collection("friendRequests").doc("user1_user3")
    .set({ requestId: "user1_user3", senderId: "user1", receiverId: "user3", status: "pending", createdAt: TS() }));
});

test("only the receiver can accept; friendship rows need an accepted request", async () => {
  const req = { requestId: "user1_user2", senderId: "user1", receiverId: "user2", status: "pending", createdAt: TS() };
  await assertSucceeds(as("user1").collection("friendRequests").doc("user1_user2").set(req));

  await assertFails(as("user1").collection("friendRequests").doc("user1_user2").update({ status: "accepted" }));
  await assertFails(as("user2").collection("friends").doc("user1_user2")
    .set({ uid: "user1", friendUid: "user2", createdAt: TS() }));

  const db = as("user2");
  const batch = db.batch();
  batch.update(db.collection("friendRequests").doc("user1_user2"), { status: "accepted" });
  batch.set(db.collection("friends").doc("user1_user2"), { uid: "user1", friendUid: "user2", createdAt: TS() });
  batch.set(db.collection("friends").doc("user2_user1"), { uid: "user2", friendUid: "user1", createdAt: TS() });
  await assertSucceeds(batch.commit());

  await assertFails(as("user3").collection("friendRequests").doc("user1_user2").get());
});

// ---------- chats & messages ----------
const chat = (a, b) => ({
  participants: [a, b], lastMessage: "", lastSenderId: "", pinnedBy: [],
  unreadCounts: { [a]: 0, [b]: 0 }, timestamp: TS(), createdAt: TS(), updatedAt: TS(),
});

test("chat uses canonical id; participants only", async () => {
  await assertSucceeds(as("user1").collection("chats").doc("user1_user2").set(chat("user1", "user2")));
  await assertFails(as("user1").collection("chats").doc("chat1").set(chat("user1", "user2")));
  await assertFails(as("user3").collection("chats").doc("user1_user2").get());
  await assertSucceeds(as("user2").collection("chats").doc("user1_user2").get());
  // existence check on a missing chat must not error
  await assertSucceeds(as("user1").collection("chats").doc("user1_user9").get());
});

test("messages: sender identity, membership, and seen-only updates", async () => {
  await assertSucceeds(as("user1").collection("chats").doc("user1_user2").set(chat("user1", "user2")));

  const msg = (id, sender) => ({
    messageId: id, chatId: "user1_user2", senderId: sender, message: "hi",
    seen: false, delivered: true, type: "text", timestamp: TS(),
  });
  await assertSucceeds(as("user1").collection("messages").doc("m1").set(msg("m1", "user1")));
  await assertFails(as("user1").collection("messages").doc("m2").set(msg("m2", "user2"))); // forged sender
  await assertFails(as("user3").collection("messages").doc("m3").set(msg("m3", "user3"))); // not a participant

  await assertSucceeds(as("user2").collection("messages").where("chatId", "==", "user1_user2").get());
  await assertFails(as("user3").collection("messages").where("chatId", "==", "user1_user2").get());

  await assertFails(as("user1").collection("messages").doc("m1").update({ seen: true }));        // sender can't mark seen
  await assertFails(as("user2").collection("messages").doc("m1").update({ message: "edited" })); // no edits
  await assertSucceeds(as("user2").collection("messages").doc("m1").update({ seen: true }));
});

// ---------- blocks ----------
test("blocking prevents messages and friend requests in both directions", async () => {
  await assertSucceeds(as("user1").collection("chats").doc("user1_user2").set(chat("user1", "user2")));

  await assertSucceeds(as("user2").collection("blocks").doc("user2_user1")
    .set({ uid: "user2", blockedUid: "user1", createdAt: TS() }));

  const msg = {
    messageId: "m1", chatId: "user1_user2", senderId: "user1", message: "hi",
    seen: false, delivered: true, type: "text", timestamp: TS(),
  };
  await assertFails(as("user1").collection("messages").doc("m1").set(msg));
  await assertFails(as("user1").collection("friendRequests").doc("user1_user2")
    .set({ requestId: "user1_user2", senderId: "user1", receiverId: "user2", status: "pending", createdAt: TS() }));

  // The blocked user cannot see that they were blocked.
  await assertFails(as("user1").collection("blocks").doc("user2_user1").get());
  // Unblocking restores messaging.
  await assertSucceeds(as("user2").collection("blocks").doc("user2_user1").delete());
  await assertSucceeds(as("user1").collection("messages").doc("m1").set(msg));
});

test("users cannot create blocks on behalf of others", async () => {
  await assertFails(as("user1").collection("blocks").doc("user2_user3")
    .set({ uid: "user2", blockedUid: "user3", createdAt: TS() }));
});

// ---------- unsend / re-send ----------
test("only the sender can unsend a message", async () => {
  await assertSucceeds(as("user1").collection("chats").doc("user1_user2").set(chat("user1", "user2")));
  await assertSucceeds(as("user1").collection("messages").doc("m1").set({
    messageId: "m1", chatId: "user1_user2", senderId: "user1", message: "oops",
    seen: false, delivered: true, type: "text", timestamp: TS(),
  }));
  await assertFails(as("user2").collection("messages").doc("m1").delete());
  await assertSucceeds(as("user1").collection("messages").doc("m1").delete());
});

test("a rejected friend request can be re-sent by the sender only", async () => {
  const req = { requestId: "user1_user2", senderId: "user1", receiverId: "user2", status: "pending", createdAt: TS() };
  await assertSucceeds(as("user1").collection("friendRequests").doc("user1_user2").set(req));
  await assertSucceeds(as("user2").collection("friendRequests").doc("user1_user2").update({ status: "rejected" }));
  await assertFails(as("user3").collection("friendRequests").doc("user1_user2").update({ status: "pending", createdAt: TS() }));
  await assertSucceeds(as("user1").collection("friendRequests").doc("user1_user2").update({ status: "pending", createdAt: TS() }));
});

// ---------- statuses ----------
test("statuses are visible only to listed viewers and the owner", async () => {
  const expires = new Date(Date.now() + 23 * 3600 * 1000);
  await assertSucceeds(as("user1").collection("statuses").doc("s1").set({
    uid: "user1", text: "hello", imageUrl: "", viewers: ["user1", "user2"],
    createdAt: TS(), expiresAt: expires,
  }));
  await assertSucceeds(as("user2").collection("statuses").where("viewers", "array-contains", "user2").get());
  await assertFails(as("user3").collection("statuses").doc("s1").get());
  await assertFails(as("user2").collection("statuses").doc("s1").delete());
  await assertSucceeds(as("user1").collection("statuses").doc("s1").delete());

  // Cannot post as someone else or with an expiry beyond 25h.
  await assertFails(as("user2").collection("statuses").doc("s2").set({
    uid: "user1", text: "forged", imageUrl: "", viewers: ["user2"], createdAt: TS(), expiresAt: expires,
  }));
  await assertFails(as("user1").collection("statuses").doc("s3").set({
    uid: "user1", text: "long", imageUrl: "", viewers: ["user1"], createdAt: TS(),
    expiresAt: new Date(Date.now() + 72 * 3600 * 1000),
  }));
});

// ---------- privacy: protected profile data ----------
const settingsDoc = (over = {}) => ({
  personalInfo: { mode: "FRIENDS", excluded: [] },
  profilePicture: { mode: "EVERYONE_EXCEPT", excluded: [] },
  about: { mode: "EVERYONE", excluded: [] },
  status: { mode: "FRIENDS", excluded: [] },
  group: { mode: "FRIENDS", excluded: [] },
  email: { mode: "FRIENDS", excluded: [] },
  phone: { mode: "ONLY_ME", excluded: [] },
  ...over,
});

async function seedOwner(uid, settings) {
  const db = as(uid);
  await assertSucceeds(db.collection("users").doc(uid).collection("private").doc("settings").set(settings));
  await assertSucceeds(db.collection("users").doc(uid).collection("private").doc("email").set({ value: "a@b.co", updatedAt: TS() }));
  await assertSucceeds(db.collection("users").doc(uid).collection("private").doc("phone").set({ value: "+15551234", updatedAt: TS() }));
  await assertSucceeds(db.collection("users").doc(uid).collection("private").doc("about").set({ text: "hi", updatedAt: TS() }));
  await assertSucceeds(db.collection("users").doc(uid).collection("private").doc("photo").set({ url: "https://x/y.jpg", updatedAt: TS() }));
}

async function makeFriends(a, b) {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("friends").doc(`${a}_${b}`).set({ uid: a, friendUid: b, createdAt: new Date() });
    await db.collection("friends").doc(`${b}_${a}`).set({ uid: b, friendUid: a, createdAt: new Date() });
  });
}

const priv = (viewer, owner, docId) => as(viewer).collection("users").doc(owner).collection("private").doc(docId).get();

test("owner can always read their own private data; settings stay owner-only", async () => {
  await seedOwner("user1", settingsDoc());
  await assertSucceeds(priv("user1", "user1", "email"));
  await assertSucceeds(priv("user1", "user1", "settings"));
  await assertFails(priv("user2", "user1", "settings"));
});

test("'Only me' blocks everyone else; 'My friends' needs a friendship", async () => {
  await seedOwner("user1", settingsDoc());
  await makeFriends("user1", "user2");

  await assertFails(priv("user2", "user1", "phone"));       // phone: ONLY_ME
  await assertSucceeds(priv("user2", "user1", "email"));    // personalInfo + email: FRIENDS, user2 is a friend
  await assertFails(priv("user3", "user1", "email"));       // stranger
  await assertSucceeds(priv("user3", "user1", "about"));    // about: EVERYONE
  await assertSucceeds(priv("user3", "user1", "photo"));    // picture: EVERYONE_EXCEPT [] = everyone
});

test("'except' lists hide data from the named people only", async () => {
  await seedOwner("user1", settingsDoc({
    profilePicture: { mode: "EVERYONE_EXCEPT", excluded: ["user3"] },
    email: { mode: "FRIENDS_EXCEPT", excluded: ["user2"] },
  }));
  await makeFriends("user1", "user2");
  await makeFriends("user1", "user4");

  await assertFails(priv("user3", "user1", "photo"));
  await assertSucceeds(priv("user2", "user1", "photo"));
  await assertFails(priv("user2", "user1", "email"));       // friend, but excluded
  await assertSucceeds(priv("user4", "user1", "email"));    // friend, not excluded
});

test("personal info acts as a master switch for email and phone", async () => {
  await seedOwner("user1", settingsDoc({
    personalInfo: { mode: "ONLY_ME", excluded: [] },
    email: { mode: "FRIENDS", excluded: [] },
  }));
  await makeFriends("user1", "user2");
  await assertFails(priv("user2", "user1", "email"));
});

test("without a settings document nothing is shared", async () => {
  await assertSucceeds(as("user1").collection("users").doc("user1").collection("private").doc("about").set({ text: "x", updatedAt: TS() }));
  await assertFails(priv("user2", "user1", "about"));
});

test("only the owner can write private documents", async () => {
  await assertFails(as("user2").collection("users").doc("user1").collection("private").doc("about").set({ text: "x", updatedAt: TS() }));
  await assertFails(as("user1").collection("users").doc("user1").collection("private").doc("extra").set({ a: 1 }));
});
